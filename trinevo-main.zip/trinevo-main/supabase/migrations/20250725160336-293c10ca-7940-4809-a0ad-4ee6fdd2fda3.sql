-- Create status enum for quotes
CREATE TYPE public.quote_status AS ENUM ('Saved', 'Sent', 'Accepted', 'Declined');

-- Create quotes table
CREATE TABLE public.quotes (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    quote_number TEXT NOT NULL,
    status quote_status NOT NULL DEFAULT 'Saved',
    client_id UUID NOT NULL REFERENCES public.customers(id) ON DELETE CASCADE,
    currency TEXT NOT NULL DEFAULT 'EUR',
    subtotal NUMERIC(10,2) NOT NULL DEFAULT 0,
    total NUMERIC(10,2) NOT NULL DEFAULT 0,
    notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    author_id UUID NOT NULL
);

-- Create quote_lines table
CREATE TABLE public.quote_lines (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    quote_id UUID NOT NULL REFERENCES public.quotes(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    description TEXT,
    quantity NUMERIC(10,2) NOT NULL DEFAULT 1,
    unit_price NUMERIC(10,2) NOT NULL DEFAULT 0,
    total NUMERIC(10,2) NOT NULL DEFAULT 0,
    display_order INTEGER NOT NULL DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on quotes table
ALTER TABLE public.quotes ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for quotes
CREATE POLICY "Users can view their own quotes" 
ON public.quotes 
FOR SELECT 
USING (author_id = auth.uid());

CREATE POLICY "Users can create their own quotes" 
ON public.quotes 
FOR INSERT 
WITH CHECK (author_id = auth.uid());

CREATE POLICY "Users can update their own quotes" 
ON public.quotes 
FOR UPDATE 
USING (author_id = auth.uid());

CREATE POLICY "Users can delete their own quotes" 
ON public.quotes 
FOR DELETE 
USING (author_id = auth.uid());

-- Enable RLS on quote_lines table
ALTER TABLE public.quote_lines ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for quote_lines (access through quote ownership)
CREATE POLICY "Users can view quote lines of their quotes" 
ON public.quote_lines 
FOR SELECT 
USING (EXISTS (
    SELECT 1 FROM public.quotes 
    WHERE quotes.id = quote_lines.quote_id 
    AND quotes.author_id = auth.uid()
));

CREATE POLICY "Users can create quote lines for their quotes" 
ON public.quote_lines 
FOR INSERT 
WITH CHECK (EXISTS (
    SELECT 1 FROM public.quotes 
    WHERE quotes.id = quote_lines.quote_id 
    AND quotes.author_id = auth.uid()
));

CREATE POLICY "Users can update quote lines of their quotes" 
ON public.quote_lines 
FOR UPDATE 
USING (EXISTS (
    SELECT 1 FROM public.quotes 
    WHERE quotes.id = quote_lines.quote_id 
    AND quotes.author_id = auth.uid()
));

CREATE POLICY "Users can delete quote lines of their quotes" 
ON public.quote_lines 
FOR DELETE 
USING (EXISTS (
    SELECT 1 FROM public.quotes 
    WHERE quotes.id = quote_lines.quote_id 
    AND quotes.author_id = auth.uid()
));

-- Add triggers for updated_at timestamps
CREATE TRIGGER update_quotes_updated_at
    BEFORE UPDATE ON public.quotes
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_quote_lines_updated_at
    BEFORE UPDATE ON public.quote_lines
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at_column();

-- Create index for quote numbers (should be unique per user)
CREATE UNIQUE INDEX idx_quotes_number_author ON public.quotes(quote_number, author_id);

-- Create index for quote lines ordering
CREATE INDEX idx_quote_lines_quote_order ON public.quote_lines(quote_id, display_order);