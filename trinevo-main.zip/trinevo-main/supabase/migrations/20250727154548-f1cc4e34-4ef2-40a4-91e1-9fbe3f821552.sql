-- Fix the remaining function search path issue
CREATE OR REPLACE FUNCTION public.update_project_progress()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  total_tasks INTEGER;
  completed_tasks INTEGER;
  project_progress INTEGER;
BEGIN
  -- Get task counts for the project
  SELECT 
    COUNT(*) as total,
    COUNT(CASE WHEN status = 'done' THEN 1 END) as completed
  INTO total_tasks, completed_tasks
  FROM public.tasks 
  WHERE project_id = COALESCE(NEW.project_id, OLD.project_id);
  
  -- Calculate progress percentage
  IF total_tasks = 0 THEN
    project_progress := 0;
  ELSE
    project_progress := ROUND((completed_tasks::DECIMAL / total_tasks::DECIMAL) * 100);
  END IF;
  
  -- Update project progress and status
  UPDATE public.projects 
  SET 
    progress = project_progress,
    status = CASE 
      WHEN project_progress = 100 THEN 'completed'
      WHEN project_progress > 0 THEN 'in_progress'
      ELSE status
    END,
    updated_at = now()
  WHERE id = COALESCE(NEW.project_id, OLD.project_id);
  
  RETURN COALESCE(NEW, OLD);
END;
$$;