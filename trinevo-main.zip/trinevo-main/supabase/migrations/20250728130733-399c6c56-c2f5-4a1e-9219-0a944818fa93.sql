-- Add Stripe fields to profiles table
ALTER TABLE profiles ADD COLUMN stripe_account_id TEXT;
ALTER TABLE profiles ADD COLUMN stripe_connected BOOLEAN DEFAULT FALSE;
ALTER TABLE profiles ADD COLUMN stripe_publishable_key TEXT;

-- Create email tracking table
CREATE TABLE email_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  document_type TEXT NOT NULL, -- 'invoice' or 'quote'
  document_id UUID NOT NULL,
  recipient_email TEXT NOT NULL,
  subject TEXT NOT NULL,
  sent_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  status TEXT DEFAULT 'sent', -- 'sent', 'delivered', 'opened', 'failed'
  payment_link_id TEXT, -- Stripe payment link ID for invoices
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS on email_logs
ALTER TABLE email_logs ENABLE ROW LEVEL SECURITY;

-- Create policies for email_logs
CREATE POLICY "Users can view their own email logs" 
ON email_logs FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own email logs" 
ON email_logs FOR INSERT 
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own email logs" 
ON email_logs FOR UPDATE 
USING (auth.uid() = user_id);