-- Add missing notes column to customers table
ALTER TABLE public.customers 
ADD COLUMN notes TEXT;