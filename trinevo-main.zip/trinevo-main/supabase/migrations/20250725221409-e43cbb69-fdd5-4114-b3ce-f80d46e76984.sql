-- Add company logo and accent color fields to profiles table
ALTER TABLE public.profiles 
ADD COLUMN company_logo TEXT,
ADD COLUMN accent_color TEXT DEFAULT '#3b82f6';