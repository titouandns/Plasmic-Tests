-- Make email field nullable to allow customer creation with minimal data
ALTER TABLE public.customers 
ALTER COLUMN email DROP NOT NULL;