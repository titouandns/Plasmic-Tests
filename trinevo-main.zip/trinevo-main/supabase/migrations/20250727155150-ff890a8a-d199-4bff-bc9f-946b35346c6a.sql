-- Fix the recursive team_members policies once and for all
DROP POLICY IF EXISTS "Team admins can manage team members" ON team_members;
DROP POLICY IF EXISTS "Users can view team members of their teams" ON team_members;

-- Create a security definer function to check team membership
CREATE OR REPLACE FUNCTION public.is_team_member(team_id_param uuid, user_id_param uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = ''
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.team_members
    WHERE team_id = team_id_param
    AND user_id = user_id_param
  );
$$;

-- Create a security definer function to check team admin status
CREATE OR REPLACE FUNCTION public.is_team_admin(team_id_param uuid, user_id_param uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = ''
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.team_members
    WHERE team_id = team_id_param
    AND user_id = user_id_param
    AND role IN ('owner', 'admin')
  );
$$;

-- Create new policies using the security definer functions
CREATE POLICY "Users can view their team memberships"
ON team_members FOR SELECT
USING (user_id = auth.uid());

CREATE POLICY "Users can view team members where they are also members"
ON team_members FOR SELECT
USING (public.is_team_member(team_id, auth.uid()));

CREATE POLICY "Team admins can insert team members"
ON team_members FOR INSERT
WITH CHECK (public.is_team_admin(team_id, auth.uid()) OR user_id = auth.uid());

CREATE POLICY "Team admins can update team members"
ON team_members FOR UPDATE
USING (public.is_team_admin(team_id, auth.uid()));

CREATE POLICY "Team admins can delete team members"
ON team_members FOR DELETE
USING (public.is_team_admin(team_id, auth.uid()) AND user_id != auth.uid());