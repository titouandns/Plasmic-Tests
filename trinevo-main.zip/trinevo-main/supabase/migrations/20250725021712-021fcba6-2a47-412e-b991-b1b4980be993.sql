-- Fix function security by dropping trigger, function, then recreating both with proper security
DROP TRIGGER IF EXISTS update_customers_updated_at ON public.customers;
DROP FUNCTION IF EXISTS public.update_updated_at_column();

-- Recreate function with proper security
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = '';

-- Recreate trigger
CREATE TRIGGER update_customers_updated_at
  BEFORE UPDATE ON public.customers
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();