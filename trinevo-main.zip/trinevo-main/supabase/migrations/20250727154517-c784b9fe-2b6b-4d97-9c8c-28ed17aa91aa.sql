-- Fix security warnings by setting search path on functions
CREATE OR REPLACE FUNCTION ensure_default_team_name()
RETURNS TRIGGER 
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
BEGIN
  IF NEW.name IS NULL OR TRIM(NEW.name) = '' THEN
    NEW.name := 'My Team';
  END IF;
  RETURN NEW;
END;
$$;

-- Update the existing update_updated_at_column function to fix search path
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;