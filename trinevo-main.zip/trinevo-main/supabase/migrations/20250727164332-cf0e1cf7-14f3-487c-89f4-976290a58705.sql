-- Add missing INSERT policy for teams table
CREATE POLICY "Users can create teams" 
ON public.teams 
FOR INSERT 
WITH CHECK (true);

-- Create function to automatically create team and assign user as owner
CREATE OR REPLACE FUNCTION public.handle_new_user_team()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  new_team_id UUID;
  team_name TEXT;
BEGIN
  -- Get user's first name from metadata or fallback to email prefix
  team_name := COALESCE(
    NEW.raw_user_meta_data ->> 'first_name',
    SPLIT_PART(NEW.email, '@', 1)
  ) || '''s Team';
  
  -- Create new team
  INSERT INTO public.teams (name)
  VALUES (team_name)
  RETURNING id INTO new_team_id;
  
  -- Add user as team owner
  INSERT INTO public.team_members (team_id, user_id, role, invited_by)
  VALUES (new_team_id, NEW.id, 'owner', NEW.id);
  
  RETURN NEW;
END;
$$;

-- Create trigger to auto-create team when user signs up
DROP TRIGGER IF EXISTS on_auth_user_created_team ON auth.users;
CREATE TRIGGER on_auth_user_created_team
  AFTER INSERT ON auth.users
  FOR EACH ROW 
  EXECUTE FUNCTION public.handle_new_user_team();

-- Update existing users without teams (like current user)
DO $$
DECLARE
  user_record RECORD;
  new_team_id UUID;
  team_name TEXT;
BEGIN
  -- Find users who don't have team memberships
  FOR user_record IN 
    SELECT u.id, u.email, u.raw_user_meta_data
    FROM auth.users u
    LEFT JOIN public.team_members tm ON u.id = tm.user_id
    WHERE tm.user_id IS NULL
  LOOP
    -- Create team name
    team_name := COALESCE(
      user_record.raw_user_meta_data ->> 'first_name',
      SPLIT_PART(user_record.email, '@', 1)
    ) || '''s Team';
    
    -- Create team
    INSERT INTO public.teams (name)
    VALUES (team_name)
    RETURNING id INTO new_team_id;
    
    -- Add user as owner
    INSERT INTO public.team_members (team_id, user_id, role, invited_by)
    VALUES (new_team_id, user_record.id, 'owner', user_record.id);
    
    -- Update profile with team_id
    UPDATE public.profiles 
    SET team_id = new_team_id
    WHERE user_id = user_record.id;
  END LOOP;
END;
$$;