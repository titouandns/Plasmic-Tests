-- Add quote_id reference to projects table
ALTER TABLE public.projects 
ADD COLUMN quote_id uuid REFERENCES public.quotes(id);

-- Create index for better performance when querying projects by quote
CREATE INDEX idx_projects_quote_id ON public.projects(quote_id);

-- Add comment for documentation
COMMENT ON COLUMN public.projects.quote_id IS 'Reference to the quote this project was created from';