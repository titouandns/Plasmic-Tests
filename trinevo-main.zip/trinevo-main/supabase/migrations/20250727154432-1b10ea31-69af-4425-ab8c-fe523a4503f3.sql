-- Fix infinite recursion in team_members policies
DROP POLICY IF EXISTS "Team admins can manage team members" ON team_members;
DROP POLICY IF EXISTS "Users can view team members of their teams" ON team_members;

-- Create corrected policies for team_members
CREATE POLICY "Users can view team members of their teams" 
ON team_members FOR SELECT 
USING (
  user_id = auth.uid() OR 
  team_id IN (
    SELECT tm.team_id 
    FROM team_members tm 
    WHERE tm.user_id = auth.uid()
  )
);

CREATE POLICY "Team admins can manage team members" 
ON team_members FOR ALL 
USING (
  team_id IN (
    SELECT tm.team_id 
    FROM team_members tm 
    WHERE tm.user_id = auth.uid() 
    AND tm.role IN ('owner', 'admin')
  )
);

-- Drop existing storage policies to recreate them properly
DROP POLICY IF EXISTS "Users can upload their own avatar" ON storage.objects;
DROP POLICY IF EXISTS "Users can view their own avatar" ON storage.objects;
DROP POLICY IF EXISTS "Users can update their own avatar" ON storage.objects;
DROP POLICY IF EXISTS "Team members can upload team logos" ON storage.objects;
DROP POLICY IF EXISTS "Team members can view team logos" ON storage.objects;
DROP POLICY IF EXISTS "Team members can update team logos" ON storage.objects;

-- Create simpler storage policies for avatars
CREATE POLICY "Users can upload their own avatar"
ON storage.objects FOR INSERT
WITH CHECK (
  bucket_id = 'avatars' 
  AND auth.uid()::text = (storage.foldername(name))[1]
);

CREATE POLICY "Users can view their own avatar"
ON storage.objects FOR SELECT
USING (
  bucket_id = 'avatars' 
  AND auth.uid()::text = (storage.foldername(name))[1]
);

CREATE POLICY "Users can update their own avatar"
ON storage.objects FOR UPDATE
USING (
  bucket_id = 'avatars' 
  AND auth.uid()::text = (storage.foldername(name))[1]
);

-- Create simpler storage policies for team logos
CREATE POLICY "Team members can upload team logos"
ON storage.objects FOR INSERT
WITH CHECK (
  bucket_id = 'team-logos'
  AND EXISTS (
    SELECT 1 FROM profiles p 
    WHERE p.user_id = auth.uid() 
    AND p.team_id IS NOT NULL
    AND (storage.foldername(name))[1] = p.team_id::text
  )
);

CREATE POLICY "Team members can view team logos"
ON storage.objects FOR SELECT
USING (
  bucket_id = 'team-logos'
  AND EXISTS (
    SELECT 1 FROM profiles p 
    WHERE p.user_id = auth.uid() 
    AND p.team_id IS NOT NULL
    AND (storage.foldername(name))[1] = p.team_id::text
  )
);

CREATE POLICY "Team members can update team logos"
ON storage.objects FOR UPDATE
USING (
  bucket_id = 'team-logos'
  AND EXISTS (
    SELECT 1 FROM profiles p 
    WHERE p.user_id = auth.uid() 
    AND p.team_id IS NOT NULL
    AND (storage.foldername(name))[1] = p.team_id::text
  )
);

-- Add default team name constraint and function
CREATE OR REPLACE FUNCTION ensure_default_team_name()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.name IS NULL OR TRIM(NEW.name) = '' THEN
    NEW.name := 'My Team';
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for team name defaults
DROP TRIGGER IF EXISTS ensure_team_name_trigger ON teams;
CREATE TRIGGER ensure_team_name_trigger
  BEFORE INSERT OR UPDATE ON teams
  FOR EACH ROW
  EXECUTE FUNCTION ensure_default_team_name();