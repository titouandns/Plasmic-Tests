-- Enable the pgsodium extension for vault functionality
CREATE EXTENSION IF NOT EXISTS pgsodium;

-- Create a function to safely get secrets from the vault
CREATE OR REPLACE FUNCTION get_vault_secret(secret_name text)
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    secret_value text;
BEGIN
    SELECT decrypted_secret INTO secret_value
    FROM vault.decrypted_secrets
    WHERE name = secret_name;
    
    RETURN secret_value;
END;
$$;