-- Add archived field to customers table
ALTER TABLE public.customers 
ADD COLUMN archived BOOLEAN NOT NULL DEFAULT false;

-- Add index for better performance when filtering archived customers
CREATE INDEX idx_customers_archived ON public.customers(archived);

-- Add index for better performance when filtering by status
CREATE INDEX idx_customers_status ON public.customers(status);