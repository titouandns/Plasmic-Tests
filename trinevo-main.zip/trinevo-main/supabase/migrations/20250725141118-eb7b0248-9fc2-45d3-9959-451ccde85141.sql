-- Add separate address fields to customers table
ALTER TABLE public.customers 
ADD COLUMN street_address TEXT,
ADD COLUMN city TEXT,
ADD COLUMN postcode TEXT,
ADD COLUMN country TEXT,
ADD COLUMN state_region TEXT;

-- Create index for better performance on address searches
CREATE INDEX idx_customers_city ON public.customers(city);
CREATE INDEX idx_customers_country ON public.customers(country);