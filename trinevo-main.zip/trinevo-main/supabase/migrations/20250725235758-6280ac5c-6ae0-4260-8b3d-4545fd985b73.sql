-- Create invoices table with similar structure to quotes
CREATE TABLE public.invoices (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  invoice_number TEXT NOT NULL,
  client_id UUID NOT NULL,
  author_id UUID NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  subtotal NUMERIC NOT NULL DEFAULT 0,
  total NUMERIC NOT NULL DEFAULT 0,
  currency TEXT NOT NULL DEFAULT 'EUR',
  status TEXT NOT NULL DEFAULT 'draft',
  notes TEXT,
  due_date DATE,
  issue_date DATE DEFAULT CURRENT_DATE
);

-- Enable RLS
ALTER TABLE public.invoices ENABLE ROW LEVEL SECURITY;

-- Create policies for invoices
CREATE POLICY "Users can view their own invoices" 
ON public.invoices 
FOR SELECT 
USING (auth.uid() = author_id);

CREATE POLICY "Users can create their own invoices" 
ON public.invoices 
FOR INSERT 
WITH CHECK (auth.uid() = author_id);

CREATE POLICY "Users can update their own invoices" 
ON public.invoices 
FOR UPDATE 
USING (auth.uid() = author_id);

CREATE POLICY "Users can delete their own invoices" 
ON public.invoices 
FOR DELETE 
USING (auth.uid() = author_id);

-- Create invoice lines table
CREATE TABLE public.invoice_lines (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  invoice_id UUID NOT NULL,
  title TEXT NOT NULL,
  description TEXT,
  quantity NUMERIC NOT NULL DEFAULT 1,
  unit_price NUMERIC NOT NULL DEFAULT 0,
  total NUMERIC NOT NULL DEFAULT 0,
  display_order INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS for invoice lines
ALTER TABLE public.invoice_lines ENABLE ROW LEVEL SECURITY;

-- Create policies for invoice lines
CREATE POLICY "Users can view invoice lines of their invoices" 
ON public.invoice_lines 
FOR SELECT 
USING (EXISTS (
  SELECT 1 FROM invoices 
  WHERE invoices.id = invoice_lines.invoice_id 
  AND invoices.author_id = auth.uid()
));

CREATE POLICY "Users can create invoice lines for their invoices" 
ON public.invoice_lines 
FOR INSERT 
WITH CHECK (EXISTS (
  SELECT 1 FROM invoices 
  WHERE invoices.id = invoice_lines.invoice_id 
  AND invoices.author_id = auth.uid()
));

CREATE POLICY "Users can update invoice lines of their invoices" 
ON public.invoice_lines 
FOR UPDATE 
USING (EXISTS (
  SELECT 1 FROM invoices 
  WHERE invoices.id = invoice_lines.invoice_id 
  AND invoices.author_id = auth.uid()
));

CREATE POLICY "Users can delete invoice lines of their invoices" 
ON public.invoice_lines 
FOR DELETE 
USING (EXISTS (
  SELECT 1 FROM invoices 
  WHERE invoices.id = invoice_lines.invoice_id 
  AND invoices.author_id = auth.uid()
));

-- Add triggers for updated_at columns
CREATE TRIGGER update_invoices_updated_at
BEFORE UPDATE ON public.invoices
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_invoice_lines_updated_at
BEFORE UPDATE ON public.invoice_lines
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();