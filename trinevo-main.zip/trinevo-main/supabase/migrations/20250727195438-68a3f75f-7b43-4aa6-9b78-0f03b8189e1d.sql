-- Add type field to invoices table
ALTER TABLE public.invoices 
ADD COLUMN type text NOT NULL DEFAULT 'normal';

-- Add quote_id field to link invoices to quotes
ALTER TABLE public.invoices 
ADD COLUMN quote_id uuid REFERENCES public.quotes(id) ON DELETE SET NULL;

-- Add comment to clarify the type field values
COMMENT ON COLUMN public.invoices.type IS 'Invoice type: normal or deposit';

-- Add comment to clarify the quote_id field
COMMENT ON COLUMN public.invoices.quote_id IS 'Links invoice to source quote (for deposit/final invoices)';

-- Create index for better performance when querying invoices by quote
CREATE INDEX idx_invoices_quote_id ON public.invoices(quote_id);

-- Create index for better performance when querying by type
CREATE INDEX idx_invoices_type ON public.invoices(type);