-- Add company number and tax number fields to customers table
ALTER TABLE public.customers 
ADD COLUMN company_number text,
ADD COLUMN tax_number text;