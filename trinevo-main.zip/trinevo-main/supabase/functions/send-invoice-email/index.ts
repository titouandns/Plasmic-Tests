import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { Resend } from "npm:resend@2.0.0";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const logStep = (step: string, details?: any) => {
  const detailsStr = details ? ` - ${JSON.stringify(details)}` : '';
  console.log(`[SEND-INVOICE-EMAIL] ${step}${detailsStr}`);
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    logStep("Function started");

    const resendKey = Deno.env.get("RESEND_API_KEY");
    if (!resendKey) throw new Error("RESEND_API_KEY is not set");

    // Use service role key for database operations
    const supabaseClient = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
      { auth: { persistSession: false } }
    );

    const authHeader = req.headers.get("Authorization");
    if (!authHeader) throw new Error("No authorization header provided");
    
    const token = authHeader.replace("Bearer ", "");
    const { data: userData, error: userError } = await supabaseClient.auth.getUser(token);
    if (userError) throw new Error(`Authentication error: ${userError.message}`);
    
    const user = userData.user;
    if (!user?.email) throw new Error("User not authenticated or email not available");
    logStep("User authenticated", { userId: user.id, email: user.email });

    const { 
      invoice_id, 
      customer_email, 
      customer_name, 
      subject, 
      message, 
      payment_link_url,
      invoice_number,
      total_amount,
      currency = "EUR"
    } = await req.json();
    
    if (!invoice_id || !customer_email) {
      throw new Error("Missing required fields: invoice_id and customer_email");
    }

    // Get user profile for company details
    const { data: profile, error: profileError } = await supabaseClient
      .from("profiles")
      .select("*")
      .eq("user_id", user.id)
      .single();

    if (profileError) throw new Error("Failed to fetch user profile");

    const resend = new Resend(resendKey);

    // Create email template
    const fromEmail = `${profile.first_name || 'Team'} <onboarding@resend.dev>`;
    const defaultSubject = subject || `Invoice ${invoice_number || invoice_id} from ${profile.company_name || 'Your Company'}`;
    
    const emailHtml = `
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Invoice ${invoice_number || invoice_id}</title>
          <style>
            body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; margin: 0; padding: 0; background-color: #f8fafc; }
            .container { max-width: 600px; margin: 0 auto; background-color: white; }
            .header { background: linear-gradient(135deg, ${profile.accent_color || '#3b82f6'}, ${profile.accent_color || '#3b82f6'}dd); color: white; padding: 40px 30px; text-align: center; }
            .content { padding: 30px; }
            .invoice-details { background-color: #f8fafc; padding: 20px; border-radius: 8px; margin: 20px 0; }
            .payment-button { display: inline-block; background: ${profile.accent_color || '#3b82f6'}; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; font-weight: 600; margin: 20px 0; }
            .footer { background-color: #f1f5f9; padding: 20px; text-align: center; color: #64748b; font-size: 14px; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>Invoice ${invoice_number || invoice_id}</h1>
              <p>From ${profile.company_name || profile.first_name + ' ' + profile.last_name || 'Your Company'}</p>
            </div>
            <div class="content">
              <p>Dear ${customer_name || 'Valued Customer'},</p>
              
              ${message ? `<p>${message}</p>` : `
                <p>Thank you for your business! Please find your invoice details below.</p>
              `}
              
              <div class="invoice-details">
                <h3>Invoice Details</h3>
                <p><strong>Invoice Number:</strong> ${invoice_number || invoice_id}</p>
                <p><strong>Amount:</strong> ${total_amount ? `${currency} ${total_amount}` : 'See attached invoice'}</p>
                <p><strong>From:</strong> ${profile.company_name || profile.first_name + ' ' + profile.last_name}</p>
              </div>
              
              ${payment_link_url ? `
                <div style="text-align: center; margin: 30px 0;">
                  <a href="${payment_link_url}" class="payment-button">Pay Invoice Online</a>
                  <p style="color: #64748b; font-size: 14px; margin-top: 10px;">
                    Click the button above to pay securely with Stripe
                  </p>
                </div>
              ` : ''}
              
              <p>If you have any questions about this invoice, please don't hesitate to contact us.</p>
              
              <p>Best regards,<br>
              ${profile.first_name && profile.last_name ? `${profile.first_name} ${profile.last_name}` : 'The Team'}<br>
              ${profile.company_name || ''}</p>
            </div>
            <div class="footer">
              <p>${profile.company_name || ''}</p>
              ${profile.street_address ? `<p>${profile.street_address}, ${profile.city || ''} ${profile.zip_code || ''}</p>` : ''}
              ${profile.vat_number ? `<p>VAT: ${profile.vat_number}</p>` : ''}
            </div>
          </div>
        </body>
      </html>
    `;

    logStep("Sending email", { 
      to: customer_email, 
      subject: defaultSubject,
      hasPaymentLink: !!payment_link_url 
    });

    const emailResponse = await resend.emails.send({
      from: fromEmail,
      to: [customer_email],
      subject: defaultSubject,
      html: emailHtml,
    });

    if (emailResponse.error) {
      throw new Error(`Failed to send email: ${emailResponse.error.message}`);
    }

    logStep("Email sent successfully", { emailId: emailResponse.data?.id });

    // Log email to database
    await supabaseClient.from("email_logs").insert({
      user_id: user.id,
      document_type: 'invoice',
      document_id: invoice_id,
      recipient_email: customer_email,
      subject: defaultSubject,
      status: 'sent',
      payment_link_id: payment_link_url ? 'generated' : null,
    });

    return new Response(JSON.stringify({
      success: true,
      email_id: emailResponse.data?.id,
      message: "Invoice email sent successfully"
    }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 200,
    });

  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    logStep("ERROR in send-invoice-email", { message: errorMessage });
    return new Response(JSON.stringify({ error: errorMessage }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 500,
    });
  }
});