import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import Stripe from "https://esm.sh/stripe@14.21.0";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const logStep = (step: string, details?: any) => {
  const detailsStr = details ? ` - ${JSON.stringify(details)}` : '';
  console.log(`[CREATE-PAYMENT-LINK] ${step}${detailsStr}`);
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    logStep("Function started");

    const stripeKey = Deno.env.get("STRIPE_SECRET_KEY");
    if (!stripeKey) throw new Error("STRIPE_SECRET_KEY is not set");

    // Use service role key for database operations
    const supabaseClient = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
      { auth: { persistSession: false } }
    );

    const authHeader = req.headers.get("Authorization");
    if (!authHeader) throw new Error("No authorization header provided");
    
    const token = authHeader.replace("Bearer ", "");
    const { data: userData, error: userError } = await supabaseClient.auth.getUser(token);
    if (userError) throw new Error(`Authentication error: ${userError.message}`);
    
    const user = userData.user;
    if (!user?.email) throw new Error("User not authenticated or email not available");
    logStep("User authenticated", { userId: user.id, email: user.email });

    const { invoice_id, amount, currency = "EUR", customer_email, customer_name, description } = await req.json();
    
    if (!invoice_id || !amount) {
      throw new Error("Missing required fields: invoice_id and amount");
    }

    const stripe = new Stripe(stripeKey, { apiVersion: "2023-10-16" });

    // Get user's profile to check Stripe connection
    const { data: profile, error: profileError } = await supabaseClient
      .from("profiles")
      .select("stripe_account_id, stripe_connected")
      .eq("user_id", user.id)
      .single();

    if (profileError) throw new Error("Failed to fetch user profile");
    if (!profile?.stripe_connected || !profile?.stripe_account_id) {
      throw new Error("Stripe not connected for this user");
    }

    logStep("Creating payment link", { 
      invoice_id, 
      amount: Math.round(amount * 100), // Convert to cents
      currency,
      customer_email 
    });

    // Create Stripe payment link
    const paymentLink = await stripe.paymentLinks.create({
      line_items: [
        {
          price_data: {
            currency: currency.toLowerCase(),
            product_data: {
              name: description || `Invoice Payment - ${invoice_id}`,
              metadata: {
                invoice_id,
                user_id: user.id,
              },
            },
            unit_amount: Math.round(amount * 100), // Convert to cents
          },
          quantity: 1,
        },
      ],
      metadata: {
        invoice_id,
        user_id: user.id,
        customer_email: customer_email || "",
      },
      after_completion: {
        type: "redirect",
        redirect: {
          url: `${req.headers.get("origin") || "https://app.example.com"}/invoices/${invoice_id}?payment=success`,
        },
      },
    });

    logStep("Payment link created", { paymentLinkId: paymentLink.id, url: paymentLink.url });

    return new Response(JSON.stringify({
      success: true,
      payment_link_id: paymentLink.id,
      payment_link_url: paymentLink.url,
    }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 200,
    });

  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    logStep("ERROR in create-payment-link", { message: errorMessage });
    return new Response(JSON.stringify({ error: errorMessage }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 500,
    });
  }
});