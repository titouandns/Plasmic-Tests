import { serve } from "https://deno.land/std@0.168.0/http/server.ts"

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  console.log('=== AI Quote Generation Function Started ===')

  try {
    // 1. Check if we can read the request body
    let body;
    try {
      body = await req.json()
      console.log('Request body parsed successfully:', JSON.stringify(body))
    } catch (err) {
      console.error('Failed to parse request body:', err)
      return new Response(
        JSON.stringify({ error: 'Invalid JSON in request body' }), 
        { 
          status: 400, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      )
    }

    const { prompt } = body

    // 2. Validate prompt
    if (!prompt || typeof prompt !== 'string' || prompt.trim() === '') {
      console.error('Invalid or missing prompt')
      return new Response(
        JSON.stringify({ error: 'Prompt is required and must be a non-empty string' }), 
        { 
          status: 400, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      )
    }

    console.log('Prompt received:', prompt.substring(0, 100) + '...')

    // 3. Check API key
    const REPLICATE_API_KEY = Deno.env.get('REPLICATE_API_KEY')
    console.log('API Key exists:', !!REPLICATE_API_KEY)
    console.log('API Key length:', REPLICATE_API_KEY?.length || 0)
    
    if (!REPLICATE_API_KEY || REPLICATE_API_KEY.trim() === '') {
      console.error('REPLICATE_API_KEY environment variable not set')
      return new Response(
        JSON.stringify({ error: 'API key not configured' }), 
        { 
          status: 500, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      )
    }

    // 4. Create structured prompt
    const structuredPrompt = `You are a professional quote generator. Based on the following project description, generate detailed quote line items in EXACTLY this JSON format:

{
  "lineItems": [
    {
      "title": "Brief title for this line item",
      "description": "Detailed description of what this includes",
      "price": 1000
    }
  ]
}

Project Description: ${prompt.trim()}

Requirements:
- Generate 3-6 realistic line items based on the project scope
- Prices should be reasonable and professional (whole numbers)
- Each line should represent a distinct deliverable or service
- Use clear, professional language
- ONLY respond with valid JSON in the exact format above, no additional text`

    console.log('Structured prompt created, length:', structuredPrompt.length)

    // 5. Make API call to Replicate
    console.log('Making API call to Replicate...')
    
    let response;
    try {
      response = await fetch('https://api.replicate.com/v1/predictions', {
        method: 'POST',
        headers: {
          'Authorization': `Token ${REPLICATE_API_KEY.trim()}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          version: "1dcf2c4b2cea4a60c9e48c5f4995b8ad8cb98a1c8c4ad8c0f41fa0b7bfe1ed98",
          input: {
            prompt: structuredPrompt
          }
        }),
      })
    } catch (fetchError) {
      console.error('Fetch request failed:', fetchError)
      return new Response(
        JSON.stringify({ 
          error: 'Failed to connect to Replicate API',
          details: fetchError.message 
        }), 
        { 
          status: 500, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      )
    }

    console.log('Replicate response status:', response.status)
    console.log('Replicate response headers:', Object.fromEntries(response.headers.entries()))
    
    if (!response.ok) {
      let errorText;
      try {
        errorText = await response.text()
      } catch {
        errorText = 'Failed to read error response'
      }
      console.error('Replicate API error:', errorText)
      
      return new Response(
        JSON.stringify({ 
          error: `Replicate API error (${response.status})`,
          details: errorText
        }), 
        { 
          status: 500, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      )
    }

    let prediction;
    try {
      prediction = await response.json()
      console.log('Initial prediction response:', JSON.stringify(prediction))
    } catch (parseError) {
      console.error('Failed to parse Replicate response:', parseError)
      return new Response(
        JSON.stringify({ 
          error: 'Failed to parse Replicate response',
          details: parseError.message 
        }), 
        { 
          status: 500, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      )
    }

    // 6. Poll for completion (simplified)
    let result = prediction
    let pollCount = 0
    const maxPolls = 30 // 30 seconds max

    while ((result.status === 'starting' || result.status === 'processing') && pollCount < maxPolls) {
      await new Promise(resolve => setTimeout(resolve, 1000))
      pollCount++
      
      try {
        const pollResponse = await fetch(`https://api.replicate.com/v1/predictions/${result.id}`, {
          headers: {
            'Authorization': `Token ${REPLICATE_API_KEY.trim()}`,
            'Content-Type': 'application/json'
          },
        })
        
        if (!pollResponse.ok) {
          throw new Error(`Poll failed: ${pollResponse.status}`)
        }
        
        result = await pollResponse.json()
        console.log(`Poll ${pollCount}: ${result.status}`)
        
      } catch (pollError) {
        console.error('Polling error:', pollError)
        break
      }
    }

    if (result.status === 'failed') {
      console.error('Prediction failed:', result.error)
      return new Response(
        JSON.stringify({ 
          error: 'AI generation failed',
          details: result.error || 'Unknown error'
        }), 
        { 
          status: 500, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      )
    }

    if (result.status !== 'succeeded') {
      console.error('Prediction did not succeed, status:', result.status)
      return new Response(
        JSON.stringify({ 
          error: 'AI generation timed out or failed',
          status: result.status
        }), 
        { 
          status: 500, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      )
    }

    // 7. Process the result
    const generatedText = Array.isArray(result.output) ? result.output.join('') : (result.output || '')
    console.log('Generated text:', generatedText)

    // 8. Parse JSON response
    let lineItems;
    try {
      // Try to parse as direct JSON
      const parsed = JSON.parse(generatedText)
      if (parsed.lineItems && Array.isArray(parsed.lineItems)) {
        lineItems = parsed.lineItems.filter(item => 
          item.title && item.description && typeof item.price === 'number'
        )
      }
    } catch (parseError) {
      console.log('Direct JSON parse failed, trying fallback...')
      
      // Fallback: return a default item
      lineItems = [{
        title: "AI Generated Service",
        description: "Service generated based on your project description. Please review and edit as needed.",
        price: 1000
      }]
    }

    if (!lineItems || lineItems.length === 0) {
      lineItems = [{
        title: "Generated Quote Item",
        description: "Please review and customize this quote item based on your project requirements.",
        price: 1500
      }]
    }

    console.log(`Successfully generated ${lineItems.length} line items`)

    return new Response(JSON.stringify({ 
      lineItems,
      rawResponse: generatedText 
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 200,
    })

  } catch (error) {
    console.error("Unexpected error in ai-quote-generation function:", error)
    return new Response(JSON.stringify({ 
      error: 'Internal server error',
      details: error.message
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 500,
    })
  }
})