import { Save } from "lucide-react";
import { Button } from "@/components/ui/button";

interface SaveChangesBarProps {
  isDirty: boolean;
  onSave: () => void;
  isLoading?: boolean;
  className?: string;
}

export function SaveChangesBar({ 
  isDirty, 
  onSave, 
  isLoading = false,
  className = ""
}: SaveChangesBarProps) {
  if (!isDirty) return null;

  return (
    <div className={`fixed bottom-6 left-1/2 -translate-x-1/2 z-50 animate-slide-in-bottom ${className}`}>
      <Button
        variant="dark"
        onClick={onSave}
        disabled={isLoading}
      >
        <Save className="h-4 w-4 mr-2" />
        {isLoading ? "Saving..." : "Save Changes"}
      </Button>
    </div>
  );
}
