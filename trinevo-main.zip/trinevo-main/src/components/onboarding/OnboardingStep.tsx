import { ReactNode } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
interface OnboardingStepProps {
  step: number;
  title: string;
  description: string;
  children: ReactNode;
}
export function OnboardingStep({
  step,
  title,
  description,
  children
}: OnboardingStepProps) {
  return <div className="w-full max-w-md mx-auto">
      <Card className="border-border/50 shadow-sm">
        <CardHeader className="text-center pb-6">
          
          <CardTitle className="text-xl">{title}</CardTitle>
          <CardDescription className="text-muted-foreground">
            {description}
          </CardDescription>
        </CardHeader>
        <CardContent className="pt-0">
          {children}
        </CardContent>
      </Card>
    </div>;
}