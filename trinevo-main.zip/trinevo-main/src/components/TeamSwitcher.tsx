import { useState } from "react";
import { ChevronDown, Plus, Users } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useTeam } from "@/hooks/useTeam";
import { useAuth } from "@/components/AuthProvider";
import { useSidebar } from "@/components/ui/sidebar";
import { cn } from "@/lib/utils";

export function TeamSwitcher({ className }: { className?: string }) {
  const { team, teamMembers, createTeam } = useTeam();
  const { user } = useAuth();
  const { state } = useSidebar();
  const [isCreating, setIsCreating] = useState(false);
  const isCollapsed = state === "collapsed";

  const handleCreateTeam = async () => {
    if (!user?.user_metadata?.first_name) return;
    
    setIsCreating(true);
    try {
      const teamName = `${user.user_metadata.first_name}'s New Team`;
      await createTeam(teamName);
    } catch (error) {
      console.error('Failed to create team:', error);
    } finally {
      setIsCreating(false);
    }
  };

  const getTeamInitials = (name: string) => {
    return name.split(' ').map(word => word[0]).join('').toUpperCase().slice(0, 2);
  };

  if (!team) {
    return (
      <div className={cn(
        "flex items-center gap-2 p-2 rounded-lg bg-muted/50",
        isCollapsed && "justify-center",
        className
      )}>
        <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center">
          <Users className="h-4 w-4 text-muted-foreground" />
        </div>
        {!isCollapsed && <span className="text-sm text-muted-foreground">Loading team...</span>}
      </div>
    );
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button
          variant="ghost"
          className={cn(
            "w-full h-auto p-2 hover:bg-muted/50",
            isCollapsed ? "justify-center" : "justify-start gap-2",
            className
          )}
          aria-label="Switch team"
        >
          <Avatar className="h-8 w-8 flex-shrink-0">
            <AvatarImage src={team.logo || ''} alt={team.name} />
            <AvatarFallback className="bg-primary text-primary-foreground text-xs">
              {getTeamInitials(team.name)}
            </AvatarFallback>
          </Avatar>
          {!isCollapsed && (
            <>
              <div className="flex-1 text-left min-w-0">
                <p className="text-sm font-medium truncate">{team.name}</p>
                <p className="text-xs text-muted-foreground">
                  {teamMembers.length} member{teamMembers.length !== 1 ? 's' : ''}
                </p>
              </div>
              <ChevronDown className="h-4 w-4 text-muted-foreground" />
            </>
          )}
        </Button>
      </DropdownMenuTrigger>
      
      <DropdownMenuContent align="start" className="w-64">
        <div className="p-2">
          <div className="flex items-center gap-2 p-2 rounded-md bg-muted/50">
            <Avatar className="h-8 w-8">
              <AvatarImage src={team.logo || ''} alt={team.name} />
              <AvatarFallback className="bg-primary text-primary-foreground text-xs">
                {getTeamInitials(team.name)}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium truncate">{team.name}</p>
              <p className="text-xs text-muted-foreground">
                Current team
              </p>
            </div>
          </div>
        </div>
        
        <DropdownMenuSeparator />
        
        <DropdownMenuItem
          onClick={handleCreateTeam}
          disabled={isCreating}
          className="gap-2"
        >
          <Plus className="h-4 w-4" />
          {isCreating ? 'Creating...' : 'Create new team'}
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}