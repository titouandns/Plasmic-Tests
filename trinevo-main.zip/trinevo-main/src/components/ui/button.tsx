import * as React from "react"
import { Slot } from "@radix-ui/react-slot"
import { cva, type VariantProps } from "class-variance-authority"

import { cn } from "@/lib/utils"

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-3 whitespace-nowrap rounded-[18px] text-sm font-normal transition-all duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 [&_svg]:ml-auto [&_svg]:size-4 [&_svg]:shrink-0 [&_svg]:transition-transform [&_svg]:duration-200",
  {
    variants: {
      variant: {
        default: "bg-[#111] text-[#FAFAF7] border-[0.5px] border-[#999] shadow-[0_0.5px_1.25px_-1.16px_rgba(0,0,0,0.1),0_1.8px_4.76px_-2.3px_rgba(0,0,0,0.09),0_8px_20.8px_-3.5px_rgba(0,0,0,0.043),inset_0_-2px_9px_rgba(255,255,255,0.49),0_0_0_2px_rgba(0,0,0,0.2)] hover:bg-[#1A1A1A]",
        destructive: "bg-destructive text-destructive-foreground border-[0.5px] border-destructive hover:bg-destructive/90",
        outline: "inline-flex items-center justify-center border border-gray-500 select-none relative cursor-pointer transition ease-in-out duration-200 bg-transparent text-gray-500 hover:bg-gray-100 hover:text-gray-600 hover:border-gray-600 focus-visible:ring-gray-500/20 focus-visible:ring-2 focus-visible:outline-none h-8 px-3 py-2 rounded-xl gap-1 text-sm disabled:cursor-not-allowed disabled:opacity-70 [&_svg]:text-gray-500 hover:[&_svg]:text-gray-600",
        secondary: "bg-secondary text-secondary-foreground border-[0.5px] border-secondary hover:bg-secondary/80",
        grey: "inline-flex items-center justify-center h-8 rounded-xl px-3 py-2 text-sm bg-gray-100 border border-gray-300 text-gray-900 focus-visible:ring-2 focus-visible:ring-gray-200 transition duration-200 ease-in-out outline-none disabled:opacity-70 disabled:cursor-not-allowed",
        ghost: "hover:bg-muted text-gray-500 border-none hover:text-gray-600 [&_svg]:text-gray-500 hover:[&_svg]:text-gray-600",
        link: "text-primary underline-offset-4 hover:underline border-none",
        light: "bg-white text-black border-[0.5px] border-[#F0ECE7] shadow-[inset_0px_-1px_4px_rgba(0,0,0,0.15)] hover:bg-gray-50",
        dark: "inline-flex items-center justify-center border select-none relative cursor-pointer transition ease-in-out duration-200 bg-black text-white hover:bg-black/90 focus-visible:bg-black/90 focus-visible:ring-black/20 focus-visible:ring-2 focus-visible:outline-none h-8 px-3 py-2 rounded-xl gap-1 text-sm disabled:cursor-not-allowed disabled:opacity-70 dark:bg-white dark:text-black dark:hover:bg-gray-100 dark:focus-visible:ring-gray-300",
      },
      size: {
        default: "h-8 px-3 py-2",
        sm: "h-8 px-4 py-2 text-xs",
        lg: "h-8 px-8 py-2 text-base",
        icon: "h-10 w-10 px-0",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  }
)

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  asChild?: boolean
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, asChild = false, ...props }, ref) => {
    const Comp = asChild ? Slot : "button"
    return (
      <Comp
        className={cn(buttonVariants({ variant, size, className }))}
        ref={ref}
        {...props}
      />
    )
  }
)
Button.displayName = "Button"

export { Button, buttonVariants }
