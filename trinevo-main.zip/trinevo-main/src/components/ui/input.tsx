import * as React from "react"

import { cn } from "@/lib/utils"

const Input = React.forwardRef<HTMLInputElement, React.ComponentProps<"input">>(
  ({ className, type, ...props }, ref) => {
    return (
      <input
        type={type}
        className={cn(
          "flex h-8 w-full rounded-xl px-3 py-2 text-sm bg-gray-100 border border-gray-300 placeholder:text-gray-500 text-gray-500 focus-visible:ring-2 focus-visible:ring-gray-200 transition duration-200 ease-in-out outline-none disabled:opacity-70 disabled:cursor-not-allowed",
          className
        )}
        ref={ref}
        {...props}
      />
    )
  }
)
Input.displayName = "Input"

export { Input }
