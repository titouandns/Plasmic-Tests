import { useToast } from "@/hooks/use-toast"
import { CheckCircle, XCircle } from "lucide-react"
import {
  Toast,
  ToastClose,
  ToastDescription,
  ToastProvider,
  ToastTitle,
  ToastViewport,
} from "@/components/ui/toast"

export function Toaster() {
  const { toasts } = useToast()

  return (
    <ToastProvider>
      {toasts.map(({ id, title, description, action, variant, ...props }) => {
        const Icon =
          variant === "success"
            ? CheckCircle
            : variant === "destructive"
            ? XCircle
            : null

        const message = title || description

        return (
          <Toast key={id} variant={variant} {...props}>
            <div className="flex items-center gap-2 w-full">
              {Icon && <Icon className="h-4 w-4 text-current" />}
              <span className="text-sm font-medium truncate">{message}</span>
            </div>
            {action}
            <ToastClose />
          </Toast>
        )
      })}
      <ToastViewport />
    </ToastProvider>
  )
}
