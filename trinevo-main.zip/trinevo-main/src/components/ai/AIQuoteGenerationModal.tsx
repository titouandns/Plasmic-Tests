import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Loader2, Sparkles, Lightbulb } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface AIQuoteGenerationModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onGenerate: (lineItems: Array<{title: string, description: string, price: number}>) => void;
}

const examples = [
  {
    title: "Website Development",
    description: "Complete e-commerce website with payment integration, user accounts, and admin dashboard"
  },
  {
    title: "Mobile App Development", 
    description: "iOS and Android app for food delivery with real-time tracking, payment processing, and restaurant management"
  },
  {
    title: "Brand Identity Design",
    description: "Complete brand identity including logo, business cards, letterhead, website design, and social media templates"
  },
  {
    title: "Marketing Campaign",
    description: "3-month digital marketing campaign including social media management, Google Ads, content creation, and analytics reporting"
  }
];

export const AIQuoteGenerationModal: React.FC<AIQuoteGenerationModalProps> = ({
  open,
  onOpenChange,
  onGenerate
}) => {
  const [prompt, setPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [streamedText, setStreamedText] = useState('');

  const handleGenerate = async () => {
    if (!prompt.trim()) {
      toast.error('Please describe your project');
      return;
    }

    setIsGenerating(true);
    setStreamedText('');

    try {
      const { data, error } = await supabase.functions.invoke('ai-quote-generation', {
        body: { prompt: prompt.trim() }
      });

      if (error) throw error;

      if (data.lineItems && data.lineItems.length > 0) {
        // Simulate typing animation
        setStreamedText('Generating quote lines...\n\n');
        
        for (let i = 0; i < data.lineItems.length; i++) {
          const item = data.lineItems[i];
          const lineText = `Line ${i + 1}:\n- Title: ${item.title}\n- Description: ${item.description}\n- Price: €${item.price}\n\n`;
          
          // Type out each character with a slight delay
          for (let j = 0; j < lineText.length; j++) {
            await new Promise(resolve => setTimeout(resolve, 20));
            setStreamedText(prev => prev + lineText[j]);
          }
        }

        // Wait a moment then apply the generation
        setTimeout(() => {
          onGenerate(data.lineItems);
          toast.success(`Generated ${data.lineItems.length} quote lines`);
          onOpenChange(false);
          setPrompt('');
          setStreamedText('');
        }, 1000);

      } else {
        throw new Error('No line items generated');
      }

    } catch (error) {
      console.error('AI generation error:', error);
      toast.error(error.message || 'Failed to generate quote. Please try again.');
    } finally {
      setIsGenerating(false);
    }
  };

  const insertExample = (example: typeof examples[0]) => {
    setPrompt(example.description);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Sparkles className="h-5 w-5 text-primary" />
            Generate Quote with AI
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          <div>
            <Label htmlFor="prompt" className="text-sm font-medium">
              Describe your project in detail
            </Label>
            <Textarea
              id="prompt"
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="E.g., I need a complete website redesign for my consulting business. It should include a modern homepage, about page, services section, blog, contact forms, and integration with my CRM system. The design should be professional and mobile-responsive with a focus on lead generation."
              className="min-h-[120px] mt-2"
              disabled={isGenerating}
            />
            <p className="text-xs text-muted-foreground mt-1">
              The more detailed your description, the more accurate the generated quote will be.
            </p>
          </div>

          <div>
            <div className="flex items-center gap-2 mb-3">
              <Lightbulb className="h-4 w-4 text-primary" />
              <span className="text-sm font-medium">Example projects</span>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
              {examples.map((example, index) => (
                <Button
                  key={index}
                  variant="outline"
                  size="sm"
                  className="h-auto p-3 text-left justify-start"
                  onClick={() => insertExample(example)}
                  disabled={isGenerating}
                >
                  <div>
                    <div className="font-medium text-sm">{example.title}</div>
                    <div className="text-xs text-muted-foreground line-clamp-2">
                      {example.description}
                    </div>
                  </div>
                </Button>
              ))}
            </div>
          </div>

          {streamedText && (
            <div className="bg-muted/50 rounded-lg p-4">
              <div className="text-sm font-medium mb-2 flex items-center gap-2">
                <Sparkles className="h-4 w-4 text-primary animate-pulse" />
                AI Generated Quote Lines
              </div>
              <pre className="text-sm whitespace-pre-wrap text-muted-foreground font-mono">
                {streamedText}
              </pre>
            </div>
          )}

          <div className="flex justify-end gap-3">
            <Button
              variant="outline"
              onClick={() => onOpenChange(false)}
              disabled={isGenerating}
            >
              Cancel
            </Button>
            <Button
              onClick={handleGenerate}
              disabled={!prompt.trim() || isGenerating}
              className="min-w-[120px]"
            >
              {isGenerating ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Generating...
                </>
              ) : (
                <>
                  <Sparkles className="h-4 w-4 mr-2" />
                  Generate Quote
                </>
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};