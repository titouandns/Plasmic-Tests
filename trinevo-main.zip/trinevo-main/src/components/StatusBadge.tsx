import { useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";

interface StatusBadgeProps {
  status: string;
  options: string[];
  onChange: (newStatus: string) => Promise<void>;
  editable?: boolean;
  model: string;
  id: string;
  className?: string;
}

const getStatusColor = (status: string, model: string) => {
  // Pastel color scheme for all statuses
  const colorMap: Record<string, Record<string, string>> = {
    customer: {
      active: "bg-[#9ed8b3] text-gray-900",
      inactive: "bg-[#ffc7c7] text-gray-900", 
      lead: "bg-[#fff5ba] text-gray-900"
    },
    project: {
      not_started: "bg-[#e9c6f0] text-gray-900",
      in_progress: "bg-[#b6ccfa] text-gray-900",
      completed: "bg-[#9ed8b3] text-gray-900",
      cancelled: "bg-[#ffc7c7] text-gray-900"
    },
    quote: {
      Saved: "bg-[#e9c6f0] text-gray-900",
      Sent: "bg-[#b6ccfa] text-gray-900",
      Accepted: "bg-[#9ed8b3] text-gray-900",
      Declined: "bg-[#ffc7c7] text-gray-900"
    },
    invoice: {
      draft: "bg-[#e9c6f0] text-gray-900",
      sent: "bg-[#b6ccfa] text-gray-900",
      paid: "bg-[#9ed8b3] text-gray-900",
      cancelled: "bg-[#ffc7c7] text-gray-900"
    },
    task: {
      todo: "bg-[#e9c6f0] text-gray-900",
      in_progress: "bg-[#b6ccfa] text-gray-900",
      done: "bg-[#9ed8b3] text-gray-900"
    }
  };

  return colorMap[model]?.[status] || "bg-[#d9c9f2] text-gray-900";
};

export function StatusBadge({ 
  status, 
  options, 
  onChange, 
  editable = true, 
  model, 
  id,
  className = ""
}: StatusBadgeProps) {
  const [isUpdating, setIsUpdating] = useState(false);

  const handleStatusChange = async (newStatus: string) => {
    if (newStatus === status || isUpdating) return;
    
    setIsUpdating(true);
    try {
      await onChange(newStatus);
      toast.success(`${model} status updated successfully`);
    } catch (error) {
      toast.error(`Failed to update ${model} status`);
      console.error('Status update error:', error);
    } finally {
      setIsUpdating(false);
    }
  };

  const formatDisplayStatus = (status: string) => {
    return status.replace('_', ' ').charAt(0).toUpperCase() + status.slice(1).replace('_', ' ');
  };

  if (!editable) {
    return (
      <Badge 
        className={`rounded-full px-2 py-0.5 text-xs font-medium ${getStatusColor(status, model)} ${className}`}
      >
        {formatDisplayStatus(status)}
      </Badge>
    );
  }

  return (
    <Select 
      value={status} 
      onValueChange={handleStatusChange}
      disabled={isUpdating}
    >
      <SelectTrigger className="h-auto border-none bg-transparent p-0 focus:ring-0 w-auto">
        <SelectValue>
          <Badge 
            className={`rounded-full px-2 py-0.5 text-xs font-medium cursor-pointer hover:opacity-80 transition-opacity ${getStatusColor(status, model)} ${className}`}
          >
            {formatDisplayStatus(status)}
          </Badge>
        </SelectValue>
      </SelectTrigger>
      <SelectContent>
        {options.map((option) => (
          <SelectItem key={option} value={option}>
            <div className="flex items-center gap-2">
              <div 
                className={`w-3 h-3 rounded-full ${getStatusColor(option, model).split(' ')[0]}`}
              />
              {formatDisplayStatus(option)}
            </div>
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}