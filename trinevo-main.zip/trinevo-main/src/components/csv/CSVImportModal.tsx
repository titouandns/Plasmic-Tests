import { useState, useCallback } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useToast } from "@/hooks/use-toast";
import { Upload, Download, FileText, AlertTriangle, CheckCircle, X } from "lucide-react";
import { cn } from "@/lib/utils";
import { parseCSV, validateCustomerRow, generateDemoCSV } from "@/lib/csvUtils";
import type { Tables, TablesInsert } from "@/integrations/supabase/types";

interface CSVImportModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onImportComplete: () => void;
}

type Customer = Tables<'customers'>;
type CustomerInsert = TablesInsert<'customers'>;

interface ParsedCustomer {
  company_name: string;
  contact_name?: string | null;
  email?: string | null;
  phone?: string | null;
  street_address?: string | null;
  city?: string | null;
  postcode?: string | null;
  country?: string | null;
  state_region?: string | null;
  company_number?: string | null;
  tax_number?: string | null;
  status: string;
  notes?: string | null;
  billing_address?: string | null;
  archived: boolean;
  _rowIndex: number;
  _errors: string[];
  _isValid: boolean;
}

export function CSVImportModal({ open, onOpenChange, onImportComplete }: CSVImportModalProps) {
  const [dragActive, setDragActive] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [parsedData, setParsedData] = useState<ParsedCustomer[]>([]);
  const [importing, setImporting] = useState(false);
  const [importProgress, setImportProgress] = useState(0);
  const [step, setStep] = useState<'upload' | 'preview' | 'complete'>('upload');
  const { toast } = useToast();

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    const droppedFile = e.dataTransfer.files[0];
    if (droppedFile?.type === 'text/csv' || droppedFile?.name.endsWith('.csv')) {
      handleFile(droppedFile);
    } else {
      toast({
        variant: "destructive",
        title: "Invalid file type",
        description: "Please upload a CSV file."
      });
    }
  }, [toast]);

  const handleFile = async (selectedFile: File) => {
    setFile(selectedFile);
    
    try {
      const csvText = await selectedFile.text();
      const parsed = parseCSV(csvText);
      const validatedData = parsed.map((row, index) => {
        const validation = validateCustomerRow(row);
        return {
          ...row,
          _rowIndex: index + 1,
          _errors: validation.errors,
          _isValid: validation.isValid
        };
      });
      
      setParsedData(validatedData);
      setStep('preview');
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error parsing CSV",
        description: "There was an error reading the CSV file. Please check the format."
      });
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      handleFile(selectedFile);
    }
  };

  const downloadDemoCSV = () => {
    const csvContent = generateDemoCSV();
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'demo_customers_import_trinevo.csv';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
  };

  const handleImport = async () => {
    const validRows = parsedData.filter(row => row._isValid);
    if (validRows.length === 0) {
      toast({
        variant: "destructive",
        title: "No valid rows",
        description: "Please fix the errors before importing."
      });
      return;
    }

    setImporting(true);
    setImportProgress(0);

    try {
      const { supabase } = await import("@/integrations/supabase/client");
      
      for (let i = 0; i < validRows.length; i++) {
        const row = validRows[i];
        const { _rowIndex, _errors, _isValid, ...customerData } = row;
        
        // Check for existing customer by email
        if (customerData.email) {
          const { data: existing } = await supabase
            .from('customers')
            .select('id')
            .eq('email', customerData.email)
            .maybeSingle();
          
          if (existing) {
            // Skip duplicate
            setImportProgress(((i + 1) / validRows.length) * 100);
            continue;
          }
        }

        // Get current user
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) throw new Error('No authenticated user');

        await supabase
          .from('customers')
          .insert({
            ...customerData,
            user_id: user.id
          } as CustomerInsert);

        setImportProgress(((i + 1) / validRows.length) * 100);
      }

      setStep('complete');
      toast({
        title: "Import successful",
        description: `Successfully imported ${validRows.length} customers.`
      });
      
      setTimeout(() => {
        onImportComplete();
        handleClose();
      }, 2000);
      
    } catch (error) {
      console.error('Import error:', error);
      toast({
        variant: "destructive",
        title: "Import failed",
        description: "There was an error importing the customers."
      });
    } finally {
      setImporting(false);
    }
  };

  const handleClose = () => {
    setFile(null);
    setParsedData([]);
    setStep('upload');
    setImportProgress(0);
    setImporting(false);
    onOpenChange(false);
  };

  const validCount = parsedData.filter(row => row._isValid).length;
  const invalidCount = parsedData.length - validCount;

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Import Customers from CSV</DialogTitle>
        </DialogHeader>

        {step === 'upload' && (
          <div className="space-y-6">
            <div
              className={cn(
                "border-2 border-dashed rounded-lg p-8 text-center transition-colors relative",
                dragActive ? "border-primary bg-primary/5" : "border-muted-foreground/25",
                "hover:border-primary/50"
              )}
              onDragEnter={handleDrag}
              onDragLeave={handleDrag}
              onDragOver={handleDrag}
              onDrop={handleDrop}
            >
              <Upload className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
              <div className="space-y-2">
                <p className="text-lg font-medium">Drop your CSV file here</p>
                <p className="text-sm text-muted-foreground">
                  or click to select a file
                </p>
              </div>
              <input
                type="file"
                accept=".csv"
                onChange={handleFileSelect}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
              />
            </div>

            <div className="flex items-center justify-center">
              <button
                onClick={downloadDemoCSV}
                className="text-primary hover:text-primary/80 underline text-sm font-medium z-20 relative"
              >
                <Download className="mr-2 h-4 w-4 inline" />
                Download Demo CSV Template
              </button>
            </div>
          </div>
        )}

        {step === 'preview' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <Badge variant="outline" className="text-green-600">
                  <CheckCircle className="mr-1 h-3 w-3" />
                  {validCount} valid
                </Badge>
                {invalidCount > 0 && (
                  <Badge variant="outline" className="text-red-600">
                    <AlertTriangle className="mr-1 h-3 w-3" />
                    {invalidCount} invalid
                  </Badge>
                )}
              </div>
              <div className="flex gap-2">
                <Button variant="outline" onClick={() => setStep('upload')}>
                  Back
                </Button>
                <Button 
                  onClick={handleImport} 
                  disabled={validCount === 0 || importing}
                >
                  Import {validCount} Customers
                </Button>
              </div>
            </div>

            {invalidCount > 0 && (
              <Alert>
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription>
                  Some rows have errors and will be skipped. Fix the errors and re-upload to include them.
                </AlertDescription>
              </Alert>
            )}

            <div className="border rounded-lg max-h-96 overflow-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-16">Row</TableHead>
                    <TableHead>Company</TableHead>
                    <TableHead>Contact</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Errors</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {parsedData.map((row, index) => (
                    <TableRow key={index} className={!row._isValid ? "bg-red-50" : ""}>
                      <TableCell>{row._rowIndex}</TableCell>
                      <TableCell>{row.company_name}</TableCell>
                      <TableCell>{row.contact_name}</TableCell>
                      <TableCell>{row.email}</TableCell>
                      <TableCell>{row.status}</TableCell>
                      <TableCell>
                        {row._errors.length > 0 ? (
                          <div className="flex flex-wrap gap-1">
                            {row._errors.map((error, i) => (
                              <Badge key={i} variant="destructive" className="text-xs">
                                {error}
                              </Badge>
                            ))}
                          </div>
                        ) : (
                          <Badge variant="outline" className="text-green-600">
                            <CheckCircle className="mr-1 h-3 w-3" />
                            Valid
                          </Badge>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </div>
        )}

        {step === 'complete' && (
          <div className="text-center space-y-4 py-8">
            <CheckCircle className="mx-auto h-16 w-16 text-green-600" />
            <div>
              <h3 className="text-lg font-semibold">Import Complete!</h3>
              <p className="text-muted-foreground">
                Successfully imported {validCount} customers.
              </p>
            </div>
          </div>
        )}

        {importing && (
          <div className="space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span>Importing customers...</span>
              <span>{Math.round(importProgress)}%</span>
            </div>
            <Progress value={importProgress} />
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}