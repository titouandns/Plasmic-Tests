import { useEffect } from "react";
import { useLocation } from "react-router-dom";
import { SidebarProvider, SidebarTrigger, useSidebar } from "@/components/ui/sidebar";
import { AppSidebar } from "./Sidebar";
import { Header } from "./Header";
import { useAutoTeamCreation } from "@/hooks/useAutoTeamCreation";

interface LayoutProps {
  children: React.ReactNode;
}

function LayoutContent({ children }: LayoutProps) {
  const location = useLocation();
  const { setOpen } = useSidebar();
  
  // Auto-create team for users who don't have one
  useAutoTeamCreation();

  // Auto-collapse sidebar on quote pages
  useEffect(() => {
    const isQuotePage = location.pathname.includes('/quotes/') && 
                       (location.pathname.includes('/new') || location.pathname.includes('/edit'));
    
    if (isQuotePage) {
      setOpen(false);
    }
  }, [location.pathname, setOpen]);

  return (
    <div className="min-h-screen flex w-full bg-gradient-subtle">
      <AppSidebar />
      
      <div className="flex-1 flex flex-col min-w-0">
        <Header />
        
<main
  className={`flex-1 ${
    location.pathname.includes('/quotes/') || location.pathname === '/tasks'
      ? 'p-0'
      : 'p-4 sm:p-6 md:p-8 lg:p-16 xl:p-24'
  }`}
>          <div className={location.pathname.includes('/quotes/') || location.pathname === '/tasks' ? '' : 'mx-auto max-w-7xl'}>
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}

export function Layout({ children }: LayoutProps) {
  return (
    <SidebarProvider defaultOpen={true}>
      <LayoutContent>{children}</LayoutContent>
    </SidebarProvider>
  );
}
