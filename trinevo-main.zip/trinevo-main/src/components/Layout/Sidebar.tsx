import { useState, useEffect, useRef } from "react";
import { NavLink, useLocation } from "react-router-dom";
import {
  DashboardIcon,
  CustomersIcon,
  ProjectsIcon,
  InvoicesIcon,
  QuotesIcon,
  SettingsIcon,
  TasksIcon,
  AnalyticsIcon
} from "@/components/LottieIcon";
import {
  ChevronDown,
  ChevronRight,
  Building2,
  User,
  TrendingUp,
  FileText
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarFooter,
  SidebarTrigger,
  useSidebar,
} from "@/components/ui/sidebar";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { TeamSwitcher } from "@/components/TeamSwitcher";
import { useAuth } from "@/components/AuthProvider";
import { useTeam } from "@/hooks/useTeam";
import { supabase } from "@/integrations/supabase/client";
import trinelogoLogo from "@/assets/trinevo-logo.png";

interface NavItem {
  title: string;
  href: string;
  icon: React.ComponentType<{ className?: string }>;
  iconRef?: React.RefObject<{ play: () => void }>;
  children?: NavItem[];
}

const navigation: NavItem[] = [
  {
    title: "Dashboard",
    href: "/",
    icon: DashboardIcon,
  },
  {
    title: "Customers",
    href: "/customers",
    icon: CustomersIcon,
  },
  {
    title: "Invoicing",
    href: "/invoicing",
    icon: QuotesIcon,
    children: [
      { title: "Quotes", href: "/invoicing/quotes", icon: () => null },
      { title: "Invoices", href: "/invoicing/invoices", icon: () => null },
    ],
  },
  {
    title: "Projects",
    href: "/projects",
    icon: ProjectsIcon,
  },
  {
    title: "Tasks",
    href: "/tasks",
    icon: TasksIcon,
  },
  {
    title: "Analytics",
    href: "/analytics",
    icon: AnalyticsIcon,
  },
  {
    title: "Settings",
    href: "/settings",
    icon: SettingsIcon,
  },
];

export function AppSidebar() {
  const [expandedItems, setExpandedItems] = useState<string[]>(["Invoicing"]);
  const [userProfile, setUserProfile] = useState<any>(null);
  const location = useLocation();
  const { state, open } = useSidebar();
  const { user } = useAuth();
  const { team } = useTeam();

  useEffect(() => {
    if (user) {
      const fetchProfile = async () => {
        const { data } = await supabase
          .from('profiles')
          .select('first_name, last_name, avatar_url')
          .eq('user_id', user.id)
          .single();
        setUserProfile(data);
      };
      fetchProfile();
    }
  }, [user]);

  const toggleExpanded = (title: string) => {
    setExpandedItems(prev =>
      prev.includes(title)
        ? prev.filter(item => item !== title)
        : [...prev, title]
    );
  };

  const isActiveRoute = (href: string) => {
    if (href === "/") return location.pathname === "/";
    return location.pathname.startsWith(href);
  };

  const NavItem = ({ item, level = 0 }: { item: NavItem; level?: number }) => {
    const hasChildren = item.children && item.children.length > 0;
    const isExpanded = expandedItems.includes(item.title);
    const isActive = isActiveRoute(item.href);
    const isCollapsed = state === "collapsed";
    const iconRef = useRef<{ play: () => void }>(null);

    const handleMouseEnter = () => {
      if (iconRef.current) {
        iconRef.current.play();
      }
    };

    const IconComponent = item.icon as any;

    if (hasChildren) {
      return (
        <SidebarMenuItem>
          <SidebarMenuButton
            onClick={() => !isCollapsed && toggleExpanded(item.title)}
            onMouseEnter={handleMouseEnter}
            className={cn(
              "w-full",
              level > 0 && !isCollapsed && "pl-8",
              isActive && "font-semibold",
              isCollapsed && "justify-center px-2"
            )}
            tooltip={isCollapsed ? item.title : undefined}
          >
            <IconComponent ref={iconRef} className="h-5 w-5 flex-shrink-0" />
            {!isCollapsed && (
              <>
                <span>{item.title}</span>
                {isExpanded ? (
                  <ChevronDown className="h-4 w-4 ml-auto" />
                ) : (
                  <ChevronRight className="h-4 w-4 ml-auto" />
                )}
              </>
            )}
          </SidebarMenuButton>
          {!isCollapsed && isExpanded && item.children && (
            <SidebarMenu className="ml-4 space-y-1">
              {item.children.map((child) => (
                <NavItem key={child.href} item={child} level={level + 1} />
              ))}
            </SidebarMenu>
          )}
        </SidebarMenuItem>
      );
    }

    return (
      <SidebarMenuItem>
        <SidebarMenuButton 
          asChild 
          isActive={isActive}
          tooltip={isCollapsed ? item.title : undefined}
          className={cn(
            "hover:bg-muted hover:rounded-xl transition-colors",
            level > 0 && !isCollapsed && "pl-8",
            isCollapsed && "justify-center px-2",
            isActive && "bg-muted rounded-xl"
          )}
        >
          <NavLink to={item.href} onMouseEnter={handleMouseEnter}>
          <IconComponent ref={iconRef} className="h-5 w-5 flex-shrink-0" />
            {!isCollapsed && <span>{item.title}</span>}
          </NavLink>
        </SidebarMenuButton>
      </SidebarMenuItem>
    );
  };

  return (
    <Sidebar 
      collapsible="icon" 
      className="border-r border-border hidden lg:flex"
      side="left"
      variant="sidebar"
    >
      <SidebarHeader className="h-16 border-border p-4">
        {state === "collapsed" ? (
          <div className="flex justify-center items-center h-full">
            <SidebarTrigger className="h-8 w-8" />
          </div>
        ) : (
          <>
            <SidebarTrigger className="absolute top-4 right-4" />
          </>
        )}
      </SidebarHeader>

      <SidebarContent> 
        <SidebarGroup>
          <div className="mb-6">
            <TeamSwitcher />
          </div>
          <SidebarGroupContent>
            <SidebarMenu className="space-y-2">
              {navigation.map((item) => (
                <NavItem key={item.href} item={item} />
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter className="border-t border-border p-4">
        <div className={cn(
          "flex items-center gap-3",
          state === "collapsed" && "justify-center"
        )}>
          <Avatar className="h-8 w-8">
            <AvatarImage src={userProfile?.avatar_url || ''} alt="User avatar" />
            <AvatarFallback className="bg-primary text-primary-foreground text-xs">
              {userProfile?.first_name?.[0] || ''}
              {userProfile?.last_name?.[0] || ''}
            </AvatarFallback>
          </Avatar>
          {state === "expanded" && userProfile && (
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium truncate">
                {userProfile.first_name && userProfile.last_name
                  ? `${userProfile.first_name} ${userProfile.last_name}`
                  : userProfile.first_name || userProfile.last_name || 'User'}
              </p>
              <p className="text-xs text-muted-foreground truncate">
                {user?.email}
              </p>
            </div>
          )}
        </div>
      </SidebarFooter>
    </Sidebar>
  );
}
