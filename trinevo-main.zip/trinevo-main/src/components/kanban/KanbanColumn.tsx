import { useDroppable } from "@dnd-kit/core";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import { cn } from "@/lib/utils";
import { QuickAddTask } from "./QuickAddTask";

interface KanbanColumnProps {
  id: string;
  title: string;
  color: string;
  taskCount: number;
  children: React.ReactNode;
  onAddTask: () => void;
  onQuickAdd?: (title: string) => void;
  quickAddDisabled?: boolean;
}

export function KanbanColumn({ 
  id, 
  title, 
  color, 
  taskCount, 
  children, 
  onAddTask,
  onQuickAdd,
  quickAddDisabled
}: KanbanColumnProps) {
  const { setNodeRef, isOver } = useDroppable({
    id,
  });

  return (
    <div
      ref={setNodeRef}
      className={cn(
        "flex flex-col rounded-lg border-2 border-dashed transition-all duration-300 ease-in-out",
        color,
        isOver && "border-primary bg-primary/10 scale-[1.02] shadow-md"
      )}
    >
      {/* Column Header */}
      <div className="p-4 border-b border-border/50">
        <div className="flex items-center justify-between">
          <h3 className="font-semibold text-sm uppercase tracking-wide text-muted-foreground">
            {title}
          </h3>
          <span className="bg-muted text-muted-foreground text-xs px-2 py-1 rounded-full">
            {taskCount}
          </span>
        </div>
      </div>

      {/* Column Content */}
      <div className={cn(
        "p-4  flex flex-col",
        taskCount > 0 ? "min-h-[200px]" : "min-h-fit"
      )}>
        <div className="space-y-3 flex-1">
          {children}
        </div>
        
        {/* Add Task Button - Always at Bottom */}
        <div className="mt-0">
          {onQuickAdd ? (
            <QuickAddTask 
              onAdd={onQuickAdd} 
              disabled={quickAddDisabled}
            />
          ) : (
            <Button
              variant="ghost"
              size="sm"
              onClick={onAddTask}
              className="w-full justify-start text-muted-foreground hover:text-foreground"
            >
              <Plus className="h-4 w-4 mr-2" />
              Add task
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}
