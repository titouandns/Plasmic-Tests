import { useState } from "react";
import {
  DndContext,
  DragEndEvent,
  DragOverEvent,
  DragStartEvent,
  DragOverlay,
  closestCorners,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
} from "@dnd-kit/core";
import {
  SortableContext,
  sortableKeyboardCoordinates,
  verticalListSortingStrategy,
} from "@dnd-kit/sortable";
import { useTasks, Task } from "@/hooks/useSupabase";
import { KanbanColumn } from "./KanbanColumn";
import { TaskCard } from "./TaskCard";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import { TaskForm } from "@/components/forms/TaskForm";

interface KanbanBoardProps {
  projectId: string;
}

const columns = [
  { id: "todo", title: "To Do", color: "bg-[#f9ebf9] border-[#f1d3f4]" },
  { id: "in_progress", title: "In Progress", color: "bg-[#eff3fe] border-[#d2ddf8]" },
  { id: "done", title: "Done", color: "bg-[#e8f7ec] border-[#c3ecd1]" },
] as const;

export function KanbanBoard({ projectId }: KanbanBoardProps) {
  const { tasks, updateTask, reorderTasks, addTask, loading } = useTasks(projectId);
  const [activeTask, setActiveTask] = useState<Task | null>(null);
  const [showTaskForm, setShowTaskForm] = useState(false);
  const [newTaskStatus, setNewTaskStatus] = useState<"todo" | "in_progress" | "done">("todo");
  const [completedTasks, setCompletedTasks] = useState<Set<string>>(new Set());

  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 8,
      },
    }),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  const getTasksByStatus = (status: string) => {
    return tasks
      .filter(task => task.status === status)
      .sort((a, b) => a.position - b.position);
  };

  const handleDragStart = (event: DragStartEvent) => {
    const { active } = event;
    const task = tasks.find(task => task.id === active.id);
    setActiveTask(task || null);
  };

  const handleDragOver = (event: DragOverEvent) => {
    const { active, over } = event;
    if (!over) return;

    const activeId = active.id as string;
    const overId = over.id as string;

    const activeTask = tasks.find(task => task.id === activeId);
    if (!activeTask) return;

    // If dropping over a column
    if (columns.find(col => col.id === overId)) {
      if (activeTask.status !== overId) {
        // Check if moving to "done" for the first time
        if (overId === "done" && activeTask.status !== "done") {
          setCompletedTasks(prev => new Set([...prev, activeId]));
        }
        updateTask(activeId, { status: overId as "todo" | "in_progress" | "done" });
      }
      return;
    }

    // If dropping over another task
    const overTask = tasks.find(task => task.id === overId);
    if (!overTask) return;

    if (activeTask.status !== overTask.status) {
      // Check if moving to "done" for the first time
      if (overTask.status === "done" && activeTask.status !== "done") {
        setCompletedTasks(prev => new Set([...prev, activeId]));
      }
      updateTask(activeId, { status: overTask.status });
    }
  };

  const handleDragEnd = (event: DragEndEvent) => {
    setActiveTask(null);
    
    const { active, over } = event;
    if (!over) return;

    const activeId = active.id as string;
    const overId = over.id as string;

    const activeTask = tasks.find(task => task.id === activeId);
    if (!activeTask) return;

    // If dropped over a task, reorder within the column
    if (!columns.find(col => col.id === overId)) {
      const overTask = tasks.find(task => task.id === overId);
      if (overTask && activeTask.status === overTask.status) {
        const tasksInColumn = getTasksByStatus(activeTask.status);
        const oldIndex = tasksInColumn.findIndex(task => task.id === activeId);
        const newIndex = tasksInColumn.findIndex(task => task.id === overId);

        if (oldIndex !== newIndex) {
          const reorderedTasks = [...tasksInColumn];
          const [movedTask] = reorderedTasks.splice(oldIndex, 1);
          reorderedTasks.splice(newIndex, 0, movedTask);

          // Update positions
          const updatedTasks = reorderedTasks.map((task, index) => ({
            ...task,
            position: index,
          }));

          reorderTasks(updatedTasks);
        }
      }
    }
  };

  const handleAddTask = (status: "todo" | "in_progress" | "done") => {
    setNewTaskStatus(status);
    setShowTaskForm(true);
  };

  const handleQuickAdd = async (status: "todo" | "in_progress" | "done", title: string) => {
    const columnTasks = getTasksByStatus(status);
    const newPosition = columnTasks.length;
    
    const newTask = {
      project_id: projectId,
      title,
      description: "",
      status,
      priority: "medium" as const,
      position: newPosition,
    };

    await addTask(newTask);
  };

  return (
    <div className="w-full">
      <DndContext
        sensors={sensors}
        collisionDetection={closestCorners}
        onDragStart={handleDragStart}
        onDragOver={handleDragOver}
        onDragEnd={handleDragEnd}
      >
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {columns.map((column) => {
            const columnTasks = getTasksByStatus(column.id);
            return (
              <div key={column.id} className="flex flex-col">
                <KanbanColumn
                  id={column.id}
                  title={column.title}
                  color={column.color}
                  taskCount={columnTasks.length}
                  onAddTask={() => handleAddTask(column.id)}
                  onQuickAdd={(title) => handleQuickAdd(column.id, title)}
                  quickAddDisabled={loading}
                >
                  <SortableContext
                    items={columnTasks.map(task => task.id)}
                    strategy={verticalListSortingStrategy}
                  >
                    <div className="space-y-3 flex-1">
                      {columnTasks.map((task) => (
                        <TaskCard
                          key={task.id}
                          task={task}
                          isActive={activeTask?.id === task.id}
                          isJustCompleted={completedTasks.has(task.id)}
                          onEditTitle={(taskId, newTitle) => updateTask(taskId, { title: newTitle })}
                          onUpdate={(taskId, updates) => updateTask(taskId, updates)}
                          onAnimationComplete={() => setCompletedTasks(prev => {
                            const newSet = new Set(prev);
                            newSet.delete(task.id);
                            return newSet;
                          })}
                        />
                      ))}
                    </div>
                  </SortableContext>
                </KanbanColumn>
              </div>
            );
          })}
        </div>

        <DragOverlay>
          {activeTask && (
            <div className="rotate-2 scale-105">
              <TaskCard 
                task={activeTask} 
                onEditTitle={(taskId, newTitle) => updateTask(taskId, { title: newTitle })}
                onUpdate={(taskId, updates) => updateTask(taskId, updates)}
              />
            </div>
          )}
        </DragOverlay>
      </DndContext>

      <TaskForm
        open={showTaskForm}
        onOpenChange={setShowTaskForm}
        projectId={projectId}
        defaultStatus={newTaskStatus}
      />
    </div>
  );
}
