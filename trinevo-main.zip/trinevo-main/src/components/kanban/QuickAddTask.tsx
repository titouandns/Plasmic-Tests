import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Plus, X, Check } from "lucide-react";
import { cn } from "@/lib/utils";

interface QuickAddTaskProps {
  onAdd: (title: string) => void;
  disabled?: boolean;
}

export function QuickAddTask({ onAdd, disabled }: QuickAddTaskProps) {
  const [isAdding, setIsAdding] = useState(false);
  const [title, setTitle] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (title.trim()) {
      onAdd(title.trim());
      setTitle("");
      setIsAdding(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      if (title.trim()) {
        onAdd(title.trim());
        setTitle("");
        setIsAdding(false);
      }
    } else if (e.key === 'Escape') {
      handleCancel();
    }
  };

  const handleCancel = () => {
    setTitle("");
    setIsAdding(false);
  };

  if (isAdding) {
    return (
      <div className="relative">
        <Input
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Enter task title..."
          className="text-sm pr-8"
          autoFocus
          disabled={disabled}
          onBlur={() => {
            if (title.trim()) {
              onAdd(title.trim());
              setTitle("");
            }
            setIsAdding(false);
          }}
        />
        <Button 
          type="button" 
          variant="ghost" 
          size="sm" 
          onClick={handleCancel}
          disabled={disabled}
          className="absolute right-1 top-1/2 -translate-y-1/2 h-6 w-6 p-0 hover:bg-muted"
        >
          <X className="h-3 w-3" />
        </Button>
      </div>
    );
  }

  return (
    <Button
      variant="ghost"
      size="sm"
      onClick={() => setIsAdding(true)}
      disabled={disabled}
      className={cn(
        "justify-start text-left text-muted-foreground hover:text-foreground",
        "border border-dashed border-transparent hover:border-border",
        "transition-all duration-200"
      )}
    >
      <Plus className="h-4 w-4 mr-2" />
      Add task
    </Button>
  );
}
