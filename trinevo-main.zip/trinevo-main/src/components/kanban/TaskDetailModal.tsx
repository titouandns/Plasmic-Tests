import { useState, useEffect } from "react";
import { format, parseISO, isValid } from "date-fns";
import { Calendar, User, Palette, CheckSquare2, Square, Plus, X } from "lucide-react";

import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Calendar as CalendarComponent } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Task } from "@/hooks/useSupabase";
import { useTeam } from "@/hooks/useTeam";
import { cn } from "@/lib/utils";
import { TASK_COLORS, TaskColorKey, getTaskColor } from "@/lib/taskColors";

interface ChecklistItem {
  id: string;
  text: string;
  completed: boolean;
}

interface TaskDetailModalProps {
  task: Task & {
    color_tag?: string;
    assigned_to?: string;
    assigned_user?: { first_name?: string; last_name?: string; avatar_url?: string };
    checklist?: ChecklistItem[];
  };
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onUpdate?: (updates: Partial<Task>) => void;
}

export function TaskDetailModal({ task, open, onOpenChange, onUpdate }: TaskDetailModalProps) {
  const [title, setTitle] = useState(task.title);
  const [description, setDescription] = useState(task.description || "");
  const [colorTag, setColorTag] = useState<TaskColorKey>(task.color_tag as TaskColorKey || 'gray');
  const [dueDate, setDueDate] = useState<Date | undefined>(
    task.due_date ? parseISO(task.due_date) : undefined
  );
  const [checklist, setChecklist] = useState<ChecklistItem[]>(task.checklist || []);
  const [newChecklistItem, setNewChecklistItem] = useState("");
  const [assignedTo, setAssignedTo] = useState<string | undefined>(task.assigned_to);
  
  const { teamMembers } = useTeam();

  // Auto-save effect
  useEffect(() => {
    if (!open) return;

    const timeoutId = setTimeout(() => {
      const updates: Partial<Task> = {};
      let hasChanges = false;

      if (title !== task.title) {
        updates.title = title;
        hasChanges = true;
      }
      
      if (description !== (task.description || "")) {
        updates.description = description;
        hasChanges = true;
      }

      if (colorTag !== (task.color_tag || 'gray')) {
        (updates as any).color_tag = colorTag;
        hasChanges = true;
      }

      if (dueDate !== (task.due_date ? parseISO(task.due_date) : undefined)) {
        updates.due_date = dueDate ? dueDate.toISOString() : null;
        hasChanges = true;
      }

      if (JSON.stringify(checklist) !== JSON.stringify(task.checklist || [])) {
        (updates as any).checklist = checklist;
        hasChanges = true;
      }

      if (assignedTo !== task.assigned_to) {
        (updates as any).assigned_to = assignedTo;
        hasChanges = true;
      }

      if (hasChanges && onUpdate) {
        onUpdate(updates);
      }
    }, 500);

    return () => clearTimeout(timeoutId);
  }, [title, description, colorTag, dueDate, checklist, assignedTo, task, onUpdate, open]);

  const addChecklistItem = () => {
    if (newChecklistItem.trim()) {
      setChecklist(prev => [...prev, {
        id: Date.now().toString(),
        text: newChecklistItem.trim(),
        completed: false
      }]);
      setNewChecklistItem("");
    }
  };

  const toggleChecklistItem = (id: string) => {
    setChecklist(prev => prev.map(item => 
      item.id === id ? { ...item, completed: !item.completed } : item
    ));
  };

  const removeChecklistItem = (id: string) => {
    setChecklist(prev => prev.filter(item => item.id !== id));
  };

  const updateChecklistItem = (id: string, text: string) => {
    setChecklist(prev => prev.map(item => 
      item.id === id ? { ...item, text } : item
    ));
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle className="sr-only">Task Details</DialogTitle>
        </DialogHeader>

        <div className="flex-1 overflow-y-auto space-y-6 pr-2">
          {/* Title */}
          <div>
            <Input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="text-lg font-medium border-none p-0 h-auto bg-transparent focus-visible:ring-0 focus-visible:ring-offset-0"
              placeholder="Task title..."
            />
          </div>

          {/* Properties Row */}
          <div className="flex flex-wrap gap-4">
            {/* Color Tag */}
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" size="sm" className="gap-2">
                  <div className={cn("w-3 h-3 rounded-full", getTaskColor(colorTag).dot)} />
                  <Palette className="h-4 w-4" />
                  Color
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-2">
                <div className="grid grid-cols-3 gap-2">
                  {Object.entries(TASK_COLORS).map(([key, color]) => (
                    <Button
                      key={key}
                      variant="ghost"
                      size="sm"
                      className="gap-2 justify-start"
                      onClick={() => setColorTag(key as TaskColorKey)}
                    >
                      <div className={cn("w-3 h-3 rounded-full", color.dot)} />
                      {color.name}
                    </Button>
                  ))}
                </div>
              </PopoverContent>
            </Popover>

            {/* Due Date */}
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" size="sm" className="gap-2">
                  <Calendar className="h-4 w-4" />
                  {dueDate ? format(dueDate, "MMM d, yyyy") : "Add due date"}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0">
                <CalendarComponent
                  mode="single"
                  selected={dueDate}
                  onSelect={setDueDate}
                  className="pointer-events-auto"
                />
              </PopoverContent>
            </Popover>

            {/* Assignee */}
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" size="sm" className="gap-2">
                  <User className="h-4 w-4" />
                  {assignedTo ? (
                    teamMembers?.find(m => m.user_id === assignedTo)?.profiles ? 
                      `${teamMembers.find(m => m.user_id === assignedTo)?.profiles?.first_name || 'Member'}` :
                      'Assigned'
                  ) : 'Assign member'}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-2">
                <div className="space-y-1">
                  <Button
                    variant="ghost"
                    size="sm"
                    className="w-full justify-start"
                    onClick={() => setAssignedTo(undefined)}
                  >
                    <X className="h-4 w-4 mr-2" />
                    Unassign
                  </Button>
                  {teamMembers?.map((member) => (
                    <Button
                      key={member.user_id}
                      variant="ghost"
                      size="sm"
                      className="w-full justify-start gap-2"
                      onClick={() => setAssignedTo(member.user_id)}
                    >
                      <Avatar className="h-6 w-6">
                        <AvatarImage src={member.profiles?.avatar_url} />
                        <AvatarFallback className="text-xs">
                          {member.profiles?.first_name?.[0] || member.profiles?.last_name?.[0] || 'M'}
                        </AvatarFallback>
                      </Avatar>
                      {member.profiles?.first_name} {member.profiles?.last_name}
                    </Button>
                  ))}
                </div>
              </PopoverContent>
            </Popover>
          </div>

          {/* Description */}
          <div>
            <Textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Add a description..."
              className="min-h-[100px] border-border/50"
            />
          </div>

          {/* Checklist */}
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <CheckSquare2 className="h-4 w-4" />
              <span className="font-medium">Checklist</span>
              {checklist.length > 0 && (
                <span className="text-sm text-muted-foreground">
                  {checklist.filter(item => item.completed).length}/{checklist.length}
                </span>
              )}
            </div>

            <div className="space-y-2">
              {checklist.map((item) => (
                <div key={item.id} className="flex items-center gap-2 group">
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-6 w-6 p-0"
                    onClick={() => toggleChecklistItem(item.id)}
                  >
                    {item.completed ? (
                      <CheckSquare2 className="h-4 w-4 text-green-600" />
                    ) : (
                      <Square className="h-4 w-4" />
                    )}
                  </Button>
                  <Input
                    value={item.text}
                    onChange={(e) => updateChecklistItem(item.id, e.target.value)}
                    className="h-6 text-sm border-none bg-transparent p-0 focus-visible:ring-0 focus-visible:ring-offset-0"
                    style={{ textDecoration: item.completed ? 'line-through' : 'none' }}
                  />
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-6 w-6 p-0 opacity-0 group-hover:opacity-100"
                    onClick={() => removeChecklistItem(item.id)}
                  >
                    <X className="h-3 w-3" />
                  </Button>
                </div>
              ))}

              {/* Add new checklist item */}
              <div className="flex items-center gap-2">
                <Square className="h-4 w-4 text-muted-foreground" />
                <Input
                  value={newChecklistItem}
                  onChange={(e) => setNewChecklistItem(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && addChecklistItem()}
                  placeholder="Add checklist item..."
                  className="h-6 text-sm border-none bg-transparent p-0 focus-visible:ring-0 focus-visible:ring-offset-0"
                />
                {newChecklistItem.trim() && (
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-6 w-6 p-0"
                    onClick={addChecklistItem}
                  >
                    <Plus className="h-3 w-3" />
                  </Button>
                )}
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}