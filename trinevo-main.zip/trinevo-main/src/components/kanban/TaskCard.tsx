import { useState, useEffect } from "react";
import { useSortable } from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Task } from "@/hooks/useSupabase";
import { cn } from "@/lib/utils";
import { getTaskColor } from "@/lib/taskColors";
import { TaskDetailModal } from "./TaskDetailModal";
import { format, isValid, parseISO } from "date-fns";
import { Pencil, CheckSquare, Calendar, User } from "lucide-react";

interface TaskCardProps {
  task: Task & {
    color_tag?: string;
    assigned_to?: string;
    assigned_user?: { first_name?: string; last_name?: string; avatar_url?: string };
    checklist?: Array<{ id: string; text: string; completed: boolean }>;
  };
  isActive?: boolean;
  isJustCompleted?: boolean;
  onEditTitle?: (taskId: string, newTitle: string) => void;
  onUpdate?: (taskId: string, updates: any) => void;
  onAnimationComplete?: () => void;
}

export function TaskCard({ 
  task, 
  isActive = false, 
  isJustCompleted = false,
  onEditTitle, 
  onUpdate,
  onAnimationComplete
}: TaskCardProps) {
  const [showDetail, setShowDetail] = useState(false);
  const [isHovered, setIsHovered] = useState(false);
  const [isEditingTitle, setIsEditingTitle] = useState(false);
  const [editedTitle, setEditedTitle] = useState(task.title);
  const [showConfetti, setShowConfetti] = useState(false);
  
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({
    id: task.id,
  });

  // Handle completion animation
  useEffect(() => {
    if (isJustCompleted && task.status === "done") {
      setShowConfetti(true);
      
      // Play completion sound (optional)
      try {
        const audio = new Audio('data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmAZFjaKy/3KgC8GKWs=');
        audio.volume = 0.1;
        audio.play().catch(() => {}); // Ignore audio errors
      } catch {}

      // Clear confetti after animation
      const timer = setTimeout(() => {
        setShowConfetti(false);
        onAnimationComplete?.();
      }, 1500);

      return () => clearTimeout(timer);
    }
  }, [isJustCompleted, task.status, onAnimationComplete]);

  const style = {
    transform: CSS.Transform.toString(transform),
    transition: isDragging ? undefined : transition,
  };

  const taskColor = getTaskColor(task.color_tag);
  
  // Calculate checklist progress
  const checklistProgress = task.checklist 
    ? { completed: task.checklist.filter(item => item.completed).length, total: task.checklist.length }
    : null;

  // Format due date
  const dueDate = task.due_date ? (() => {
    try {
      const date = parseISO(task.due_date);
      return isValid(date) ? format(date, "MMM d") : null;
    } catch {
      return null;
    }
  })() : null;

  const handleCardClick = (e: React.MouseEvent) => {
    if (isDragging || isEditingTitle) return;
    e.stopPropagation();
    setShowDetail(true);
  };

  const handleEditClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsEditingTitle(true);
  };

  const handleTitleSubmit = () => {
    if (editedTitle.trim() && editedTitle !== task.title && onEditTitle) {
      onEditTitle(task.id, editedTitle.trim());
    }
    setIsEditingTitle(false);
    setEditedTitle(task.title);
  };

  const handleTitleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleTitleSubmit();
    } else if (e.key === 'Escape') {
      setIsEditingTitle(false);
      setEditedTitle(task.title);
    }
  };

  return (
    <>
      <div className="relative">
        {/* Confetti Effect */}
        {showConfetti && (
          <div className="absolute inset-0 pointer-events-none z-10">
            {[...Array(12)].map((_, i) => (
              <div
                key={i}
                className={cn(
                  "absolute w-2 h-2 rounded-full animate-ping",
                  "bg-gradient-to-r from-blue-400 to-purple-400",
                  "opacity-70"
                )}
                style={{
                  left: `${20 + Math.random() * 60}%`,
                  top: `${20 + Math.random() * 60}%`,
                  animationDelay: `${Math.random() * 0.5}s`,
                  animationDuration: `${0.8 + Math.random() * 0.4}s`,
                }}
              />
            ))}
          </div>
        )}

        <Card
          ref={setNodeRef}
          style={style}
          className={cn(
            "cursor-grab active:cursor-grabbing group relative",
            "hover:shadow-md border-border/50 transition-all duration-200 ease-in-out",
            isDragging && "opacity-50 rotate-2 scale-105 shadow-xl z-50 border-primary/50",
            isActive && "ring-2 ring-primary ring-offset-2",
            !isDragging && "hover:scale-[1.02]",
            isJustCompleted && task.status === "done" && [
              "animate-[completion-bounce_0.6s_ease-out]",
              "shadow-[0_0_20px_rgba(34,197,94,0.4)]",
              "ring-2 ring-green-400/50"
            ]
          )}
          {...attributes}
          {...listeners}
          onClick={handleCardClick}
          onMouseEnter={() => setIsHovered(true)}
          onMouseLeave={() => setIsHovered(false)}
        >
          <CardContent className="p-3">
            <div className="space-y-2">
              {/* Color Tag Pill */}
              {task.color_tag && (
                <div className={cn("w-4 h-2 rounded-full", taskColor.dot)} />
              )}
              
              {/* Title Section */}
              <div className="flex items-start justify-between gap-2">
                {isEditingTitle ? (
                  <input
                    type="text"
                    value={editedTitle}
                    onChange={(e) => setEditedTitle(e.target.value)}
                    onBlur={handleTitleSubmit}
                    onKeyDown={handleTitleKeyDown}
                    className="flex-1 text-sm font-normal bg-transparent border-none outline-none resize-none"
                    autoFocus
                    onClick={(e) => e.stopPropagation()}
                  />
                ) : (
                  <h4 className="font-normal text-sm leading-tight text-foreground flex-1">
                    {task.title}
                  </h4>
                )}
                
                {/* Edit Button - Show on Hover */}
                {isHovered && !isDragging && !isEditingTitle && (
                  <Button
                    size="sm"
                    variant="ghost"
                    className="opacity-0 group-hover:opacity-100 transition-opacity h-6 w-6 p-0"
                    onClick={handleEditClick}
                  >
                    <Pencil className="h-3 w-3" />
                  </Button>
                )}
              </div>

              {/* Metadata Row */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  {/* Checklist Progress */}
                  {checklistProgress && checklistProgress.total > 0 && (
                    <Badge variant="secondary" className="text-xs px-1.5 py-0.5 h-5">
                      <CheckSquare className="h-3 w-3 mr-1" />
                      {checklistProgress.completed}/{checklistProgress.total}
                    </Badge>
                  )}
                  
                  {/* Due Date */}
                  {dueDate && (
                    <Badge variant="outline" className="text-xs px-1.5 py-0.5 h-5">
                      <Calendar className="h-3 w-3 mr-1" />
                      {dueDate}
                    </Badge>
                  )}
                </div>

                {/* Assigned User Avatar */}
                {task.assigned_user && (
                  <Avatar className="h-5 w-5">
                    <AvatarImage src={task.assigned_user.avatar_url} />
                    <AvatarFallback className="text-xs">
                      {task.assigned_user.first_name?.charAt(0)?.toUpperCase() || 
                       task.assigned_user.last_name?.charAt(0)?.toUpperCase() || 
                       <User className="h-3 w-3" />}
                    </AvatarFallback>
                  </Avatar>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <TaskDetailModal
        task={task}
        open={showDetail}
        onOpenChange={setShowDetail}
        onUpdate={(updates) => onUpdate?.(task.id, updates)}
      />
    </>
  );
}