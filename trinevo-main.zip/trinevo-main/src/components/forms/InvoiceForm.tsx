import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useInvoices } from "@/hooks/useInvoices";
import { useCustomers } from "@/hooks/useSupabase";
import { CustomerSearchSelect } from "@/components/CustomerSearchSelect";

const invoiceSchema = z.object({
  client_id: z.string().min(1, "Customer is required"),
  invoice_number: z.string().min(1, "Invoice number is required"),
  issue_date: z.string().min(1, "Issue date is required"),
  due_date: z.string().optional(),
  subtotal: z.number().min(0, "Subtotal must be positive"),
  total: z.number().min(0, "Total must be positive"),
  currency: z.string().default("EUR"),
  status: z.string().default("draft"),
  notes: z.string().optional(),
});

type InvoiceFormData = z.infer<typeof invoiceSchema>;

interface InvoiceFormProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function InvoiceForm({ open, onOpenChange }: InvoiceFormProps) {
  const { addInvoice } = useInvoices();
  const { customers } = useCustomers();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const form = useForm<InvoiceFormData>({
    resolver: zodResolver(invoiceSchema),
    defaultValues: {
      client_id: "",
      invoice_number: `INV-${Date.now().toString().slice(-6)}`,
      issue_date: new Date().toISOString().split('T')[0],
      due_date: "",
      subtotal: 0,
      total: 0,
      currency: "EUR",
      status: "draft",
      notes: "",
    },
  });

  const onSubmit = async (data: InvoiceFormData) => {
    try {
      setIsSubmitting(true);
      // Convert form data to required Invoice format
      const invoiceData = {
        invoice_number: data.invoice_number!,
        client_id: data.client_id!,
        subtotal: data.subtotal,
        total: data.total,
        currency: data.currency,
        status: data.status,
        type: 'normal', // Default type
        notes: data.notes || undefined,
        due_date: data.due_date || undefined,
        issue_date: data.issue_date!,
      };
      await addInvoice(invoiceData);
      form.reset();
      onOpenChange(false);
    } catch (error) {
      console.error('Error creating invoice:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle>Create New Invoice</DialogTitle>
        </DialogHeader>
        
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="invoice_number">Invoice Number</Label>
              <Input
                id="invoice_number"
                {...form.register("invoice_number")}
              />
              {form.formState.errors.invoice_number && (
                <p className="text-sm text-destructive">{form.formState.errors.invoice_number.message}</p>
              )}
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="currency">Currency</Label>
              <Select value={form.watch("currency")} onValueChange={(value) => form.setValue("currency", value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="EUR">EUR (€)</SelectItem>
                  <SelectItem value="USD">USD ($)</SelectItem>
                  <SelectItem value="GBP">GBP (£)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="client_id">Customer</Label>
            <CustomerSearchSelect
              customers={customers}
              selectedCustomerId={form.watch("client_id")}
              onSelect={(customer) => form.setValue("client_id", customer.id)}
              onCreateNew={() => {}}
              placeholder="Select a customer..."
            />
            {form.formState.errors.client_id && (
              <p className="text-sm text-destructive">{form.formState.errors.client_id.message}</p>
            )}
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="issue_date">Issue Date</Label>
              <Input
                id="issue_date"
                type="date"
                {...form.register("issue_date")}
              />
              {form.formState.errors.issue_date && (
                <p className="text-sm text-destructive">{form.formState.errors.issue_date.message}</p>
              )}
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="due_date">Due Date</Label>
              <Input
                id="due_date"
                type="date"
                {...form.register("due_date")}
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="status">Status</Label>
            <Select value={form.watch("status")} onValueChange={(value) => form.setValue("status", value)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="draft">Draft</SelectItem>
                <SelectItem value="sent">Sent</SelectItem>
                <SelectItem value="paid">Paid</SelectItem>
                <SelectItem value="cancelled">Cancelled</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="notes">Notes</Label>
            <Textarea
              id="notes"
              placeholder="Additional notes for this invoice..."
              {...form.register("notes")}
            />
          </div>

          <div className="flex justify-end space-x-2 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
            >
              Cancel
            </Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting ? "Creating..." : "Create Invoice"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}