import { useState, useEffect, useRef } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Plus, ChevronDown } from "lucide-react";
import { cn } from "@/lib/utils";

interface Customer {
  id: string;
  company_name: string;
  contact_name?: string;
  email?: string;
  phone?: string;
  billing_address?: string;
  street_address?: string;
  city?: string;
  postcode?: string;
  country?: string;
}

interface CustomerSearchSelectProps {
  customers: Customer[];
  selectedCustomerId?: string;
  onSelect: (customer: Customer) => void;
  onCreateNew: () => void;
  placeholder?: string;
  className?: string;
}

export function CustomerSearchSelect({
  customers,
  selectedCustomerId,
  onSelect,
  onCreateNew,
  placeholder = "Search customers...",
  className
}: CustomerSearchSelectProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [isOpen, setIsOpen] = useState(false);
  const [displayValue, setDisplayValue] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);
  const dropdownRef = useRef<HTMLDivElement>(null);

  const selectedCustomer = customers.find(c => c.id === selectedCustomerId);

  useEffect(() => {
    if (selectedCustomer) {
      setDisplayValue(selectedCustomer.contact_name || selectedCustomer.company_name || "");
      setSearchTerm("");
    }
  }, [selectedCustomer]);

  const filteredCustomers = customers.filter(customer =>
    customer.company_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    customer.contact_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    customer.email?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleInputChange = (value: string) => {
    setSearchTerm(value);
    setDisplayValue(value);
    setIsOpen(true);
  };

  const handleSelect = (customer: Customer) => {
    onSelect(customer);
    setDisplayValue(customer.contact_name || customer.company_name || "");
    setSearchTerm("");
    setIsOpen(false);
  };

  const handleFocus = () => {
    setIsOpen(true);
    setSearchTerm(displayValue);
    setDisplayValue("");
  };

  const handleBlur = () => {
    setTimeout(() => {
      setIsOpen(false);
      if (selectedCustomer) {
        setDisplayValue(selectedCustomer.contact_name || selectedCustomer.company_name || "");
      }
      setSearchTerm("");
    }, 200);
  };

  return (
    <div className={cn("relative", className)}>
      <div className="relative">
        <Input
          ref={inputRef}
          value={isOpen ? searchTerm : displayValue}
          onChange={(e) => handleInputChange(e.target.value)}
          onFocus={handleFocus}
          onBlur={handleBlur}
          placeholder={placeholder}
          className="pr-8"
        />
        <ChevronDown className="absolute right-2 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
      </div>

      {isOpen && (
        <div
          ref={dropdownRef}
          className="absolute z-50 w-full mt-1 bg-background border border-border rounded-md shadow-lg max-h-60 overflow-auto"
        >
          {filteredCustomers.length > 0 ? (
            <>
              {filteredCustomers.map((customer) => (
                <div
                  key={customer.id}
                  className="p-3 hover:bg-muted cursor-pointer border-b border-border/50 last:border-b-0"
                  onClick={() => handleSelect(customer)}
                >
                  <div className="font-medium text-sm">
                    {customer.contact_name || "No contact name"}
                  </div>
                  <div className="text-sm text-muted-foreground">
                    {customer.company_name}
                  </div>
                  {customer.email && (
                    <div className="text-xs text-muted-foreground">
                      {customer.email}
                    </div>
                  )}
                </div>
              ))}
              <div 
                className="p-3 hover:bg-muted cursor-pointer text-primary font-medium flex items-center border-t border-border/50"
                onClick={onCreateNew}
              >
                <Plus className="h-4 w-4 mr-2" />
                Create new customer
              </div>
            </>
          ) : (
            <div className="p-3">
              <div className="text-sm text-muted-foreground mb-2">
                No customers found
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={onCreateNew}
                className="w-full"
              >
                <Plus className="h-4 w-4 mr-2" />
                Create new customer
              </Button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}