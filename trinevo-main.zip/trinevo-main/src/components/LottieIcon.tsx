import { useRef, forwardRef, useImperativeHandle } from "react"
import Lottie from "lottie-react"
import dashboardAnimation from "@/lotties/dashboard.json"
import customersAnimation from "@/lotties/customers.json"
import projectsAnimation from "@/lotties/projects.json"
import invoicesAnimation from "@/lotties/invoices.json"
import quotesAnimation from "@/lotties/quotes.json"
import settingsAnimation from "@/lotties/settings.json"
import tasksAnimation from "@/lotties/tasks.json"
import analyticsAnimation from "@/lotties/analytics.json"
import searchAnimation from "@/lotties/search.json"

interface AnimatedIconRef {
  play: () => void;
}

const AnimatedIcon = forwardRef<AnimatedIconRef, { animation: object; delay?: number; onHover?: boolean }>(({ animation, delay = 0, onHover = false }, ref) => {
  const lottieRef = useRef<any>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  useImperativeHandle(ref, () => ({
    play: () => {
      if (lottieRef.current) {
        setTimeout(() => {
          lottieRef.current.stop();
          lottieRef.current.play();
        }, delay);
      }
    }
  }));

  const handleMouseEnter = () => {
    if (onHover && lottieRef.current) {
      setTimeout(() => {
        lottieRef.current.stop();
        lottieRef.current.play();
      }, delay);
    }
  };

  return (
    <div 
      ref={containerRef}
      onMouseEnter={handleMouseEnter}
      className="h-5 w-5"
    >
      <Lottie
        lottieRef={lottieRef}
        animationData={animation}
        loop={false}
        autoplay={false}
        className="h-full w-full"
      />
    </div>
  );
});

AnimatedIcon.displayName = "AnimatedIcon";

export const DashboardIcon = forwardRef<AnimatedIconRef, { className?: string; delay?: number; onHover?: boolean }>((props, ref) => <AnimatedIcon ref={ref} animation={dashboardAnimation} delay={props.delay || 100} onHover={props.onHover} />);
export const CustomersIcon = forwardRef<AnimatedIconRef, { className?: string; delay?: number; onHover?: boolean }>((props, ref) => <AnimatedIcon ref={ref} animation={customersAnimation} delay={props.delay || 100} onHover={props.onHover} />);
export const ProjectsIcon = forwardRef<AnimatedIconRef, { className?: string; delay?: number; onHover?: boolean }>((props, ref) => <AnimatedIcon ref={ref} animation={projectsAnimation} delay={props.delay || 100} onHover={props.onHover} />);
export const InvoicesIcon = forwardRef<AnimatedIconRef, { className?: string; delay?: number; onHover?: boolean }>((props, ref) => <AnimatedIcon ref={ref} animation={invoicesAnimation} delay={props.delay || 100} onHover={props.onHover} />);
export const QuotesIcon = forwardRef<AnimatedIconRef, { className?: string; delay?: number; onHover?: boolean }>((props, ref) => <AnimatedIcon ref={ref} animation={quotesAnimation} delay={props.delay || 100} onHover={props.onHover} />);
export const SettingsIcon = forwardRef<AnimatedIconRef, { className?: string; delay?: number; onHover?: boolean }>((props, ref) => <AnimatedIcon ref={ref} animation={settingsAnimation} delay={props.delay || 100} onHover={props.onHover} />);
export const TasksIcon = forwardRef<AnimatedIconRef, { className?: string; delay?: number; onHover?: boolean }>((props, ref) => <AnimatedIcon ref={ref} animation={tasksAnimation} delay={props.delay || 100} onHover={props.onHover} />);
export const AnalyticsIcon = forwardRef<AnimatedIconRef, { className?: string; delay?: number; onHover?: boolean }>((props, ref) => <AnimatedIcon ref={ref} animation={analyticsAnimation} delay={props.delay || 100} onHover={props.onHover} />);
export const SearchIcon = forwardRef<AnimatedIconRef, { className?: string; delay?: number; onHover?: boolean }>((props, ref) => <AnimatedIcon ref={ref} animation={searchAnimation} delay={props.delay || 100} onHover={props.onHover} />);

DashboardIcon.displayName = "DashboardIcon";
CustomersIcon.displayName = "CustomersIcon";
ProjectsIcon.displayName = "ProjectsIcon";
InvoicesIcon.displayName = "InvoicesIcon";
QuotesIcon.displayName = "QuotesIcon";
SettingsIcon.displayName = "SettingsIcon";
TasksIcon.displayName = "TasksIcon";
AnalyticsIcon.displayName = "AnalyticsIcon";
SearchIcon.displayName = "SearchIcon";
