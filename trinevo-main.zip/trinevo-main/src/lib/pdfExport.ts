import html2pdf from 'html2pdf.js';

export interface PDFExportOptions {
  filename?: string;
  margin?: number | [number, number, number, number];
  image?: { type: string; quality: number };
  html2canvas?: { scale: number; useCORS: boolean; scrollX: number; scrollY: number; windowWidth: number; windowHeight: number };
  jsPDF?: { unit: string; format: string; orientation: string; compress: boolean };
  pagebreak?: { mode: string | string[]; before: string; after: string; avoid: string };
}

const defaultOptions: PDFExportOptions = {
  margin: [20, 20, 20, 20], // 20mm margins for safe printing
  image: { type: 'jpeg', quality: 0.98 },
  html2canvas: { 
    scale: 2, 
    useCORS: true,
    scrollX: 0,
    scrollY: 0,
    windowWidth: 794, // A4 width in pixels at 96 DPI
    windowHeight: 1123 // A4 height in pixels at 96 DPI
  },
  jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait', compress: true },
  pagebreak: { 
    mode: ['avoid-all', 'css', 'legacy'],
    before: '.page-break-before',
    after: '.page-break-after', 
    avoid: '.page-break-avoid'
  }
};

export const exportQuoteToPDF = async (
  quoteData: any,
  profile: any,
  customer: any,
  quoteLines: any[],
  optionsConfig: any,
  options: Partial<PDFExportOptions> = {}
): Promise<void> => {
  return exportToPDF(quoteData, profile, customer, quoteLines, optionsConfig, 'quote', options);
};

export const exportInvoiceToPDF = async (
  invoiceData: any,
  profile: any,
  customer: any,
  invoiceLines: any[],
  optionsConfig: any,
  options: Partial<PDFExportOptions> = {}
): Promise<void> => {
  return exportToPDF(invoiceData, profile, customer, invoiceLines, optionsConfig, 'invoice', options);
};

const exportToPDF = async (
  documentData: any,
  profile: any,
  customer: any,
  lines: any[],
  optionsConfig: any,
  type: 'quote' | 'invoice' = 'quote',
  options: Partial<PDFExportOptions> = {}
): Promise<void> => {
  const mergedOptions = { ...defaultOptions, ...options };
  
  // Set filename based on document type and number
  if (!mergedOptions.filename) {
    const documentNumber = type === 'quote' ? documentData.quote_number : documentData.invoice_number;
    const prefix = type === 'quote' ? 'Quote' : 'Invoice';
    mergedOptions.filename = `${prefix}_${documentNumber}.pdf`;
  }

  try {
    // Create the HTML content for the PDF with inline styles
    const htmlContent = createPrintableHTML(documentData, profile, customer, lines, optionsConfig, type);
    
    // Create element from HTML string
    const element = document.createElement('div');
    element.innerHTML = htmlContent;
    element.style.width = '210mm';
    element.style.minHeight = '297mm';
    element.style.backgroundColor = 'white';
    element.style.padding = '20mm';
    element.style.boxSizing = 'border-box';
    element.style.fontFamily = 'Arial, sans-serif';
    element.style.fontSize = '12px';
    element.style.lineHeight = '1.4';
    element.style.color = '#000000';

    // Use html2pdf with simplified options
    const opt = {
      margin: 0,
      filename: mergedOptions.filename,
      image: { type: 'jpeg', quality: 0.98 },
      html2canvas: { 
        scale: 2,
        useCORS: true,
        letterRendering: true,
        allowTaint: false,
        backgroundColor: '#ffffff'
      },
      jsPDF: { 
        unit: 'mm', 
        format: 'a4', 
        orientation: 'portrait',
        compress: true
      }
    };

    await html2pdf().set(opt).from(element).save();
  } catch (error) {
    console.error('PDF export failed:', error);
    throw new Error('Failed to generate PDF. Please try again.');
  }
};

export const createPrintableHTML = (
  documentData: any,
  profile: any,
  customer: any,
  lines: any[],
  optionsConfig: any,
  type: 'quote' | 'invoice' = 'quote'
): string => {
  const logo = profile?.company_logo ? `<img src="${profile.company_logo}" alt="Company Logo" style="max-height: 50px; max-width: 180px; object-fit: contain;" />` : '';
  const accentColor = profile?.accent_color || '#3b82f6';
  const documentNumber = type === 'quote' ? documentData.quote_number : documentData.invoice_number;
  const documentTitle = type === 'quote' ? (optionsConfig.documentTitle || 'Quotation') : (optionsConfig.documentTitle || 'Invoice');
  
  const deliveryAddress = optionsConfig.showDeliveryAddress && customer ? `
    <div class="section-spacing page-break-avoid">
      <h4 style="color: ${accentColor}; margin-bottom: 8px; font-weight: 600; font-size: 12px;">Delivery Address</h4>
      <div style="background: #f9fafb; padding: 12px; border-left: 3px solid ${accentColor}; font-size: 10px;">
        ${customer.company_name || ''}<br/>
        ${customer.street_address || ''}<br/>
        ${customer.postcode || ''} ${customer.city || ''}<br/>
        ${customer.country || ''}
      </div>
    </div>
  ` : '';

  const companyNumber = optionsConfig.showCompanyNumber && customer?.company_number ? `
    <div style="margin-top: 6px; font-size: 10px;">
      <strong>Company Number:</strong> ${customer.company_number}
    </div>
  ` : '';

  const taxNumber = optionsConfig.showTaxNumber && customer?.tax_number ? `
    <div style="margin-top: 6px; font-size: 10px;">
      <strong>Tax Number:</strong> ${customer.tax_number}
    </div>
  ` : '';

  const globalDiscount = optionsConfig.globalDiscount > 0 ? `
    <tr>
      <td colspan="3" style="text-align: right; padding: 8px; border: 1px solid #e5e7eb; font-size: 10px;">
        <strong>Discount (${optionsConfig.globalDiscount}%):</strong>
      </td>
      <td style="text-align: right; padding: 8px; border: 1px solid #e5e7eb; font-size: 10px;">
        <strong>-€${((documentData.subtotal * optionsConfig.globalDiscount) / 100).toFixed(2)}</strong>
      </td>
    </tr>
  ` : '';

  const acceptanceConditions = optionsConfig.showAcceptanceConditions ? `
    <div class="conditions-section page-break-avoid">
      <h4 style="color: ${accentColor}; margin-bottom: 12px; font-weight: 600; font-size: 12px;">Terms & Conditions</h4>
      <div style="font-size: 9px; line-height: 1.3; color: #6b7280; background: #f9fafb; padding: 12px; border-left: 3px solid ${accentColor};">
        ${optionsConfig.acceptanceConditions || 'This quote is valid for 30 days from the date of issue. Payment terms: 30 days net.'}
      </div>
    </div>
  ` : '';

  const signatureField = optionsConfig.showSignature ? `
    <div class="signature-section page-break-avoid">
      <div style="display: flex; justify-content: space-between; gap: 40px;">
        <div style="width: 45%;">
          <div style="border-bottom: 1px solid #000; height: 30px; margin-bottom: 6px;"></div>
          <div style="font-size: 9px; color: #666;">Client Signature</div>
        </div>
        <div style="width: 45%;">
          <div style="border-bottom: 1px solid #000; height: 30px; margin-bottom: 6px;"></div>
          <div style="font-size: 9px; color: #666;">Date</div>
        </div>
      </div>
    </div>
  ` : '';

  const freeField = optionsConfig.showFreeField && optionsConfig.freeText ? `
    <div class="section-spacing page-break-avoid">
      <div style="background: #f9fafb; padding: 16px; border-left: 3px solid ${accentColor}; font-size: 10px; line-height: 1.4;">
        ${optionsConfig.freeText}
      </div>
    </div>
  ` : '';

  return `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <title>${documentTitle} ${documentNumber}</title>
      <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
      <style>
        :root { --accent-color: ${accentColor}; }
        body { 
          font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; 
          margin: 0; 
          padding: 20px; 
          font-size: 11px;
          line-height: 1.5;
          letter-spacing: 0.025em;
          color: #000;
          background: #fff;
        }
        .pdf-container { max-width: 100%; }
        .page-break-before { page-break-before: always; break-before: page; }
        .page-break-after { page-break-after: always; break-after: page; }
        .page-break-avoid { page-break-inside: avoid; break-inside: avoid; }
        .section-spacing { margin-bottom: 24px; }
        table { width: 100%; border-collapse: collapse; }
        th, td { text-align: left; }
        @page { margin: 20mm; size: A4; }
      </style>
    </head>
    <body>
      <div class="pdf-container">
        <!-- Header Section -->
        <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 32px;" class="page-break-avoid">
          <div>
            ${logo}
            ${profile ? `
              <div style="margin-top: 12px;">
                <div style="font-weight: 600; font-size: 14px; color: ${accentColor};">${profile.company_name || ''}</div>
                <div style="margin-top: 6px; color: #6b7280; font-size: 9px; line-height: 1.3;">
                  ${profile.street_address || ''}<br/>
                  ${profile.zip_code || ''} ${profile.city || ''}<br/>
                  ${profile.country || ''}
                </div>
              </div>
            ` : ''}
          </div>
          <div style="text-align: right;">
            <h1 style="color: ${accentColor}; margin: 0 0 12px 0; font-size: 20px; font-weight: 700;">
              ${documentTitle}
            </h1>
            <div style="font-size: 10px;">
              <div><strong>${type === 'quote' ? 'Quote' : 'Invoice'} #:</strong> ${documentNumber}</div>
              <div style="margin-top: 4px;"><strong>Date:</strong> ${new Date(documentData.created_at || documentData.issue_date).toLocaleDateString()}</div>
              ${type === 'invoice' && documentData.due_date ? `<div style="margin-top: 4px;"><strong>Due Date:</strong> ${new Date(documentData.due_date).toLocaleDateString()}</div>` : ''}
            </div>
          </div>
        </div>

        <!-- Customer Section -->
        <div class="section-spacing page-break-avoid">
          <h3 style="color: ${accentColor}; margin-bottom: 12px; font-weight: 600; font-size: 12px;">Bill To</h3>
          <div style="background: #f9fafb; padding: 12px; border-left: 3px solid ${accentColor};">
            <div style="font-weight: 600; font-size: 11px;">${customer?.company_name || ''}</div>
            ${customer?.contact_name ? `<div style="margin-top: 3px; font-size: 10px;">${customer.contact_name}</div>` : ''}
            <div style="margin-top: 6px; font-size: 10px; line-height: 1.3;">
              ${customer?.street_address || ''}<br/>
              ${customer?.postcode || ''} ${customer?.city || ''}<br/>
              ${customer?.country || ''}
            </div>
            ${customer?.email ? `<div style="margin-top: 6px; font-size: 10px;"><strong>Email:</strong> ${customer.email}</div>` : ''}
            ${customer?.phone ? `<div style="margin-top: 3px; font-size: 10px;"><strong>Phone:</strong> ${customer.phone}</div>` : ''}
            ${companyNumber}
            ${taxNumber}
          </div>
          ${deliveryAddress}
        </div>

        <!-- Line Items -->
        <table style="width: 100%; border-collapse: collapse; margin-bottom: 20px;">
          <thead>
            <tr style="background-color: #f3f4f6; border-bottom: 1px solid #e5e7eb;">
              <th style="text-align: left; padding: 12px 8px; font-weight: 500; color: #6b7280; font-size: 10px; text-transform: uppercase; letter-spacing: 0.05em;">Description</th>
              <th style="text-align: center; padding: 12px 8px; font-weight: 500; color: #6b7280; width: 60px; font-size: 10px; text-transform: uppercase; letter-spacing: 0.05em;">Qty</th>
              <th style="text-align: center; padding: 12px 8px; font-weight: 500; color: #6b7280; width: 80px; font-size: 10px; text-transform: uppercase; letter-spacing: 0.05em;">Unit Price</th>
              <th style="text-align: center; padding: 12px 8px; font-weight: 500; color: #6b7280; width: 60px; font-size: 10px; text-transform: uppercase; letter-spacing: 0.05em;">VAT</th>
              <th style="text-align: right; padding: 12px 8px; font-weight: 500; color: #6b7280; width: 80px; font-size: 10px; text-transform: uppercase; letter-spacing: 0.05em;">Total</th>
            </tr>
          </thead>
          <tbody>
            ${lines.map(line => `
              <tr class="page-break-avoid" style="border-bottom: 1px solid #e5e7eb;">
                <td style="padding: 12px 8px; font-size: 10px;">
                  <div style="font-weight: 500; margin-bottom: 2px;">${line.title}</div>
                  ${line.description ? `<div style="color: #6b7280; font-size: 9px; line-height: 1.3;">${line.description}</div>` : ''}
                </td>
                <td style="text-align: center; padding: 12px 8px; font-size: 10px;">${line.quantity}</td>
                <td style="text-align: center; padding: 12px 8px; font-size: 10px;">€${Number(line.unit_price).toFixed(2)}</td>
                <td style="text-align: center; padding: 12px 8px; font-size: 10px; color: #6b7280;">0%</td>
                <td style="text-align: right; padding: 12px 8px; font-size: 10px; font-weight: 500;">€${Number(line.total).toFixed(2)}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>

        <!-- Totals Section -->
        <div class="totals-section">
          <table style="width: 50%; margin-left: auto; margin-top: 24px;">
            <tr>
              <td style="text-align: right; padding: 6px 8px; border: 1px solid #e5e7eb; font-size: 10px;">
                <strong>Subtotal:</strong>
              </td>
              <td style="text-align: right; padding: 6px 8px; border: 1px solid #e5e7eb; font-size: 10px;">
                <strong>€${Number(documentData.subtotal).toFixed(2)}</strong>
              </td>
            </tr>
            ${globalDiscount}
            <tr style="background-color: ${accentColor};">
              <td style="text-align: right; padding: 10px 8px; color: white; font-size: 11px; font-weight: 600;">
                <strong>Total:</strong>
              </td>
              <td style="text-align: right; padding: 10px 8px; color: white; font-size: 11px; font-weight: 600;">
                <strong>€${Number(documentData.total).toFixed(2)}</strong>
              </td>
            </tr>
          </table>
        </div>

        ${documentData.notes ? `
          <div class="section-spacing page-break-avoid">
            <h4 style="color: ${accentColor}; margin-bottom: 12px; font-weight: 600; font-size: 12px;">Notes</h4>
            <div style="background: #f9fafb; padding: 12px; border-left: 3px solid ${accentColor}; font-size: 10px; line-height: 1.4;">
              ${documentData.notes}
            </div>
          </div>
        ` : ''}

        ${freeField}
        ${acceptanceConditions}
        ${signatureField}
      </div>
    </body>
    </html>
  `;
};

// Legacy export for backward compatibility
export const createPrintableQuoteHTML = createPrintableHTML;