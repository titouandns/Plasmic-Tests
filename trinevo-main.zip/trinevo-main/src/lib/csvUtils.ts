import type { Tables } from "@/integrations/supabase/types";

type Customer = Tables<'customers'>;

export interface ParsedCustomerRow {
  company_name: string;
  contact_name?: string;
  email?: string;
  phone?: string;
  street_address?: string;
  city?: string;
  postcode?: string;
  country?: string;
  state_region?: string;
  company_number?: string;
  tax_number?: string;
  status: string;
  notes?: string;
  billing_address?: string;
  archived: boolean;
}

export interface ValidationResult {
  isValid: boolean;
  errors: string[];
}

export function parseCSV(csvText: string): ParsedCustomerRow[] {
  const lines = csvText.trim().split('\n');
  if (lines.length < 2) {
    throw new Error('CSV must contain at least a header row and one data row');
  }

  const headers = lines[0].split(',').map(h => h.trim().replace(/"/g, '').toLowerCase());
  const rows: ParsedCustomerRow[] = [];

  // Map CSV headers to our fields
  const fieldMapping: Record<string, keyof ParsedCustomerRow> = {
    'company name': 'company_name',
    'company_name': 'company_name',
    'contact name': 'contact_name',
    'contact_name': 'contact_name',
    'email': 'email',
    'phone': 'phone',
    'street address': 'street_address',
    'street_address': 'street_address',
    'street': 'street_address',
    'address': 'street_address',
    'city': 'city',
    'postcode': 'postcode',
    'postal code': 'postcode',
    'zip': 'postcode',
    'country': 'country',
    'state': 'state_region',
    'state_region': 'state_region',
    'region': 'state_region',
    'company number': 'company_number',
    'company_number': 'company_number',
    'tax number': 'tax_number',
    'tax_number': 'tax_number',
    'status': 'status',
    'notes': 'notes',
    'billing address': 'billing_address',
    'billing_address': 'billing_address',
    'archived': 'archived'
  };

  for (let i = 1; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;

    const values = parseCSVLine(line);
    const row: Partial<ParsedCustomerRow> = {
      status: 'lead', // default status
      archived: false // default archived
    };

    headers.forEach((header, index) => {
      const field = fieldMapping[header];
      if (field && values[index] !== undefined) {
        let value = values[index].trim().replace(/"/g, '');
        
        // Handle special cases
        if (field === 'archived') {
          row[field] = value.toLowerCase() === 'true' || value === '1';
        } else if (field === 'status') {
          // Normalize status values
          const normalizedStatus = value.toLowerCase();
          if (['lead', 'active', 'inactive', 'prospect'].includes(normalizedStatus)) {
            row[field] = normalizedStatus;
          } else {
            row[field] = 'lead'; // default fallback
          }
        } else {
          (row as any)[field] = value || undefined;
        }
      }
    });

    if (Object.keys(row).length > 2) { // More than just status and archived
      rows.push(row as ParsedCustomerRow);
    }
  }

  return rows;
}

function parseCSVLine(line: string): string[] {
  const result: string[] = [];
  let current = '';
  let inQuotes = false;
  
  for (let i = 0; i < line.length; i++) {
    const char = line[i];
    
    if (char === '"') {
      inQuotes = !inQuotes;
    } else if (char === ',' && !inQuotes) {
      result.push(current);
      current = '';
    } else {
      current += char;
    }
  }
  
  result.push(current);
  return result;
}

export function validateCustomerRow(row: ParsedCustomerRow): ValidationResult {
  const errors: string[] = [];

  // Required fields
  if (!row.company_name || row.company_name.trim() === '') {
    errors.push('Company name is required');
  }

  // At least one contact method should be provided
  if (!row.contact_name && !row.email && !row.phone) {
    errors.push('At least one of contact name, email, or phone is required');
  }

  // Email validation
  if (row.email && row.email.trim() !== '') {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(row.email)) {
      errors.push('Invalid email format');
    }
  }

  // Phone validation (basic)
  if (row.phone && row.phone.trim() !== '') {
    const phoneRegex = /^[\d\s\-\+\(\)]{7,}$/;
    if (!phoneRegex.test(row.phone)) {
      errors.push('Invalid phone format');
    }
  }

  // Status validation
  const validStatuses = ['lead', 'active', 'inactive', 'prospect'];
  if (row.status && !validStatuses.includes(row.status.toLowerCase())) {
    errors.push('Invalid status (must be: lead, active, inactive, or prospect)');
  }

  return {
    isValid: errors.length === 0,
    errors
  };
}

export function generateDemoCSV(): string {
  const headers = [
    'Company Name',
    'Contact Name', 
    'Email',
    'Phone',
    'Street',
    'Postcode',
    'City',
    'Country',
    'Company Number',
    'Tax Number',
    'Status',
    'Notes'
  ];

  const sampleRows = [
    [
      'Acme Corp',
      'Jane Doe',
      'jane@acmecorp.com',
      '+14155552671',
      '123 Market St',
      '94103',
      'San Francisco',
      'USA',
      '123456789',
      'US987654321',
      'Lead',
      'Important client from the West Coast'
    ],
    [
      'Beta Agency',
      'John Smith',
      'john@betaagency.io',
      '+442071838750',
      '10 Downing St',
      'SW1A 2AA',
      'London',
      'UK',
      'GB999888777',
      'GB123456789',
      'Active',
      'Met at last year\'s conference'
    ],
    [
      'Pixel Studio',
      '',
      'contact@pixelstudio.fr',
      '+33142345678',
      '5 Rue Oberkampf',
      '75011',
      'Paris',
      'France',
      'FR000111222',
      'FR445566778',
      'Prospect',
      'Interested in SEO services'
    ],
    [
      '',
      '',
      'no-reply@example.com',
      '',
      '12 Test St',
      '00000',
      'Test City',
      'Narnia',
      '',
      '',
      '',
      'Missing info test row'
    ]
  ];

  const csvLines = [headers.join(',')];
  
  sampleRows.forEach(row => {
    const escapedRow = row.map(field => {
      // Escape fields that contain commas, quotes, or newlines
      if (field.includes(',') || field.includes('"') || field.includes('\n')) {
        return `"${field.replace(/"/g, '""')}"`;
      }
      return field;
    });
    csvLines.push(escapedRow.join(','));
  });

  return csvLines.join('\n');
}