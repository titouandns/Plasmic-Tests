export const TASK_COLORS = {
  gray: {
    dot: 'bg-gray-400',
    border: 'border-l-gray-400',
    bg: 'bg-gray-50',
    name: 'Gray'
  },
  green: {
    dot: 'bg-green-400',
    border: 'border-l-green-400', 
    bg: 'bg-green-50',
    name: 'Green'
  },
  blue: {
    dot: 'bg-blue-400',
    border: 'border-l-blue-400',
    bg: 'bg-blue-50', 
    name: 'Blue'
  },
  yellow: {
    dot: 'bg-yellow-400',
    border: 'border-l-yellow-400',
    bg: 'bg-yellow-50',
    name: 'Yellow'
  },
  pink: {
    dot: 'bg-pink-400',
    border: 'border-l-pink-400',
    bg: 'bg-pink-50',
    name: 'Pink'
  },
  purple: {
    dot: 'bg-purple-400',
    border: 'border-l-purple-400',
    bg: 'bg-purple-50',
    name: 'Purple'
  }
} as const;

export type TaskColorKey = keyof typeof TASK_COLORS;

export function getTaskColor(colorKey?: string): typeof TASK_COLORS[TaskColorKey] {
  return TASK_COLORS[colorKey as TaskColorKey] || TASK_COLORS.gray;
}