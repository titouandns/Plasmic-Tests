import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { Layout } from "./components/Layout/Layout";
import { Dashboard } from "./pages/Dashboard";
import { Customers } from "./pages/Customers";
import { CustomerDetail } from "./pages/CustomerDetail";
import Quotes from "./pages/Quotes";
import QuoteDetail from "./pages/QuoteDetail";
import QuotePreview from "./pages/QuotePreview";
import QuoteEdit from "./pages/QuoteEdit";
import { Invoices } from "./pages/Invoices";
import InvoiceDetail from "./pages/InvoiceDetail";
import InvoicePreview from "./pages/InvoicePreview";
import InvoiceNew from "./pages/InvoiceNew";
import { Projects } from "./pages/Projects";
import { ProjectDetail } from "./pages/ProjectDetail";
import { Tasks } from "./pages/Tasks";
import { Analytics } from "./pages/Analytics";
import { Settings } from "./pages/Settings";
import Help from "./pages/Help";

import { Auth } from "./pages/Auth";
import { AuthProvider, useAuth } from "./components/AuthProvider";
import { ThemeProvider } from "./components/theme-provider";
import NotFound from "./pages/NotFound";
import TeamJoin from "./pages/TeamJoin";
import Onboarding from "./pages/Onboarding";
import EmailVerification from "./pages/EmailVerification";
import { supabase } from "@/integrations/supabase/client";
import { useEffect, useState } from "react";

const queryClient = new QueryClient();

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth();
  const [needsOnboarding, setNeedsOnboarding] = useState<boolean | null>(null);
  
  console.log('ProtectedRoute - loading:', loading, 'user:', !!user);

  useEffect(() => {
    if (user && !loading) {
      // Check if user needs onboarding
      const checkOnboardingStatus = async () => {
        const { data: profile } = await supabase
          .from("profiles")
          .select("onboarding_completed")
          .eq("user_id", user.id)
          .single();
        
        setNeedsOnboarding(!profile?.onboarding_completed);
      };
      
      checkOnboardingStatus();
    } else if (!loading && !user) {
      // If not loading and no user, set needsOnboarding to null to stop loading
      setNeedsOnboarding(null);
    }
  }, [user, loading]);

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
  }
  
  if (!user) {
    return <Navigate to="/login" replace />;
  }

  if (needsOnboarding === null) {
    return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
  }

  if (needsOnboarding) {
    return <Navigate to="/onboarding" replace />;
  }
  
  return <>{children}</>;
}

function OnboardingRoute({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth();

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
  }

  if (!user) {
    return <Navigate to="/login" replace />;
  }

  return <>{children}</>;
}

function PublicRoute({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth();
  
  if (loading) {
    return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
  }
  
  if (user) {
    return <Navigate to="/" replace />;
  }
  
  return <>{children}</>;
}

const App = () => (
  <QueryClientProvider client={queryClient}>
    <ThemeProvider defaultTheme="light" storageKey="trinevo-ui-theme">
      <AuthProvider>
        <TooltipProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
          <Routes>
            <Route path="/" element={<ProtectedRoute><Layout><Dashboard /></Layout></ProtectedRoute>} />
            <Route path="/login" element={<PublicRoute><Auth /></PublicRoute>} />
            
            <Route path="/auth" element={<PublicRoute><Auth /></PublicRoute>} />
            <Route path="/customers" element={<ProtectedRoute><Layout><Customers /></Layout></ProtectedRoute>} />
            <Route path="/customers/new" element={<ProtectedRoute><Layout><CustomerDetail /></Layout></ProtectedRoute>} />
            <Route path="/customers/:id" element={<ProtectedRoute><Layout><CustomerDetail /></Layout></ProtectedRoute>} />
            <Route path="/customers/detail" element={<Navigate to="/customers" replace />} />
            <Route path="/quotes" element={<ProtectedRoute><Layout><Quotes /></Layout></ProtectedRoute>} />
            <Route path="/quotes/new" element={<ProtectedRoute><Layout><QuoteEdit /></Layout></ProtectedRoute>} />
            <Route path="/quotes/:id" element={<ProtectedRoute><Layout><QuotePreview /></Layout></ProtectedRoute>} />
            <Route path="/quotes/:id/edit" element={<ProtectedRoute><Layout><QuoteEdit /></Layout></ProtectedRoute>} />
            <Route path="/invoicing/quotes" element={<ProtectedRoute><Layout><Quotes /></Layout></ProtectedRoute>} />
            <Route path="/invoices" element={<ProtectedRoute><Layout><Invoices /></Layout></ProtectedRoute>} />
            <Route path="/invoices/new" element={<ProtectedRoute><Layout><InvoiceNew /></Layout></ProtectedRoute>} />
            <Route path="/invoices/:id" element={<ProtectedRoute><Layout><InvoicePreview /></Layout></ProtectedRoute>} />
            <Route path="/invoices/:id/edit" element={<ProtectedRoute><Layout><InvoiceDetail /></Layout></ProtectedRoute>} />
            <Route path="/invoicing/invoices" element={<ProtectedRoute><Layout><Invoices /></Layout></ProtectedRoute>} />
            <Route path="/projects" element={<ProtectedRoute><Layout><Projects /></Layout></ProtectedRoute>} />
            <Route path="/projects/:id" element={<ProtectedRoute><Layout><ProjectDetail /></Layout></ProtectedRoute>} />
            <Route path="/tasks" element={<ProtectedRoute><Layout><Tasks /></Layout></ProtectedRoute>} />
            <Route path="/analytics" element={<ProtectedRoute><Layout><Analytics /></Layout></ProtectedRoute>} />
            <Route path="/settings" element={<ProtectedRoute><Layout><Settings /></Layout></ProtectedRoute>} />
            <Route path="/help" element={<ProtectedRoute><Layout><Help /></Layout></ProtectedRoute>} />
            <Route path="/onboarding" element={<OnboardingRoute><Onboarding /></OnboardingRoute>} />
            <Route path="/email-verification" element={<EmailVerification />} />
            <Route path="/join/:token" element={<TeamJoin />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </TooltipProvider>
    </AuthProvider>
  </ThemeProvider>
  </QueryClientProvider>
);

export default App;
