import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  ArrowLeft, 
  Plus, 
  Trash2, 
  Settings as SettingsIcon,
  Download
} from "lucide-react";
import { useInvoices, useInvoiceLines } from "@/hooks/useInvoices";
import { useCustomers, useProfile } from "@/hooks/useSupabase";
import { useToast } from "@/hooks/use-toast";
import { exportInvoiceToPDF } from "@/lib/pdfExport";
import { CustomerSearchSelect } from "@/components/CustomerSearchSelect";
import { CustomerForm } from "@/components/forms/CustomerForm";

export default function InvoiceDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { toast } = useToast();
  const { invoices, updateInvoice, addInvoice } = useInvoices();
  const { invoiceLines, addInvoiceLine, updateInvoiceLine, deleteInvoiceLine } = useInvoiceLines(id);
  const { customers } = useCustomers();
  const { profile } = useProfile();
  
  const [hasChanges, setHasChanges] = useState(false);
  const [invoice, setInvoice] = useState<any>(null);
  const [editingLines, setEditingLines] = useState<any[]>([]);
  const [showCustomerForm, setShowCustomerForm] = useState(false);
   
  // Settings state
  const [settings, setSettings] = useState({
    showDeliveryAddress: false,
    showCompanyNumber: false,
    showTaxNumber: false,
    showAcceptanceConditions: false,
    showSignature: false,
    showDocumentTitle: false,
    showFreeField: false,
    showGlobalDiscount: false,
    documentTitle: "INVOICE",
    freeText: "",
    globalDiscount: 0,
    acceptanceConditions: "Payment terms: Net 30 days."
  });

  const isNew = id === 'new';

  // Initialize invoice data
  useEffect(() => {
    if (isNew) {
      // Generate new invoice number
      const invoiceNumber = `INV-${Date.now().toString().slice(-6)}`;
      setInvoice({
        invoice_number: invoiceNumber,
        client_id: '',
        subtotal: 0,
        total: 0,
        currency: 'EUR',
        status: 'draft',
        notes: '',
        due_date: '',
        issue_date: new Date().toISOString().split('T')[0]
      });
      setEditingLines([{ 
        id: 'new-1', 
        title: '', 
        description: '', 
        quantity: 1, 
        unit_price: 0, 
        total: 0,
        display_order: 0
      }]);
    } else if (id && invoices.length > 0) {
      const foundInvoice = invoices.find(q => q.id === id);
      if (foundInvoice) {
        setInvoice(foundInvoice);
      }
    }
  }, [id, invoices, isNew]);

  // Initialize editing lines with database lines
  useEffect(() => {
    if (!isNew && invoiceLines.length > 0) {
      setEditingLines(invoiceLines.map(line => ({ ...line })));
    }
  }, [invoiceLines, isNew]);

  const handleInvoiceChange = (field: string, value: any) => {
    setInvoice((prev: any) => ({ ...prev, [field]: value }));
    setHasChanges(true);
  };

  const handleLineChange = (index: number, field: string, value: any) => {
    const updatedLines = [...editingLines];
    updatedLines[index] = { ...updatedLines[index], [field]: value };
    
    // Recalculate line total
    if (field === 'quantity' || field === 'unit_price') {
      const quantity = field === 'quantity' ? parseFloat(value) || 0 : parseFloat(updatedLines[index].quantity) || 0;
      const unitPrice = field === 'unit_price' ? parseFloat(value) || 0 : parseFloat(updatedLines[index].unit_price) || 0;
      updatedLines[index].total = quantity * unitPrice;
    }
    
    setEditingLines(updatedLines);
    setHasChanges(true);
  };

  const addNewLine = () => {
    const newLine = {
      id: `new-${Date.now()}`,
      title: '',
      description: '',
      quantity: 1,
      unit_price: 0,
      total: 0,
      display_order: editingLines.length
    };
    setEditingLines([...editingLines, newLine]);
    setHasChanges(true);
  };

  const removeLine = (index: number) => {
    const updatedLines = editingLines.filter((_, i) => i !== index);
    setEditingLines(updatedLines);
    setHasChanges(true);
  };

  const calculateTotals = () => {
    const subtotal = editingLines.reduce((sum, line) => sum + (parseFloat(line.total.toString()) || 0), 0);
    const discount = (subtotal * (settings.globalDiscount / 100));
    const discountedSubtotal = subtotal - discount;
    const vatRate = 0.21; // 21% VAT
    const vat = discountedSubtotal * vatRate;
    const total = discountedSubtotal + vat;

    return {
      subtotal,
      discount,
      discountedSubtotal,
      vat,
      total
    };
  };

  const handleSave = async () => {
    try {
      if (!invoice.client_id) {
        toast({
          title: "Error",
          description: "Please select a customer",
          variant: "destructive",
        });
        return;
      }

      const totals = calculateTotals();
      const invoiceData = {
        ...invoice,
        subtotal: totals.subtotal,
        total: totals.total
      };

      let savedInvoice;
      if (isNew) {
        savedInvoice = await addInvoice(invoiceData);
      } else {
        savedInvoice = await updateInvoice(invoice.id, invoiceData);
      }

      // Save invoice lines
      for (const line of editingLines) {
        if (line.id.toString().startsWith('new-')) {
          if (line.title.trim()) {
            await addInvoiceLine({
              invoice_id: savedInvoice.id,
              title: line.title,
              description: line.description || '',
              quantity: parseFloat(line.quantity.toString()) || 0,
              unit_price: parseFloat(line.unit_price.toString()) || 0,
              total: parseFloat(line.total.toString()) || 0,
              display_order: line.display_order
            });
          }
        } else {
          await updateInvoiceLine(line.id, {
            title: line.title,
            description: line.description || '',
            quantity: parseFloat(line.quantity.toString()) || 0,
            unit_price: parseFloat(line.unit_price.toString()) || 0,
            total: parseFloat(line.total.toString()) || 0,
            display_order: line.display_order
          });
        }
      }

      setHasChanges(false);
      
      if (isNew) {
        navigate(`/invoices/${savedInvoice.id}`);
      }
      
      toast({
        title: "Success",
        description: "Invoice saved successfully",
      });
    } catch (error) {
      console.error('Error saving invoice:', error);
    }
  };

  const handleSettingChange = (setting: string, value: any) => {
    setSettings(prev => ({ ...prev, [setting]: value }));
  };

  const handleExportPDF = async () => {
    try {
      const customer = customers.find(c => c.id === invoice?.client_id);
      const totals = calculateTotals();
      
      const invoiceData = {
        ...invoice,
        ...totals
      };

      await exportInvoiceToPDF(invoiceData, profile, customer, editingLines, settings);
    } catch (error) {
      console.error('Error exporting PDF:', error);
      toast({
        title: "Error",
        description: "Failed to export PDF",
        variant: "destructive",
      });
    }
  };

  if (!invoice) {
    return <div className="flex items-center justify-center min-h-screen">
      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
    </div>;
  }

  const customer = customers.find(c => c.id === invoice.client_id);
  const totals = calculateTotals();

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-border">
          <div className="flex items-center space-x-4">
            <Button 
              variant="ghost" 
              size="icon"
              onClick={() => navigate('/invoices')}
            >
              <ArrowLeft className="h-4 w-4" />
            </Button>
            <div>
              <h1 className="text-2xl font-bold">
                {invoice.invoice_number || 'New Invoice'}
              </h1>
              <p className="text-muted-foreground">
                {isNew ? 'Create a new invoice' : 'Edit invoice details'}
              </p>
            </div>
          </div>
          
          <div className="flex items-center space-x-3">
            <Button onClick={handleExportPDF} variant="outline">
              <Download className="h-4 w-4 mr-2" />
              Download PDF
            </Button>
            {hasChanges && (
              <Button onClick={handleSave} className="bg-primary">
                Save Invoice
              </Button>
            )}
          </div>
        </div>

        <div className="flex">
          {/* Main Content */}
          <div className="flex-1 p-6">
            {/* Invoice Preview */}
            <div className="bg-card border border-border rounded-lg p-8 shadow-sm">
              {/* Header Section */}
              <div className="flex justify-between items-start mb-8">
                <div>
                  {profile?.company_logo ? (
                    <div className="mb-4">
                      <img 
                        src={profile.company_logo} 
                        alt="Company logo" 
                        className="h-16 max-w-48 object-contain"
                        style={{ filter: profile.accent_color ? `hue-rotate(${profile.accent_color})` : undefined }}
                      />
                    </div>
                  ) : (
                    <h1 className="text-xl font-bold text-foreground mb-2">{profile?.company_name || "Company Name"}</h1>
                  )}
                  
                  <div className="text-sm text-muted-foreground space-y-1">
                    {profile?.company_name && profile?.company_logo && (
                      <p className="font-medium text-foreground">{profile.company_name}</p>
                    )}
                    <p>{profile?.street_address || "Street Address"}</p>
                    {profile?.address_complement && <p>{profile.address_complement}</p>}
                    <p>{profile?.city || "City"} {profile?.zip_code || "Zip"}</p>
                    <p>{profile?.country || "Country"}</p>
                    {settings.showCompanyNumber && profile?.company_number && <p>Company Number: {profile.company_number}</p>}
                    {settings.showTaxNumber && profile?.vat_number && <p>VAT Number: {profile.vat_number}</p>}
                  </div>
                </div>

                <div className="text-right">
                  {settings.showDocumentTitle && (
                    <h2 className="text-2xl font-bold mb-4" style={{ color: profile?.accent_color }}>
                      {settings.documentTitle}
                    </h2>
                  )}
                  <div className="space-y-1 text-sm">
                    <p><span className="font-medium">Invoice #:</span> {invoice.invoice_number}</p>
                    <p><span className="font-medium">Issue Date:</span> {new Date(invoice.issue_date).toLocaleDateString()}</p>
                    {invoice.due_date && (
                      <p><span className="font-medium">Due Date:</span> {new Date(invoice.due_date).toLocaleDateString()}</p>
                    )}
                    <p><span className="font-medium">Status:</span> 
                      <span className="ml-2 px-2 py-1 rounded text-xs bg-primary/10 text-primary">
                        {invoice.status}
                      </span>
                    </p>
                  </div>
                </div>
              </div>

              {/* Customer Information */}
              <div className="mb-8">
                <h3 className="font-semibold mb-3">Bill To:</h3>
                {customer ? (
                  <div className="text-sm space-y-1">
                    <p className="font-medium">{customer.company_name}</p>
                    {customer.contact_name && <p>{customer.contact_name}</p>}
                    {customer.street_address && <p>{customer.street_address}</p>}
                    {customer.city && customer.postcode && (
                      <p>{customer.city}, {customer.postcode}</p>
                    )}
                    {customer.country && <p>{customer.country}</p>}
                    {customer.email && <p>{customer.email}</p>}
                    {customer.phone && <p>{customer.phone}</p>}
                  </div>
                ) : (
                  <div className="mb-4">
                    <CustomerSearchSelect
                      customers={customers}
                      selectedCustomerId={invoice.client_id}
                      onSelect={(customer) => handleInvoiceChange('client_id', customer.id)}
                      onCreateNew={() => setShowCustomerForm(true)}
                      placeholder="Select or search for a customer..."
                    />
                  </div>
                )}
              </div>

              {/* Line Items Table */}
              <div className="mb-8">
                <table className="w-full border-collapse">
                  <thead>
                    <tr className="border-b border-border">
                      <th className="text-left py-3 font-medium">Description</th>
                      <th className="text-right py-3 font-medium w-24">Qty</th>
                      <th className="text-right py-3 font-medium w-32">Unit Price</th>
                      <th className="text-right py-3 font-medium w-32">Total</th>
                      <th className="w-12"></th>
                    </tr>
                  </thead>
                  <tbody>
                    {editingLines.map((line, index) => (
                      <tr key={line.id} className="border-b border-border/50">
                        <td className="py-3">
                          <Input
                            value={line.title}
                            onChange={(e) => handleLineChange(index, 'title', e.target.value)}
                            placeholder="Item description"
                            className="border-0 p-0 h-auto shadow-none focus-visible:ring-0"
                          />
                          <Textarea
                            value={line.description || ''}
                            onChange={(e) => handleLineChange(index, 'description', e.target.value)}
                            placeholder="Additional details (optional)"
                            className="mt-1 border-0 p-0 h-auto shadow-none focus-visible:ring-0 text-xs text-muted-foreground resize-none"
                            rows={1}
                          />
                        </td>
                        <td className="py-3 text-right">
                          <Input
                            type="number"
                            value={line.quantity}
                            onChange={(e) => handleLineChange(index, 'quantity', e.target.value)}
                            className="text-right border-0 p-0 h-auto shadow-none focus-visible:ring-0"
                            min="0"
                            step="0.01"
                          />
                        </td>
                        <td className="py-3 text-right">
                          <Input
                            type="number"
                            value={line.unit_price}
                            onChange={(e) => handleLineChange(index, 'unit_price', e.target.value)}
                            className="text-right border-0 p-0 h-auto shadow-none focus-visible:ring-0"
                            min="0"
                            step="0.01"
                          />
                        </td>
                        <td className="py-3 text-right font-medium">
                          €{parseFloat(line.total.toString()).toFixed(2)}
                        </td>
                        <td className="py-3">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => removeLine(index)}
                            className="h-6 w-6 text-muted-foreground hover:text-destructive"
                          >
                            <Trash2 className="h-3 w-3" />
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>

                <Button
                  variant="ghost"
                  onClick={addNewLine}
                  className="mt-4 text-sm text-muted-foreground hover:text-foreground"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Add Line Item
                </Button>
              </div>

              {/* Totals */}
              <div className="flex justify-end mb-8">
                <div className="w-80 space-y-2">
                  <div className="flex justify-between py-2">
                    <span>Subtotal:</span>
                    <span>€{totals.subtotal.toFixed(2)}</span>
                  </div>
                  
                  {settings.showGlobalDiscount && settings.globalDiscount > 0 && (
                    <div className="flex justify-between py-2 text-sm">
                      <span>Discount ({settings.globalDiscount}%):</span>
                      <span>-€{totals.discount.toFixed(2)}</span>
                    </div>
                  )}
                  
                  <div className="flex justify-between py-2 text-sm">
                    <span>VAT (21%):</span>
                    <span>€{totals.vat.toFixed(2)}</span>
                  </div>
                  
                  <div className="flex justify-between py-3 text-lg font-bold border-t border-border">
                    <span>Total:</span>
                    <span style={{ color: profile?.accent_color }}>€{totals.total.toFixed(2)}</span>
                  </div>
                </div>
              </div>

              {/* Free Text Field */}
              {settings.showFreeField && (
                <div className="mb-8">
                  <Textarea
                    value={settings.freeText}
                    onChange={(e) => handleSettingChange('freeText', e.target.value)}
                    placeholder="Additional information, terms, or notes..."
                    className="min-h-[100px]"
                  />
                </div>
              )}

              {/* Terms & Conditions */}
              {settings.showAcceptanceConditions && (
                <div className="mb-8 p-4 bg-muted rounded-lg">
                  <h4 className="font-semibold mb-2">Terms & Conditions</h4>
                  <p className="text-sm text-muted-foreground">{settings.acceptanceConditions}</p>
                </div>
              )}

              {/* Notes */}
              {invoice.notes && (
                <div className="mb-8">
                  <h4 className="font-semibold mb-2">Notes</h4>
                  <p className="text-sm text-muted-foreground">{invoice.notes}</p>
                </div>
              )}

              {/* Signature */}
              {settings.showSignature && (
                <div className="border-t border-border pt-8">
                  <div className="flex justify-between">
                    <div className="text-center">
                      <div className="w-48 border-b border-border mb-2"></div>
                      <p className="text-sm text-muted-foreground">Customer Signature</p>
                    </div>
                    <div className="text-center">
                      <div className="w-48 border-b border-border mb-2"></div>
                      <p className="text-sm text-muted-foreground">Date</p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Right Sidebar - Options */}
          <div className="w-64 bg-muted/30 border-l border-border p-6 space-y-6">
            <div className="flex items-center space-x-2">
              <SettingsIcon className="h-4 w-4" />
              <h3 className="font-semibold">Invoice Options</h3>
            </div>

            {/* Display Options */}
            <div className="space-y-4">
              <h4 className="text-sm font-medium">Display Options</h4>
              
              <div className="space-y-3">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="showDocumentTitle"
                    checked={settings.showDocumentTitle}
                    onCheckedChange={(checked) => handleSettingChange('showDocumentTitle', checked)}
                  />
                  <Label htmlFor="showDocumentTitle" className="text-sm">Document Title</Label>
                </div>
                
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="showCompanyNumber"
                    checked={settings.showCompanyNumber}
                    onCheckedChange={(checked) => handleSettingChange('showCompanyNumber', checked)}
                  />
                  <Label htmlFor="showCompanyNumber" className="text-sm">Company Number</Label>
                </div>
                
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="showTaxNumber"
                    checked={settings.showTaxNumber}
                    onCheckedChange={(checked) => handleSettingChange('showTaxNumber', checked)}
                  />
                  <Label htmlFor="showTaxNumber" className="text-sm">VAT Number</Label>
                </div>
                
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="showGlobalDiscount"
                    checked={settings.showGlobalDiscount}
                    onCheckedChange={(checked) => handleSettingChange('showGlobalDiscount', checked)}
                  />
                  <Label htmlFor="showGlobalDiscount" className="text-sm">Global Discount</Label>
                </div>
                
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="showAcceptanceConditions"
                    checked={settings.showAcceptanceConditions}
                    onCheckedChange={(checked) => handleSettingChange('showAcceptanceConditions', checked)}
                  />
                  <Label htmlFor="showAcceptanceConditions" className="text-sm">Terms & Conditions</Label>
                </div>
                
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="showFreeField"
                    checked={settings.showFreeField}
                    onCheckedChange={(checked) => handleSettingChange('showFreeField', checked)}
                  />
                  <Label htmlFor="showFreeField" className="text-sm">Free Text Field</Label>
                </div>
                
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="showSignature"
                    checked={settings.showSignature}
                    onCheckedChange={(checked) => handleSettingChange('showSignature', checked)}
                  />
                  <Label htmlFor="showSignature" className="text-sm">Signature Field</Label>
                </div>
              </div>
            </div>

            {/* Document Settings */}
            <div className="space-y-4">
              <h4 className="text-sm font-medium">Document Settings</h4>
              
              <div className="space-y-3">
                <div>
                  <Label htmlFor="documentTitle" className="text-sm">Document Title</Label>
                  <Input
                    id="documentTitle"
                    value={settings.documentTitle}
                    onChange={(e) => handleSettingChange('documentTitle', e.target.value)}
                    className="mt-1"
                  />
                </div>
                
                {settings.showGlobalDiscount && (
                  <div>
                    <Label htmlFor="globalDiscount" className="text-sm">Global Discount (%)</Label>
                    <Input
                      id="globalDiscount"
                      type="number"
                      value={settings.globalDiscount}
                      onChange={(e) => handleSettingChange('globalDiscount', parseFloat(e.target.value) || 0)}
                      className="mt-1"
                      min="0"
                      max="100"
                      step="0.1"
                    />
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Customer Form Modal */}
      {showCustomerForm && (
        <CustomerForm
          open={showCustomerForm}
          onOpenChange={setShowCustomerForm}
        />
      )}
    </div>
  );
}