import { useState, useEffect, useCallback, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useProfile } from "@/hooks/useSupabase";
import { useTeam } from "@/hooks/useTeam";
import { useAuth } from "@/components/AuthProvider";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { Loader } from "@googlemaps/js-api-loader";
import { User, Users, CreditCard, Shield, FileText, Camera, Euro, DollarSign, Plus, Trash2, Crown, Upload, X, Mail, Loader2, Settings as SettingsIcon, CheckCircle, AlertCircle } from "lucide-react";
import { SaveChangesBar } from "@/components/SaveChangesBar";
import { useIntegrations } from "@/hooks/useIntegrations";
export function Settings() {
  const {
    user
  } = useAuth();
  const {
    profile,
    updateProfile,
    loading: profileLoading
  } = useProfile();
  const {
    team,
    teamMembers,
    invites,
    loading: teamLoading,
    updateTeam,
    createTeam,
    inviteUser,
    uploadTeamLogo
  } = useTeam();
  const {
    toast
  } = useToast();
  const { loading: integrationsLoading, connectStripe, disconnectStripe } = useIntegrations();

  // Profile form state
  const [profileForm, setProfileForm] = useState({
    first_name: "",
    last_name: "",
    avatar_url: ""
  });
  const [originalProfile, setOriginalProfile] = useState({
    first_name: "",
    last_name: "",
    avatar_url: ""
  });
  const [profileSaving, setProfileSaving] = useState(false);
  const [avatarUploading, setAvatarUploading] = useState(false);
  const profileAvatarRef = useRef<HTMLInputElement>(null);

  // Team form state
  const [teamForm, setTeamForm] = useState({
    name: "",
    logo: ""
  });
  const [originalTeam, setOriginalTeam] = useState({
    name: "",
    logo: ""
  });
  const [teamSaving, setTeamSaving] = useState(false);
  const [teamLogoUploading, setTeamLogoUploading] = useState(false);
  const teamLogoRef = useRef<HTMLInputElement>(null);

  // Invite user state
  const [inviteEmail, setInviteEmail] = useState("");
  const [inviteRole, setInviteRole] = useState("member");
  const [inviting, setInviting] = useState(false);
  const [showInviteDialog, setShowInviteDialog] = useState(false);

  // Security state
  const [passwordResetSent, setPasswordResetSent] = useState(false);
  const [sendingPasswordReset, setSendingPasswordReset] = useState(false);
  const [authProviders, setAuthProviders] = useState<string[]>([]);

  // Invoicing form state
  const [invoicingForm, setInvoicingForm] = useState({
    company_name: "",
    company_number: "",
    vat_number: "",
    street_address: "",
    address_complement: "",
    zip_code: "",
    city: "",
    country: "",
    company_logo: "",
    accent_color: "#3b82f6"
  });
  const [originalInvoicingForm, setOriginalInvoicingForm] = useState({
    company_name: "",
    company_number: "",
    vat_number: "",
    street_address: "",
    address_complement: "",
    zip_code: "",
    city: "",
    country: "",
    company_logo: "",
    accent_color: "#3b82f6"
  });
  const [invoicingSaving, setInvoicingSaving] = useState(false);
  const [logoUploading, setLogoUploading] = useState(false);
  const [dragActive, setDragActive] = useState(false);

  // Change detection
  const hasProfileChanges = JSON.stringify(profileForm) !== JSON.stringify(originalProfile);
  const hasTeamChanges = JSON.stringify(teamForm) !== JSON.stringify(originalTeam);
  const hasInvoicingChanges = JSON.stringify(invoicingForm) !== JSON.stringify(originalInvoicingForm);

  // Initialize forms with data
  useEffect(() => {
    if (profile) {
      const profileData = {
        first_name: profile.first_name || "",
        last_name: profile.last_name || "",
        avatar_url: profile.avatar_url || ""
      };
      setProfileForm(profileData);
      setOriginalProfile(profileData);
      const invoicingData = {
        company_name: profile.company_name || "",
        company_number: profile.company_number || "",
        vat_number: profile.vat_number || "",
        street_address: profile.street_address || "",
        address_complement: profile.address_complement || "",
        zip_code: profile.zip_code || "",
        city: profile.city || "",
        country: profile.country || "",
        company_logo: profile.company_logo || "",
        accent_color: profile.accent_color || "#3b82f6"
      };
      setInvoicingForm(invoicingData);
      setOriginalInvoicingForm(invoicingData);
    }
  }, [profile]);
  useEffect(() => {
    if (team) {
      const teamData = {
        name: team.name,
        logo: team.logo || ""
      };
      setTeamForm(teamData);
      setOriginalTeam(teamData);
    }
  }, [team]);

  // Don't create default team automatically - let users do it manually when needed
  // useEffect(() => {
  //   const initializeTeam = async () => {
  //     if (!teamLoading && !team && user && profile) {
  //       try {
  //         await createTeam("My Team");
  //       } catch (error) {
  //         console.error("Error creating default team:", error);
  //       }
  //     }
  //   };
  //   
  //   initializeTeam();
  // }, [teamLoading, team, user, profile, createTeam]);

  // Fetch authentication providers used by the user
  useEffect(() => {
    const fetchAuthProviders = async () => {
      if (!user) return;
      try {
        const {
          data,
          error
        } = await supabase.auth.getUserIdentities();
        if (error) throw error;
        const providers = data?.identities?.map(identity => identity.provider) || [];
        setAuthProviders(providers);
      } catch (error) {
        console.error("Error fetching auth providers:", error);
      }
    };
    fetchAuthProviders();
  }, [user]);

  // Initialize Google Maps Places Autocomplete
  useEffect(() => {
    const initializeAutocomplete = async () => {
      try {
        const loader = new Loader({
          apiKey: "AIzaSyBdVl-cTICSwYKrZ95SuvNw7dbMuDt1KG0",
          version: "weekly",
          libraries: ["places"]
        });
        await loader.load();
        const autocomplete = new google.maps.places.Autocomplete(document.getElementById("street_address") as HTMLInputElement, {
          types: ["address"],
          fields: ["address_components", "formatted_address"]
        });
        autocomplete.addListener("place_changed", () => {
          const place = autocomplete.getPlace();
          if (place.address_components) {
            const addressComponents = place.address_components;
            let streetNumber = "";
            let route = "";
            let locality = "";
            let postalCode = "";
            let country = "";
            addressComponents.forEach(component => {
              const types = component.types;
              if (types.includes("street_number")) {
                streetNumber = component.long_name;
              }
              if (types.includes("route")) {
                route = component.long_name;
              }
              if (types.includes("locality")) {
                locality = component.long_name;
              }
              if (types.includes("postal_code")) {
                postalCode = component.long_name;
              }
              if (types.includes("country")) {
                country = component.long_name;
              }
            });
            setInvoicingForm(prev => ({
              ...prev,
              street_address: `${streetNumber} ${route}`.trim(),
              city: locality,
              zip_code: postalCode,
              country: country
            }));
          }
        });
      } catch (error) {
        console.error("Error initializing Google Maps:", error);
      }
    };
    initializeAutocomplete();
  }, []);

  // Profile handlers
  const handleProfileFormChange = (field: string, value: string) => {
    setProfileForm(prev => ({
      ...prev,
      [field]: value
    }));
  };
  const handleAvatarUpload = async (file: File) => {
    if (!user) return;
    const maxSize = 2 * 1024 * 1024; // 2MB
    if (file.size > maxSize) {
      toast({
        title: "Error",
        description: "File size must be less than 2MB",
        variant: "destructive"
      });
      return;
    }
    if (!file.type.startsWith('image/')) {
      toast({
        title: "Error",
        description: "Please upload an image file (JPG, PNG, GIF)",
        variant: "destructive"
      });
      return;
    }
    try {
      setAvatarUploading(true);
      const fileExt = file.name.split('.').pop();
      const fileName = `avatar.${fileExt}`;
      const filePath = `${user.id}/${fileName}`;
      const {
        error: uploadError
      } = await supabase.storage.from('avatars').upload(filePath, file, {
        upsert: true
      });
      if (uploadError) throw uploadError;
      const {
        data: {
          publicUrl
        }
      } = supabase.storage.from('avatars').getPublicUrl(filePath);
      setProfileForm(prev => ({
        ...prev,
        avatar_url: publicUrl
      }));
      toast({
        title: "Success",
        description: "Avatar uploaded successfully"
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to upload avatar",
        variant: "destructive"
      });
    } finally {
      setAvatarUploading(false);
    }
  };
  const handleSaveProfile = async () => {
    try {
      setProfileSaving(true);

      // Always use updateProfile hook which handles the logic properly
      await updateProfile(profileForm);
      setOriginalProfile(profileForm);
      toast({
        title: "Success",
        description: "Profile updated successfully"
      });
    } catch (error) {
      console.error("Error updating profile:", error);
      toast({
        title: "Error",
        description: "Failed to update profile",
        variant: "destructive"
      });
    } finally {
      setProfileSaving(false);
    }
  };

  // Team handlers
  const handleTeamFormChange = (field: string, value: string) => {
    setTeamForm(prev => ({
      ...prev,
      [field]: value
    }));
  };
  const handleTeamLogoUpload = async (file: File) => {
    if (!team) return;
    const maxSize = 2 * 1024 * 1024; // 2MB
    if (file.size > maxSize) {
      toast({
        title: "Error",
        description: "File size must be less than 2MB",
        variant: "destructive"
      });
      return;
    }
    if (!file.type.startsWith('image/')) {
      toast({
        title: "Error",
        description: "Please upload an image file (JPG, PNG, GIF)",
        variant: "destructive"
      });
      return;
    }
    try {
      setTeamLogoUploading(true);
      const updatedTeam = await uploadTeamLogo(file);
      if (updatedTeam) {
        setTeamForm(prev => ({
          ...prev,
          logo: updatedTeam.logo || ""
        }));
        toast({
          title: "Success",
          description: "Team logo uploaded successfully"
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to upload team logo",
        variant: "destructive"
      });
    } finally {
      setTeamLogoUploading(false);
    }
  };
  const handleSaveTeam = async () => {
    if (!teamForm.name.trim()) {
      toast({
        title: "Error",
        description: "Team name cannot be empty",
        variant: "destructive"
      });
      return;
    }
    try {
      setTeamSaving(true);
      const updates: any = {};
      if (teamForm.name.trim() !== originalTeam.name) {
        updates.name = teamForm.name.trim();
      }
      if (Object.keys(updates).length > 0) {
        const updatedTeam = await updateTeam(updates);
        if (updatedTeam) {
          setTeamForm(prev => ({
            ...prev,
            ...updatedTeam
          }));
          setOriginalTeam({
            ...originalTeam,
            ...updatedTeam
          });
        }
        toast({
          title: "Success",
          description: "Team settings updated successfully"
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update team settings",
        variant: "destructive"
      });
    } finally {
      setTeamSaving(false);
    }
  };
  const handleInviteUser = async () => {
    if (!inviteEmail.trim()) {
      toast({
        title: "Error",
        description: "Please enter an email address",
        variant: "destructive"
      });
      return;
    }
    try {
      setInviting(true);
      await inviteUser(inviteEmail.trim(), inviteRole);
      setInviteEmail("");
      setInviteRole("member");
      setShowInviteDialog(false);
      toast({
        title: "Success",
        description: "User invited successfully"
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to send invitation",
        variant: "destructive"
      });
    } finally {
      setInviting(false);
    }
  };

  // Security handlers
  const handlePasswordReset = async () => {
    if (!user?.email) return;
    try {
      setSendingPasswordReset(true);
      const {
        error
      } = await supabase.auth.resetPasswordForEmail(user.email, {
        redirectTo: `${window.location.origin}/reset-password`
      });
      if (error) throw error;
      setPasswordResetSent(true);
      toast({
        title: "Email sent",
        description: "Password reset instructions have been sent to your email"
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to send password reset email",
        variant: "destructive"
      });
    } finally {
      setSendingPasswordReset(false);
    }
  };

  // Invoicing handlers
  const handleInvoicingFormChange = (field: string, value: string) => {
    setInvoicingForm(prev => ({
      ...prev,
      [field]: value
    }));
  };
  const handleCompanyLogoUpload = useCallback(async (file: File) => {
    if (!profile?.user_id) return;
    const maxSize = 2 * 1024 * 1024; // 2MB
    if (file.size > maxSize) {
      toast({
        title: "Error",
        description: "File size must be less than 2MB",
        variant: "destructive"
      });
      return;
    }
    if (!file.type.startsWith('image/')) {
      toast({
        title: "Error",
        description: "Please upload an image file (JPG, PNG, GIF)",
        variant: "destructive"
      });
      return;
    }
    try {
      setLogoUploading(true);
      const fileExt = file.name.split('.').pop();
      const fileName = `${Date.now()}.${fileExt}`;
      const filePath = `${profile.user_id}/${fileName}`;
      const {
        error: uploadError
      } = await supabase.storage.from('company-logos').upload(filePath, file);
      if (uploadError) throw uploadError;
      const {
        data: {
          publicUrl
        }
      } = supabase.storage.from('company-logos').getPublicUrl(filePath);
      setInvoicingForm(prev => ({
        ...prev,
        company_logo: publicUrl
      }));
      toast({
        title: "Success",
        description: "Logo uploaded successfully"
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to upload logo",
        variant: "destructive"
      });
    } finally {
      setLogoUploading(false);
    }
  }, [profile?.user_id, toast]);
  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  }, []);
  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleCompanyLogoUpload(e.dataTransfer.files[0]);
    }
  }, [handleCompanyLogoUpload]);
  const handleSaveInvoicingSettings = async () => {
    try {
      setInvoicingSaving(true);
      await updateProfile(invoicingForm);
      setOriginalInvoicingForm(invoicingForm);
      toast({
        title: "Success",
        description: "Invoicing settings saved successfully"
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to save invoicing settings",
        variant: "destructive"
      });
    } finally {
      setInvoicingSaving(false);
    }
  };
  const getInitials = (firstName?: string, lastName?: string) => {
    return `${firstName?.charAt(0) || ''}${lastName?.charAt(0) || ''}`.toUpperCase() || 'U';
  };

  // Integration handlers
  const handleConnectStripe = async () => {
    try {
      await connectStripe();
      // Refresh profile data
      window.location.reload();
    } catch (error) {
      console.error("Error connecting Stripe:", error);
    }
  };

  const handleDisconnectStripe = async () => {
    try {
      await disconnectStripe();
      // Refresh profile data
      window.location.reload();
    } catch (error) {
      console.error("Error disconnecting Stripe:", error);
    }
  };
  return <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-xl md:text-2xl lg:text-3xl font-semibold tracking-tight">Settings</h1>
        
      </div>

      {/* Settings Tabs */}
      <Tabs defaultValue="profile" className="space-y-6">
        <TabsList className="grid w-full grid-cols-6">
          <TabsTrigger value="profile" className="flex items-center space-x-2">
            <User className="h-4 w-4" />
            <span className="hidden sm:inline">Profile</span>
          </TabsTrigger>
          <TabsTrigger value="team" className="flex items-center space-x-2">
            <Users className="h-4 w-4" />
            <span className="hidden sm:inline">Team</span>
          </TabsTrigger>
          <TabsTrigger value="billing" className="flex items-center space-x-2">
            <CreditCard className="h-4 w-4" />
            <span className="hidden sm:inline">Billing</span>
          </TabsTrigger>
          <TabsTrigger value="security" className="flex items-center space-x-2">
            <Shield className="h-4 w-4" />
            <span className="hidden sm:inline">Security</span>
          </TabsTrigger>
          <TabsTrigger value="invoicing" className="flex items-center space-x-2">
            <FileText className="h-4 w-4" />
            <span className="hidden sm:inline">Invoicing</span>
          </TabsTrigger>
          <TabsTrigger value="integrations" className="flex items-center space-x-2">
            <SettingsIcon className="h-4 w-4" />
            <span className="hidden sm:inline">Integrations</span>
          </TabsTrigger>
        </TabsList>

        {/* Profile Settings */}
        <TabsContent value="profile">
          <Card className="shadow-soft">
            <CardHeader>
              <CardTitle>Profile Settings</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {profileLoading ? <div className="flex items-center justify-center p-8">
                  <Loader2 className="h-6 w-6 animate-spin" />
                </div> : <>
                  {/* Profile Photo */}
                  <div className="flex items-center space-x-4">
                    <div className="relative">
                      <Avatar className="h-20 w-20">
                        <AvatarImage src={profileForm.avatar_url} />
                        <AvatarFallback className="text-lg">
                          {getInitials(profileForm.first_name, profileForm.last_name)}
                        </AvatarFallback>
                      </Avatar>
                      {avatarUploading && <div className="absolute inset-0 flex items-center justify-center bg-background/80 rounded-full">
                          <Loader2 className="h-4 w-4 animate-spin" />
                        </div>}
                    </div>
                    <div>
                      <Button variant="outline" size="sm" onClick={() => profileAvatarRef.current?.click()} disabled={avatarUploading}>
                        <Camera className="h-4 w-4 mr-2" />
                        Change Photo
                      </Button>
                      <p className="text-xs text-muted-foreground mt-1">
                        JPG, PNG or GIF. Max size 2MB.
                      </p>
                      <input ref={profileAvatarRef} type="file" accept="image/*" onChange={e => {
                    if (e.target.files && e.target.files[0]) {
                      handleAvatarUpload(e.target.files[0]);
                    }
                  }} className="hidden" />
                    </div>
                  </div>

                  {/* Basic Info */}
                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="space-y-2">
                      <Label htmlFor="firstName">First Name</Label>
                      <Input id="firstName" value={profileForm.first_name} onChange={e => handleProfileFormChange("first_name", e.target.value)} placeholder="Enter first name" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="lastName">Last Name</Label>
                      <Input id="lastName" value={profileForm.last_name} onChange={e => handleProfileFormChange("last_name", e.target.value)} placeholder="Enter last name" />
                    </div>
                    <div className="space-y-2 md:col-span-2">
                      <Label htmlFor="email">Email</Label>
                      <Input id="email" type="email" value={user?.email || ""} disabled className="bg-muted" />
                      <p className="text-xs text-muted-foreground">
                        Email cannot be changed here. Use the Security tab to manage your account.
                      </p>
                    </div>
                  </div>

                </>}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Team Settings */}
        <TabsContent value="team">
          <div className="space-y-6">
            {/* Team Info */}
            <Card className="shadow-soft">
              <CardHeader>
                <div className="flex items-center space-x-4">
                  
                  <div>
                    <CardTitle>Team Settings</CardTitle>
                    
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                {teamLoading ? <div className="flex items-center justify-center p-8">
                    <Loader2 className="h-6 w-6 animate-spin" />
                  </div> : <>
                    {/* Team Logo */}
                    <div className="flex items-center space-x-4">
                      <div className="relative">
                        <Avatar className="h-20 w-20">
                          <AvatarImage src={teamForm.logo} />
                          <AvatarFallback className="text-lg">
                            {teamForm.name.charAt(0).toUpperCase() || 'T'}
                          </AvatarFallback>
                        </Avatar>
                        {teamLogoUploading && <div className="absolute inset-0 flex items-center justify-center bg-background/80 rounded-full">
                            <Loader2 className="h-4 w-4 animate-spin" />
                          </div>}
                      </div>
                      <div>
                        <Button variant="outline" size="sm" onClick={() => teamLogoRef.current?.click()} disabled={teamLogoUploading}>
                          <Upload className="h-4 w-4 mr-2" />
                          Change Logo
                        </Button>
                        <p className="text-xs text-muted-foreground mt-1">
                          JPG, PNG or GIF. Max size 2MB.
                        </p>
                        <input ref={teamLogoRef} type="file" accept="image/*" onChange={e => {
                      if (e.target.files && e.target.files[0]) {
                        handleTeamLogoUpload(e.target.files[0]);
                      }
                    }} className="hidden" />
                      </div>
                    </div>

                    {/* Team Name */}
                    <div className="space-y-2">
                      <Label htmlFor="teamName">Team Name</Label>
                      <Input id="teamName" value={teamForm.name} onChange={e => handleTeamFormChange("name", e.target.value)} placeholder="Enter team name" />
                    </div>

                  </>}
              </CardContent>
            </Card>

            {/* Team Members */}
            <Card className="shadow-soft">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>Team Members</CardTitle>
                <Dialog open={showInviteDialog} onOpenChange={setShowInviteDialog}>
                  <DialogTrigger asChild>
                    <Button variant="dark">
                      <Plus className="h-4 w-4 mr-2" />
                      Invite User
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Invite Team Member</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="inviteEmail">Email Address</Label>
                        <Input id="inviteEmail" type="email" value={inviteEmail} onChange={e => setInviteEmail(e.target.value)} placeholder="Enter email address" />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="inviteRole">Role</Label>
                        <select id="inviteRole" value={inviteRole} onChange={e => setInviteRole(e.target.value)} className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm shadow-sm transition-colors">
                          <option value="member">Member</option>
                          <option value="admin">Admin</option>
                        </select>
                      </div>
                      <Button className="w-full bg-gradient-primary" onClick={handleInviteUser} disabled={inviting}>
                        {inviting ? "Sending..." : "Send Invitation"}
                      </Button>
                    </div>
                  </DialogContent>
                </Dialog>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {teamMembers.map(member => <div key={member.id} className="flex items-center justify-between p-4 border border-border rounded-lg">
                      <div className="flex items-center space-x-3">
                        <Avatar className="h-10 w-10">
                          <AvatarImage src={member.profiles?.avatar_url} />
                          <AvatarFallback>
                            {getInitials(member.profiles?.first_name, member.profiles?.last_name)}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium">
                            {member.profiles?.first_name && member.profiles?.last_name ? `${member.profiles.first_name} ${member.profiles.last_name}` : "Unknown User"}
                          </p>
                          <p className="text-sm text-muted-foreground">{member.user_id}</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Badge variant={member.role === "owner" ? "default" : "secondary"}>
                          {member.role === "owner" && <Crown className="h-3 w-3 mr-1" />}
                          {member.role}
                        </Badge>
                        {member.role !== "owner" && <Button variant="ghost" size="icon">
                            <Trash2 className="h-4 w-4 text-destructive" />
                          </Button>}
                      </div>
                    </div>)}

                  {/* Pending Invites */}
                  {invites.length > 0 && <div className="space-y-2">
                      <h4 className="text-sm font-medium text-muted-foreground">Pending Invitations</h4>
                      {invites.map(invite => <div key={invite.id} className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                          <div className="flex items-center space-x-3">
                            <Mail className="h-5 w-5 text-muted-foreground" />
                            <div>
                              <p className="font-medium">{invite.email}</p>
                              <p className="text-sm text-muted-foreground">Invited {new Date(invite.created_at).toLocaleDateString()}</p>
                            </div>
                          </div>
                          <Badge variant="outline">Pending</Badge>
                        </div>)}
                    </div>}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Billing Settings */}
        <TabsContent value="billing">
          <div className="space-y-6">
            {/* Current Plan */}
            <Card className="shadow-soft">
              <CardHeader>
                <CardTitle>Current Plan</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between p-4 bg-gradient-primary rounded-lg text-primary-foreground">
                  <div>
                    <h3 className="text-lg font-semibold">Professional Plan</h3>
                    <p className="text-primary-foreground/80">€18/month for up to 3 users</p>
                    <p className="text-sm text-primary-foreground/60">7 days remaining in trial</p>
                  </div>
                  <Button variant="secondary">
                    Upgrade Plan
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Usage */}
            <Card className="shadow-soft">
              <CardHeader>
                <CardTitle>Usage</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Team Members</span>
                    <span>{teamMembers.length} / 3</span>
                  </div>
                  <div className="w-full bg-muted rounded-full h-2">
                    <div className="bg-primary h-2 rounded-full" style={{
                    width: `${teamMembers.length / 3 * 100}%`
                  }} />
                  </div>
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Projects</span>
                    <span>4 / Unlimited</span>
                  </div>
                  <div className="w-full bg-muted rounded-full h-2">
                    <div className="bg-success h-2 rounded-full" style={{
                    width: "20%"
                  }} />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Payment Method */}
            <Card className="shadow-soft">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>Payment Method</CardTitle>
                <Button variant="outline" size="sm">Add Method</Button>
              </CardHeader>
              <CardContent>
                <div className="flex items-center space-x-3 p-4 border border-border rounded-lg">
                  <div className="h-8 w-12 bg-gradient-primary rounded flex items-center justify-center">
                    <CreditCard className="h-4 w-4 text-primary-foreground" />
                  </div>
                  <div className="flex-1">
                    <p className="font-medium">•••• •••• •••• 4242</p>
                    <p className="text-sm text-muted-foreground">Expires 12/25</p>
                  </div>
                  <Button variant="ghost" size="sm">Edit</Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Security Settings */}
        <TabsContent value="security">
          <div className="space-y-6">
            {/* Authentication Methods */}
            <Card className="shadow-soft">
              <CardHeader>
                <CardTitle>Authentication Methods</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-sm text-muted-foreground">
                  Here are the authentication methods associated with your account.
                </p>
                <div className="space-y-3">
                  {authProviders.includes('email') && <div className="flex items-center justify-between p-4 border border-border rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className="h-10 w-10 bg-primary/10 rounded-lg flex items-center justify-center">
                          <Mail className="h-5 w-5 text-primary" />
                        </div>
                        <div>
                          <p className="font-medium">Email & Password</p>
                          <p className="text-sm text-muted-foreground">{user?.email}</p>
                        </div>
                      </div>
                      <Badge variant="secondary">Active</Badge>
                    </div>}
                  
                  {authProviders.includes('google') && <div className="flex items-center justify-between p-4 border border-border rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className="h-10 w-10 bg-primary/10 rounded-lg flex items-center justify-center">
                          <svg className="h-5 w-5" viewBox="0 0 24 24">
                            <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                            <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                            <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" />
                            <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" />
                          </svg>
                        </div>
                        <div>
                          <p className="font-medium">Google</p>
                          <p className="text-sm text-muted-foreground">Connected via Google OAuth</p>
                        </div>
                      </div>
                      <Badge variant="secondary">Active</Badge>
                    </div>}
                  
                  {authProviders.length === 0 && <div className="text-center p-4 text-muted-foreground">
                      <p>Loading authentication methods...</p>
                    </div>}
                </div>
              </CardContent>
            </Card>

            <Card className="shadow-soft">
              <CardHeader>
                <CardTitle>Password</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-sm text-muted-foreground">
                  To change your password, we'll send a secure reset link to your email address.
                </p>
                {passwordResetSent ? <div className="p-4 bg-success/10 border border-success/20 rounded-lg">
                    <p className="text-sm text-success">
                      Password reset instructions have been sent to your email address.
                    </p>
                  </div> : <Button className="bg-gradient-primary" onClick={handlePasswordReset} disabled={sendingPasswordReset || !authProviders.includes('email')}>
                    {sendingPasswordReset ? "Sending..." : "Send Password Reset Email"}
                  </Button>}
                {!authProviders.includes('email') && <p className="text-xs text-muted-foreground">
                    Password reset is only available for email-based accounts.
                  </p>}
              </CardContent>
            </Card>

            <Card className="shadow-soft">
              <CardHeader>
                <CardTitle>Two-Factor Authentication</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">Authenticator App</p>
                    <p className="text-sm text-muted-foreground">
                      Use an authenticator app to generate verification codes
                    </p>
                  </div>
                  <Button variant="outline">Enable</Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Invoicing Settings */}
        <TabsContent value="invoicing">
          <Card className="shadow-soft">
            <CardHeader>
              <CardTitle>Invoicing Settings</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {profileLoading ? <div className="flex items-center justify-center p-8">
                  <Loader2 className="h-6 w-6 animate-spin" />
                </div> : <>
                  {/* Company Information */}
                  <div className="space-y-4">
                    <h3 className="text-lg font-medium">Company Information</h3>
                    <div className="grid gap-4 md:grid-cols-2">
                      <div className="space-y-2">
                        <Label htmlFor="company_name">Company Name</Label>
                        <Input id="company_name" value={invoicingForm.company_name} onChange={e => handleInvoicingFormChange("company_name", e.target.value)} placeholder="Enter company name" />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="company_number">Company Number</Label>
                        <Input id="company_number" value={invoicingForm.company_number} onChange={e => handleInvoicingFormChange("company_number", e.target.value)} placeholder="Enter company registration number" />
                      </div>
                      <div className="space-y-2 md:col-span-2">
                        <Label htmlFor="vat_number">VAT Number</Label>
                        <Input id="vat_number" value={invoicingForm.vat_number} onChange={e => handleInvoicingFormChange("vat_number", e.target.value)} placeholder="Enter VAT number" />
                      </div>
                    </div>
                  </div>

                  {/* Branding */}
                  <div className="space-y-4">
                    <h3 className="text-lg font-medium">Branding</h3>
                    <div className="grid gap-4 md:grid-cols-2">
                      <div className="space-y-2">
                        <Label>Company Logo</Label>
                        {invoicingForm.company_logo ? <div className="space-y-3">
                            <div className="flex items-center space-x-3 p-3 border border-border rounded-lg">
                              <img src={invoicingForm.company_logo} alt="Company logo" className="h-12 w-12 object-contain rounded" />
                              <div className="flex-1">
                                <p className="text-sm font-medium">Current logo</p>
                                <p className="text-xs text-muted-foreground">Click to remove</p>
                              </div>
                              <Button variant="ghost" size="icon" onClick={() => setInvoicingForm(prev => ({
                          ...prev,
                          company_logo: ""
                        }))} type="button">
                                <X className="h-4 w-4" />
                              </Button>
                            </div>
                            <div className="text-center">
                              <Button variant="outline" size="sm" onClick={() => document.getElementById('logo-upload')?.click()} disabled={logoUploading} type="button">
                                <Upload className="h-4 w-4 mr-2" />
                                Replace Logo
                              </Button>
                            </div>
                          </div> : <div className={`border-2 border-dashed rounded-lg p-6 text-center cursor-pointer transition-colors ${dragActive ? 'border-primary bg-primary/5' : 'border-border hover:border-primary/50'}`} onDragEnter={handleDrag} onDragLeave={handleDrag} onDragOver={handleDrag} onDrop={handleDrop} onClick={() => document.getElementById('logo-upload')?.click()}>
                            {logoUploading ? <div className="flex flex-col items-center space-y-2">
                                <Loader2 className="h-8 w-8 animate-spin" />
                                <p className="text-sm text-muted-foreground">Uploading...</p>
                              </div> : <div className="flex flex-col items-center space-y-2">
                                <Upload className="h-8 w-8 text-muted-foreground" />
                                <div>
                                  <p className="text-sm font-medium">Drop your logo here, or click to browse</p>
                                  <p className="text-xs text-muted-foreground">PNG, JPG, GIF up to 2MB</p>
                                </div>
                              </div>}
                          </div>}
                        <input id="logo-upload" type="file" accept="image/*" onChange={e => {
                      if (e.target.files && e.target.files[0]) {
                        handleCompanyLogoUpload(e.target.files[0]);
                      }
                    }} className="hidden" />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="accent_color">Accent Color</Label>
                        <div className="flex space-x-2">
                          <Input id="accent_color" type="color" value={invoicingForm.accent_color} onChange={e => handleInvoicingFormChange("accent_color", e.target.value)} className="w-16 h-10 p-1 border rounded" />
                          <Input value={invoicingForm.accent_color} onChange={e => handleInvoicingFormChange("accent_color", e.target.value)} placeholder="#3b82f6" className="flex-1" />
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Address Information */}
                  <div className="space-y-4">
                    <h3 className="text-lg font-medium">Address Information</h3>
                    <div className="grid gap-4 md:grid-cols-2">
                      <div className="space-y-2 md:col-span-2">
                        <Label htmlFor="street_address">Street Address</Label>
                        <Input id="street_address" value={invoicingForm.street_address} onChange={e => handleInvoicingFormChange("street_address", e.target.value)} placeholder="Start typing your address..." />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="address_complement">Address Complement (Optional)</Label>
                        <Input id="address_complement" value={invoicingForm.address_complement} onChange={e => handleInvoicingFormChange("address_complement", e.target.value)} placeholder="Apartment, suite, etc." />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="zip_code">Zip Code</Label>
                        <Input id="zip_code" value={invoicingForm.zip_code} onChange={e => handleInvoicingFormChange("zip_code", e.target.value)} placeholder="Enter zip code" />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="city">City</Label>
                        <Input id="city" value={invoicingForm.city} onChange={e => handleInvoicingFormChange("city", e.target.value)} placeholder="Enter city" />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="country">Country</Label>
                        <Input id="country" value={invoicingForm.country} onChange={e => handleInvoicingFormChange("country", e.target.value)} placeholder="Enter country" />
                      </div>
                    </div>
                  </div>

                </>}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Integrations Settings */}
        <TabsContent value="integrations">
          <div className="space-y-6">
            {/* Stripe Integration */}
            <Card className="shadow-soft">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <CreditCard className="h-5 w-5" />
                  <span>Stripe Integration</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between p-4 border border-border rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className="h-10 w-10 bg-primary/10 rounded-lg flex items-center justify-center">
                      <CreditCard className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <p className="font-medium">Stripe Payment Processing</p>
                      <p className="text-sm text-muted-foreground">
                        {profile?.stripe_connected ? "Connect your Stripe account to receive payments on invoices" : "Not connected"}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    {profile?.stripe_connected ? (
                      <>
                        <CheckCircle className="h-5 w-5 text-green-500" />
                        <Badge variant="secondary">Connected</Badge>
                        <Button 
                          variant="outline" 
                          size="sm" 
                          onClick={handleDisconnectStripe}
                          disabled={integrationsLoading}
                        >
                          {integrationsLoading ? "Disconnecting..." : "Disconnect"}
                        </Button>
                      </>
                    ) : (
                      <>
                        <AlertCircle className="h-5 w-5 text-orange-500" />
                        <Badge variant="outline">Not Connected</Badge>
                        <Button 
                          variant="default" 
                          size="sm"
                          onClick={handleConnectStripe}
                          disabled={integrationsLoading}
                        >
                          {integrationsLoading ? "Connecting..." : "Connect Stripe"}
                        </Button>
                      </>
                    )}
                  </div>
                </div>
                
                {profile?.stripe_connected && (
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <p className="text-sm text-green-800">
                      <CheckCircle className="h-4 w-4 inline mr-1" />
                      Stripe is connected and ready to process payments on your invoices.
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Email Settings */}
            <Card className="shadow-soft">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Mail className="h-5 w-5" />
                  <span>Email Settings</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between p-4 border border-border rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className="h-10 w-10 bg-primary/10 rounded-lg flex items-center justify-center">
                      <Mail className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <p className="font-medium">Email Delivery Service</p>
                      <p className="text-sm text-muted-foreground">
                        Send professional invoices and quotes via email
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="h-5 w-5 text-green-500" />
                    <Badge variant="secondary">Active</Badge>
                  </div>
                </div>
                
                <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                  <p className="text-sm text-blue-800">
                    <Mail className="h-4 w-4 inline mr-1" />
                    Email service is configured and ready to send invoices and quotes to your customers.
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* Integration Features */}
            <Card className="shadow-soft">
              <CardHeader>
                <CardTitle>Available Features</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="p-4 border border-border rounded-lg">
                    <div className="flex items-center space-x-2 mb-2">
                      <CreditCard className="h-4 w-4 text-primary" />
                      <h4 className="font-medium">Invoice Payments</h4>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      Add payment links to invoices for faster collection
                    </p>
                  </div>
                  
                  <div className="p-4 border border-border rounded-lg">
                    <div className="flex items-center space-x-2 mb-2">
                      <Mail className="h-4 w-4 text-primary" />
                      <h4 className="font-medium">Email Templates</h4>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      Professional email templates for quotes and invoices
                    </p>
                  </div>
                  
                  <div className="p-4 border border-border rounded-lg">
                    <div className="flex items-center space-x-2 mb-2">
                      <FileText className="h-4 w-4 text-primary" />
                      <h4 className="font-medium">PDF Generation</h4>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      Automatic PDF attachments for all documents
                    </p>
                  </div>
                  
                  <div className="p-4 border border-border rounded-lg">
                    <div className="flex items-center space-x-2 mb-2">
                      <CheckCircle className="h-4 w-4 text-primary" />
                      <h4 className="font-medium">Payment Tracking</h4>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      Real-time payment status updates and notifications
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>

      <SaveChangesBar isDirty={hasProfileChanges || hasTeamChanges || hasInvoicingChanges} onSave={() => {
      if (hasProfileChanges) handleSaveProfile();
      if (hasTeamChanges) handleSaveTeam();
      if (hasInvoicingChanges) handleSaveInvoicingSettings();
    }} isLoading={profileSaving || teamSaving || invoicingSaving} />
    </div>;
}
