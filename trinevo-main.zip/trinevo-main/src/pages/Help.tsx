import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Button } from "@/components/ui/button";
import { Mail, MessageCircle } from "lucide-react";

export default function Help() {
  const faqs = [
    {
      question: "How do I create a new quote?",
      answer: "Navigate to the Quotes section and click the 'New Quote' button. Fill in the customer details, add line items, and save your quote."
    },
    {
      question: "How can I convert a quote to an invoice?",
      answer: "Open the quote you want to convert and click the 'Convert to Invoice' button. This will create a new invoice with the same details."
    },
    {
      question: "How do I manage my customers?",
      answer: "Go to the Customers section to add, edit, or view customer information. You can also import customers from a CSV file."
    },
    {
      question: "Can I export my invoices to PDF?",
      answer: "Yes, you can export any invoice to PDF by opening the invoice and clicking the 'Download PDF' button."
    },
    {
      question: "How do I track project progress?",
      answer: "Use the Projects section to create projects and track their status. You can also use the Tasks section for detailed task management."
    },
    {
      question: "How do I set up team collaboration?",
      answer: "Invite team members through the Settings page. They'll receive an email invitation to join your workspace."
    },
    {
      question: "Can I customize my invoice templates?",
      answer: "Currently, invoices use a standard template. Customization options will be available in future updates."
    },
    {
      question: "How do I change my account settings?",
      answer: "Click on your profile picture in the top right corner and select 'Settings' to update your account information."
    },
    {
      question: "Is my data secure?",
      answer: "Yes, all data is encrypted and stored securely. We use industry-standard security practices to protect your information."
    },
    {
      question: "How do I contact support?",
      answer: "You can reach out to our support team using the contact information at the bottom of this page."
    }
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-col space-y-2">
        <h1 className="text-xl md:text-2xl lg:text-3xl font-semibold tracking-tight">Help & Support</h1>
        <p className="text-muted-foreground">
          Find answers to common questions and get help with using Trinevo.
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        <div className="md:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>Frequently Asked Questions</CardTitle>
              <CardDescription>
                Browse through our most common questions and answers.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Accordion type="single" collapsible className="w-full">
                {faqs.map((faq, index) => (
                  <AccordionItem key={index} value={`item-${index}`}>
                    <AccordionTrigger className="text-left">
                      {faq.question}
                    </AccordionTrigger>
                    <AccordionContent className="text-muted-foreground">
                      {faq.answer}
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Need More Help?</CardTitle>
              <CardDescription>
                Can't find what you're looking for? Get in touch with our support team.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Button className="w-full" variant="outline">
                <Mail className="mr-2 h-4 w-4" />
                Email Support
              </Button>
              <Button className="w-full" variant="outline">
                <MessageCircle className="mr-2 h-4 w-4" />
                Live Chat
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Quick Tips</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 text-sm">
              <div>
                <strong>Keyboard Shortcuts:</strong>
                <p className="text-muted-foreground">Press Ctrl+K to open the search menu</p>
              </div>
              <div>
                <strong>Bulk Actions:</strong>
                <p className="text-muted-foreground">Select multiple items to perform bulk operations</p>
              </div>
              <div>
                <strong>Auto-save:</strong>
                <p className="text-muted-foreground">Your work is automatically saved as you type</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}