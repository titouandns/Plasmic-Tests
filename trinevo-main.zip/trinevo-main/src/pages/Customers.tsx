import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { StatusBadge } from "@/components/StatusBadge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";
import { 
  Plus, 
  Search, 
  MoreHorizontal,
  Check,
  X,
  Edit,
  Trash2,
  Copy,
  Eye,
  Upload
} from "lucide-react";
import { SearchIcon } from "@/components/LottieIcon";
import { useCustomers } from "@/hooks/useSupabase";
import { supabase } from "@/integrations/supabase/client";
import { CSVImportModal } from "@/components/csv/CSVImportModal";

type SortOption = "company_asc" | "company_desc" | "created_asc" | "created_desc" | "total_asc" | "total_desc";

type FilterOptions = {
  status: string[];
  dateRange: "all" | "month" | "30days" | "custom";
  customDateFrom?: Date;
  customDateTo?: Date;
  hasProject: "all" | "yes" | "no";
};

export function Customers() {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState("");
  const [showQuickAdd, setShowQuickAdd] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  
  // Filter and Sort State
  const [showFilters, setShowFilters] = useState(false);
  const [sortBy, setSortBy] = useState<SortOption>("created_desc");
  const [filters, setFilters] = useState<FilterOptions>({
    status: [],
    dateRange: "all",
    hasProject: "all"
  });
  const [editData, setEditData] = useState<{
    company_name: string;
    contact_name: string;
    email: string;
    phone: string;
    status: "lead" | "active" | "inactive";
  }>({
    company_name: "",
    contact_name: "",
    email: "",
    phone: "",
    status: "lead"
  });
  const [newCustomer, setNewCustomer] = useState<{
    company_name: string;
    contact_name: string;
    email: string;
    phone: string;
    status: "lead" | "active" | "inactive";
  }>({
    company_name: "",
    contact_name: "",
    email: "",
    phone: "",
    status: "lead"
  });
  const { customers, loading, addCustomer, updateCustomer, refetch } = useCustomers();
  const { toast } = useToast();
  const [deleteCustomerId, setDeleteCustomerId] = useState<string | null>(null);
  const [showImportModal, setShowImportModal] = useState(false);

  // Format address for display
  const formatAddress = (customer: any) => {
    const parts = [
      customer.street_address,
      customer.city,
      customer.state_region,
      customer.postcode,
      customer.country
    ].filter(Boolean);
    
    return parts.length > 0 ? parts.join(', ') : customer.billing_address || '';
  };

  const getAvatarColor = (name: string) => {
    const colors = [
      "hsl(210, 40%, 85%)", "hsl(200, 45%, 85%)", "hsl(190, 40%, 85%)",
      "hsl(180, 35%, 85%)", "hsl(170, 40%, 85%)", "hsl(160, 45%, 85%)",
      "hsl(150, 40%, 85%)", "hsl(140, 35%, 85%)", "hsl(130, 40%, 85%)",
      "hsl(120, 45%, 85%)", "hsl(60, 40%, 85%)", "hsl(50, 45%, 85%)",
      "hsl(40, 40%, 85%)", "hsl(30, 45%, 85%)", "hsl(20, 40%, 85%)",
      "hsl(10, 35%, 85%)", "hsl(350, 40%, 85%)", "hsl(340, 45%, 85%)",
      "hsl(330, 40%, 85%)", "hsl(320, 35%, 85%)"
    ];
    let hash = 0;
    for (let i = 0; i < name.length; i++) {
      hash = name.charCodeAt(i) + ((hash << 5) - hash);
    }
    return colors[Math.abs(hash) % colors.length];
  };

  const handleQuickAdd = async () => {
    if (!newCustomer.company_name && !newCustomer.contact_name) return;
    
    await addCustomer(newCustomer);
    setNewCustomer({
      company_name: "",
      contact_name: "",
      email: "",
      phone: "",
      status: "lead"
    });
    setShowQuickAdd(false);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      handleQuickAdd();
    }
    if (e.key === "Escape") {
      setShowQuickAdd(false);
      setNewCustomer({
        company_name: "",
        contact_name: "",
        email: "",
        phone: "",
        status: "lead"
      });
    }
  };

  const handleEditCustomer = (customer: any) => {
    setEditingId(customer.id);
    setEditData({
      company_name: customer.company_name,
      contact_name: customer.contact_name,
      email: customer.email,
      phone: customer.phone || "",
      status: customer.status
    });
  };

  const handleSaveEdit = async () => {
    if (!editingId) return;
    
    await updateCustomer(editingId, editData);
    setEditingId(null);
    setEditData({
      company_name: "",
      contact_name: "",
      email: "",
      phone: "",
      status: "lead"
    });
  };

  const handleCancelEdit = () => {
    setEditingId(null);
    setEditData({
      company_name: "",
      contact_name: "",
      email: "",
      phone: "",
      status: "lead"
    });
  };

  const handleNavigateToCustomer = (customerId: string) => {
    navigate(`/customers/${customerId}`);
  };

  // Quick Actions Handlers
  const handleDuplicateCustomer = async (customer: any) => {
    const duplicatedCustomer = {
      company_name: `${customer.company_name} (Copy)`,
      contact_name: customer.contact_name,
      email: customer.email,
      phone: customer.phone,
      status: customer.status,
      street_address: customer.street_address,
      city: customer.city,
      postcode: customer.postcode,
      country: customer.country,
      state_region: customer.state_region,
      notes: customer.notes
    };
    
    await addCustomer(duplicatedCustomer);
    toast({
      title: "Customer duplicated",
      description: "A copy of the customer has been created successfully.",
    });
  };

  const handleDeleteCustomer = async () => {
    if (!deleteCustomerId) return;
    
    try {
      const { error } = await supabase
        .from('customers')
        .delete()
        .eq('id', deleteCustomerId);

      if (error) throw error;

      toast({
        title: "Customer deleted",
        description: "Customer has been permanently deleted.",
      });
      
      setDeleteCustomerId(null);
      // Refetch customers to update the UI
      await refetch();
    } catch (error) {
      console.error('Error deleting customer:', error);
      toast({
        title: "Error",
        description: "Failed to delete customer. Please try again.",
        variant: "destructive",
      });
    }
  };

  // Status Update Handler
  const handleStatusUpdate = async (customerId: string, newStatus: "lead" | "active" | "inactive") => {
    await updateCustomer(customerId, { status: newStatus });
    toast({
      title: "Status updated",
      description: `Customer status changed to ${newStatus}.`,
    });
  };



  // Filter and Sort logic
  const getFilteredAndSortedCustomers = () => {
    let filtered = customers.filter(customer => {
      // Search filter - handle null/undefined values
      const searchLower = searchTerm.toLowerCase();
      const companyName = (customer.company_name || '').toLowerCase();
      const contactName = (customer.contact_name || '').toLowerCase(); 
      const email = (customer.email || '').toLowerCase();
      
      const matchesSearch = companyName.includes(searchLower) ||
                           contactName.includes(searchLower) ||
                           email.includes(searchLower);
      
      if (!matchesSearch) return false;
      
      // Status filter
      if (filters.status.length > 0 && !filters.status.includes(customer.status)) {
        return false;
      }
      
      // Date range filter
      if (filters.dateRange !== "all") {
        const customerDate = new Date(customer.created_at);
        const now = new Date();
        
        switch (filters.dateRange) {
          case "month": {
            const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
            if (customerDate < startOfMonth) return false;
            break;
          }
          case "30days": {
            const thirtyDaysAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
            if (customerDate < thirtyDaysAgo) return false;
            break;
          }
          case "custom": {
            if (filters.customDateFrom && customerDate < filters.customDateFrom) return false;
            if (filters.customDateTo && customerDate > filters.customDateTo) return false;
            break;
          }
        }
      }
      
      // TODO: Has project filter - will be implemented when projects are available
      
      return true;
    });
    
    // Sort
    filtered.sort((a, b) => {
      switch (sortBy) {
        case "company_asc":
          return (a.company_name || '').localeCompare(b.company_name || '');
        case "company_desc":
          return (b.company_name || '').localeCompare(a.company_name || '');
        case "created_asc":
          return new Date(a.created_at).getTime() - new Date(b.created_at).getTime();
        case "created_desc":
          return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
        case "total_asc":
        case "total_desc":
          // TODO: Implement when total paid data is available
          return 0;
        default:
          return 0;
      }
    });
    
    return filtered;
  };

  const filteredCustomers = getFilteredAndSortedCustomers();

  // Clear filters function
  const clearFilters = () => {
    setFilters({
      status: [],
      dateRange: "all",
      hasProject: "all"
    });
    setSortBy("created_desc");
  };

  // Get active filters count
  const getActiveFiltersCount = () => {
    let count = 0;
    if (filters.status.length > 0) count++;
    if (filters.dateRange !== "all") count++;
    if (filters.hasProject !== "all") count++;
    return count;
  };

  if (loading) {
    return <div className="p-6">Loading customers...</div>;
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl md:text-2xl lg:text-3xl">Customers</h1>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => setShowImportModal(true)} className="border-gray-300">
            <Upload className="h-4 w-4 mr-2" />
            Import CSV
          </Button>
          <Button variant="dark" onClick={() => navigate('/customers/new')}>
            <Plus className="h-4 w-4 mr-2" />
            Add Customer
          </Button>
        </div>
      </div>

      {/* Search and Filters */}
      <Card className="shadow-none">
        <CardContent className="p-0 border-none shadow-none">
          <div className="flex items-center space-x-4 border-none">
            <div className="relative flex-1 group">
              <div className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4">
                <SearchIcon delay={150} onHover={true} />
              </div>
              <Input
                placeholder="Search customers..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full h-8 rounded-xl px-3 pl-10 text-sm bg-gray-100 border border-gray-300 placeholder:text-gray-500 text-gray-900 focus-visible:ring-2 focus-visible:ring-gray-200 transition duration-200 ease-in-out outline-none disabled:opacity-70 disabled:cursor-not-allowed"
              />
            </div>
            
            {/* Filters */}
            <div className="flex gap-2">
              <Select value={filters.status.length === 1 ? filters.status[0] : "all"} onValueChange={(value) => {
                if (value === "all") {
                  setFilters(prev => ({ ...prev, status: [] }));
                } else {
                  setFilters(prev => ({ ...prev, status: [value] }));
                }
              }}>
                <SelectTrigger className="w-[140px]">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="lead">Lead</SelectItem>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="inactive">Inactive</SelectItem>
                </SelectContent>
              </Select>

              <Select value={sortBy} onValueChange={(value: SortOption) => setSortBy(value)}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Sort by..." />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="company_asc">Company A-Z</SelectItem>
                  <SelectItem value="company_desc">Company Z-A</SelectItem>
                  <SelectItem value="created_desc">Newest First</SelectItem>
                  <SelectItem value="created_asc">Oldest First</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
          </div>
          
          {/* Active Filters Display */}
          {(searchTerm || getActiveFiltersCount() > 0) && (
            <div className="flex items-center gap-2 mt-3 pt-3 border-t">
              <span className="text-sm text-muted-foreground">
                Showing {filteredCustomers.length} of {customers.length} customers
              </span>
              {filters.status.length > 0 && (
                <div className="flex gap-1">
                  {filters.status.map(status => (
                    <Badge key={status} variant="secondary" className="text-xs">
                      Status: {status}
                      <X 
                        className="h-3 w-3 ml-1 cursor-pointer" 
                        onClick={() => setFilters(prev => ({
                          ...prev,
                          status: prev.status.filter(s => s !== status)
                        }))}
                      />
                    </Badge>
                  ))}
                </div>
              )}
              {filters.dateRange !== "all" && (
                <Badge variant="secondary" className="text-xs">
                  Date: {filters.dateRange}
                  <X 
                    className="h-3 w-3 ml-1 cursor-pointer" 
                    onClick={() => setFilters(prev => ({ ...prev, dateRange: "all" }))}
                  />
                </Badge>
              )}
            </div>
          )}
        </CardContent>
      </Card>


      {/* Customer Table */}
      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <div className="min-w-[900px]">
              {/* Custom header that matches input styling */}
              <div className="flex h-8 w-full rounded-xl px-4 py-2 text-sm bg-gray-100 border border-gray-300 text-gray-500 mb-0 items-center">
                <div className="w-12 text-left"></div>
                <div className="w-48 font-medium text-left pl-0">Company</div>
                <div className="w-48 font-medium text-left">Contact</div>
                <div className="w-64 font-medium text-left">Email</div>
                <div className="w-40 font-medium text-left">Phone</div>
                <div className="w-32 font-medium text-left">Status</div>
                <div className="w-20 font-medium text-right">Actions</div>
              </div>
              <Table>
              <TableBody>
                {/* Quick Add Row */}
                {showQuickAdd ? (
                  <TableRow className="bg-muted/30">
                    <TableCell>
                      <Avatar className="h-8 w-8">
                        <AvatarFallback className="text-xs bg-muted">
                          {newCustomer.company_name.charAt(0).toUpperCase() || "?"}
                        </AvatarFallback>
                      </Avatar>
                    </TableCell>
                    <TableCell>
                      <Input
                        placeholder="Company name"
                        value={newCustomer.company_name}
                        onChange={(e) => setNewCustomer({ ...newCustomer, company_name: e.target.value })}
                        onKeyDown={handleKeyPress}
                        className="h-8"
                        autoFocus
                      />
                    </TableCell>
                    <TableCell>
                      <Input
                        placeholder="Contact name"
                        value={newCustomer.contact_name}
                        onChange={(e) => setNewCustomer({ ...newCustomer, contact_name: e.target.value })}
                        onKeyDown={handleKeyPress}
                        className="h-8"
                      />
                    </TableCell>
                    <TableCell>
                      <Input
                        placeholder="Email"
                        type="email"
                        value={newCustomer.email}
                        onChange={(e) => setNewCustomer({ ...newCustomer, email: e.target.value })}
                        onKeyDown={handleKeyPress}
                        className="h-8"
                      />
                    </TableCell>
                    <TableCell>
                      <Input
                        placeholder="Phone"
                        value={newCustomer.phone}
                        onChange={(e) => setNewCustomer({ ...newCustomer, phone: e.target.value })}
                        onKeyDown={handleKeyPress}
                        className="h-8"
                      />
                    </TableCell>
                    <TableCell>
                      <Select 
                        value={newCustomer.status} 
                        onValueChange={(value: "active" | "inactive" | "lead") => 
                          setNewCustomer({ ...newCustomer, status: value })
                        }
                      >
                        <SelectTrigger className="h-8">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="lead">Lead</SelectItem>
                          <SelectItem value="active">Active</SelectItem>
                          <SelectItem value="inactive">Inactive</SelectItem>
                        </SelectContent>
                      </Select>
                    </TableCell>
                    <TableCell>
                      <div className="flex gap-1">
                        <Button 
                          size="icon" 
                          variant="ghost" 
                          className="h-8 w-8" 
                          onClick={handleQuickAdd}
                          disabled={!newCustomer.company_name && !newCustomer.contact_name}
                        >
                          <Check className="h-4 w-4" />
                        </Button>
                        <Button 
                          size="icon" 
                          variant="ghost" 
                          className="h-8 w-8" 
                          onClick={() => {
                            setShowQuickAdd(false);
                            setNewCustomer({
                              company_name: "",
                              contact_name: "",
                              email: "",
                              phone: "",
                              status: "lead"
                            });
                          }}
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ) : (
                  <TableRow 
                    className="border-dashed border-muted-foreground/30 hover:bg-muted/50 cursor-pointer"
                    onClick={() => setShowQuickAdd(true)}
                  >
                    <TableCell colSpan={6} className="text-center text-muted-foreground py-3">
                      <div className="flex items-center justify-center gap-2">
                        <Plus className="h-4 w-4" />
                        Quick add
                      </div>
                    </TableCell>
                  </TableRow>
                )}

                 {/* Customer Rows */}
                {filteredCustomers.map((customer, index) => (
                  <TableRow 
                    key={customer.id} 
                    className="border-b hover:bg-muted/50"
                    style={{ backgroundColor: '#fbfbfb' }}
                  >
                    <TableCell className="w-12 text-left">
                      <Avatar className="h-8 w-8" style={{ backgroundColor: getAvatarColor(customer.company_name) }}>
                        <AvatarFallback 
                          className="text-xs font-medium"
                          style={{ backgroundColor: getAvatarColor(customer.company_name), color: 'hsl(var(--foreground))' }}
                        >
                          {customer.company_name.charAt(0).toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                    </TableCell>
                    
                    {/* Company Name - Clickable when not editing */}
                    <TableCell className="w-48 text-left">
                      {editingId === customer.id ? (
                        <Input
                          value={editData.company_name}
                          onChange={(e) => setEditData({ ...editData, company_name: e.target.value })}
                          className="h-8"
                        />
                      ) : (
                        <button 
                          onClick={() => handleNavigateToCustomer(customer.id)}
                          className="font-medium text-left hover:text-primary underline-offset-4 hover:underline"
                        >
                          {customer.company_name}
                        </button>
                      )}
                    </TableCell>

                    {/* Contact Name */}
                    <TableCell className="w-48 text-left">
                      {editingId === customer.id ? (
                        <Input
                          value={editData.contact_name}
                          onChange={(e) => setEditData({ ...editData, contact_name: e.target.value })}
                          className="h-8"
                        />
                      ) : (
                        <span className="text-muted-foreground">{customer.contact_name}</span>
                      )}
                    </TableCell>

                    {/* Email */}
                    <TableCell className="w-64 text-left">
                      {editingId === customer.id ? (
                        <Input
                          type="email"
                          value={editData.email}
                          onChange={(e) => setEditData({ ...editData, email: e.target.value })}
                          className="h-8"
                        />
                      ) : (
                        <span className="text-muted-foreground">{customer.email}</span>
                      )}
                    </TableCell>

                    {/* Phone */}
                    <TableCell className="w-40 text-left">
                      {editingId === customer.id ? (
                        <Input
                          value={editData.phone}
                          onChange={(e) => setEditData({ ...editData, phone: e.target.value })}
                          className="h-8"
                        />
                      ) : (
                        <span className="text-muted-foreground">{customer.phone || "—"}</span>
                      )}
                    </TableCell>


                    {/* Status - Always Editable */}
                    <TableCell className="w-32 text-left">
                      {editingId === customer.id ? (
                        <Select 
                          value={editData.status} 
                          onValueChange={(value: "active" | "inactive" | "lead") => 
                            setEditData({ ...editData, status: value })
                          }
                        >
                          <SelectTrigger className="h-8">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="lead">Lead</SelectItem>
                            <SelectItem value="active">Active</SelectItem>
                            <SelectItem value="inactive">Inactive</SelectItem>
                          </SelectContent>
                        </Select>
                      ) : (
                        <StatusBadge
                          status={customer.status}
                          options={["active", "inactive", "lead"]}
                          onChange={async (newStatus) => {
                            await handleStatusUpdate(customer.id, newStatus as 'active' | 'inactive' | 'lead');
                          }}
                          model="customer"
                          id={customer.id}
                        />
                      )}
                    </TableCell>

                    {/* Actions */}
                    <TableCell className="w-20 text-right">
                      <div className="flex items-center justify-end gap-1">
                        {editingId === customer.id ? (
                          <>
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              className="h-8 w-8" 
                              onClick={handleSaveEdit}
                            >
                              <Check className="h-4 w-4" />
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              className="h-8 w-8" 
                              onClick={handleCancelEdit}
                            >
                              <X className="h-4 w-4" />
                            </Button>
                          </>
                        ) : (
                          <>
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              className="h-8 w-8"
                              onClick={() => handleEditCustomer(customer)}
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="icon" className="h-8 w-8">
                                  <MoreHorizontal className="h-4 w-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end" className="w-48">
                                <DropdownMenuItem 
                                  onClick={() => handleNavigateToCustomer(customer.id)}
                                  className="cursor-pointer"
                                >
                                  <Eye className="h-4 w-4 mr-2" />
                                  View Details
                                </DropdownMenuItem>
                                <DropdownMenuItem 
                                  onClick={() => handleDuplicateCustomer(customer)}
                                  className="cursor-pointer"
                                >
                                  <Copy className="h-4 w-4 mr-2" />
                                  Duplicate
                                </DropdownMenuItem>
                                 <DropdownMenuItem 
                                   onClick={() => setDeleteCustomerId(customer.id)}
                                   className="cursor-pointer text-destructive focus:text-destructive"
                                 >
                                   <Trash2 className="h-4 w-4 mr-2" />
                                   Delete
                                 </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
              </Table>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* CSV Import Modal */}
      <CSVImportModal
        open={showImportModal}
        onOpenChange={setShowImportModal}
        onImportComplete={refetch}
      />

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={!!deleteCustomerId} onOpenChange={() => setDeleteCustomerId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Customer</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to permanently delete this customer? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setDeleteCustomerId(null)}>
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleDeleteCustomer}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
