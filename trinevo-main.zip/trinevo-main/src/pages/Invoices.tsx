import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { StatusBadge } from "@/components/StatusBadge";
import { Plus, Search, Filter, MoreHorizontal, Eye, Download, Send, FileText } from "lucide-react";
import { SearchIcon } from "@/components/LottieIcon";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { InvoiceForm } from "@/components/forms/InvoiceForm";
import { useInvoices } from "@/hooks/useInvoices";
import { useCustomers } from "@/hooks/useSupabase";
import { format } from "date-fns";

export function Invoices() {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [typeFilter, setTypeFilter] = useState("all");
  const [showInvoiceForm, setShowInvoiceForm] = useState(false);
  const navigate = useNavigate();
  const { invoices, loading, updateInvoice } = useInvoices();
  const { customers } = useCustomers();


  const getTypeColor = (type: string) => {
    const colors = {
      normal: "bg-slate-100 text-slate-800 border-slate-200",
      deposit: "bg-amber-100 text-amber-800 border-amber-200",
    };
    return colors[type as keyof typeof colors] || "bg-slate-100 text-slate-800 border-slate-200";
  };

  const filteredInvoices = invoices.filter(invoice => {
    const customer = customers.find(c => c.id === invoice.client_id);
    const matchesSearch = invoice.invoice_number.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         customer?.company_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         customer?.contact_name?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === "all" || invoice.status === statusFilter;
    const matchesType = typeFilter === "all" || invoice.type === typeFilter;
    return matchesSearch && matchesStatus && matchesType;
  });

  // Calculate statistics
  const totalInvoices = filteredInvoices.length;
  const paidInvoices = filteredInvoices.filter(inv => inv.status === 'paid').length;
  const totalValue = filteredInvoices.reduce((sum, inv) => sum + inv.total, 0);
  const paidValue = filteredInvoices.filter(inv => inv.status === 'paid').reduce((sum, inv) => sum + inv.total, 0);

  const isOverdue = (dueDate: string | null | undefined) => {
    if (!dueDate) return false;
    return new Date(dueDate) < new Date() && dueDate !== null;
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <h1 className="text-2xl font-semibold">Invoices</h1>
        </div>
        <div className="text-center py-8">Loading invoices...</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <h1 className="text-xl md:text-2xl lg:text-3xl">Invoices</h1>
        <Button variant="dark" onClick={() => navigate("/invoices/new")} className="gap-2">
          <Plus className="h-4 w-4" />
          New Invoice
        </Button>
      </div>

      {/* Search and Filters */}
      <Card className="border-none shadow-none">
        <CardContent className="shadow-none p-0">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1 group">
              <div className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4">
                <SearchIcon delay={150} onHover={true} />
              </div>
              <Input
                placeholder="Search invoices..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full h-8 rounded-xl px-3 pl-10 text-sm bg-gray-100 border border-gray-300 placeholder:text-gray-500 text-gray-900 focus-visible:ring-2 focus-visible:ring-gray-200 transition duration-200 ease-in-out outline-none disabled:opacity-70 disabled:cursor-not-allowed"
              />
            </div>
            
            <div className="flex gap-2">
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-[140px]">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="draft">Draft</SelectItem>
                  <SelectItem value="sent">Sent</SelectItem>
                  <SelectItem value="paid">Paid</SelectItem>
                  <SelectItem value="cancelled">Cancelled</SelectItem>
                </SelectContent>
              </Select>

              <Select value={typeFilter} onValueChange={setTypeFilter}>
                <SelectTrigger className="w-[140px]">
                  <SelectValue placeholder="Type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="normal">Normal</SelectItem>
                  <SelectItem value="deposit">Deposit</SelectItem>
                </SelectContent>
              </Select>

              <Select value="newest" onValueChange={() => {}}>
                <SelectTrigger className="w-[140px]">
                  <SelectValue placeholder="Sort" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="newest">Newest First</SelectItem>
                  <SelectItem value="oldest">Oldest First</SelectItem>
                  <SelectItem value="amount-high">Amount High-Low</SelectItem>
                  <SelectItem value="amount-low">Amount Low-High</SelectItem>
                  <SelectItem value="company">Company A-Z</SelectItem>
                  <SelectItem value="due-soon">Due Soon</SelectItem>
                </SelectContent>
              </Select>

              <Select value="all-time" onValueChange={() => {}}>
                <SelectTrigger className="w-[140px]">
                  <SelectValue placeholder="Period" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all-time">All Time</SelectItem>
                  <SelectItem value="this-week">This Week</SelectItem>
                  <SelectItem value="this-month">This Month</SelectItem>
                  <SelectItem value="this-quarter">This Quarter</SelectItem>
                  <SelectItem value="this-year">This Year</SelectItem>
                  <SelectItem value="last-week">Last Week</SelectItem>
                  <SelectItem value="last-month">Last Month</SelectItem>
                  <SelectItem value="last-quarter">Last Quarter</SelectItem>
                  <SelectItem value="last-year">Last Year</SelectItem>
                  <SelectItem value="custom">Custom Period</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Invoices Table */}
      <Card className="border-border/40">
        <CardContent className="p-0">
          {filteredInvoices.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              {invoices.length === 0 ? (
                <div>
                  <FileText className="h-12 w-12 mx-auto mb-4 text-muted-foreground/50" />
                  <h3 className="text-lg font-medium mb-2">No invoices yet</h3>
                  <p className="text-sm mb-4">Create your first invoice to get started</p>
                  <Button onClick={() => navigate("/invoices/new")}>
                    <Plus className="h-4 w-4 mr-2" />
                    Create Invoice
                  </Button>
                </div>
              ) : (
                <div>
                  <p className="text-lg font-medium mb-2">No invoices found</p>
                  <p className="text-sm">Try adjusting your search or filters</p>
                </div>
              )}
            </div>
          ) : (
            <div className="overflow-x-auto">
              <div className="min-w-[700px]">
                {/* Custom header that matches input styling */}
                <div className="flex h-8 w-full rounded-xl px-4 py-2 text-sm bg-gray-100 border border-gray-300 text-gray-500 mb-0 items-center">
                  <div className="w-32 font-medium text-left">Date</div>
                  <div className="w-40 font-medium text-left">Number</div>
                  <div className="w-48 font-medium text-left">Customer</div>
                  <div className="w-32 font-medium text-left">Total</div>
                  <div className="w-32 font-medium text-left">Status</div>
                  <div className="w-24 font-medium text-right">Actions</div>
                </div>
                <Table>
                  <TableBody>
                   {filteredInvoices.map((invoice) => {
                     const customer = customers.find(c => c.id === invoice.client_id);
                     
                     return (
                       <TableRow 
                         key={invoice.id} 
                         className="border-border/40 hover:bg-muted/50 cursor-pointer"
                         style={{ backgroundColor: '#fbfbfb' }}
                         onClick={() => navigate(`/invoices/${invoice.id}`)}
                       >
                         <TableCell className="w-32 text-left">
                           {invoice.issue_date ? format(new Date(invoice.issue_date), 'MMM dd, yyyy') : '-'}
                         </TableCell>
                         <TableCell className="w-40 font-medium text-left">
                           {invoice.invoice_number}
                         </TableCell>
                         <TableCell className="w-48 text-left">
                           <span className="truncate">{customer?.company_name || 'Unknown'}</span>
                         </TableCell>
                         <TableCell className="w-32 font-medium text-left">
                           {invoice.currency} {invoice.total.toLocaleString()}
                         </TableCell>
                         <TableCell className="w-32 text-left" onClick={(e) => e.stopPropagation()}>
                           <StatusBadge
                             status={invoice.status}
                             options={["draft", "sent", "paid", "cancelled"]}
                             onChange={async (newStatus) => {
                               await updateInvoice(invoice.id, { status: newStatus });
                             }}
                             model="invoice"
                             id={invoice.id}
                           />
                         </TableCell>
                         <TableCell className="w-24 text-right">
                           <DropdownMenu>
                             <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
                               <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                                 <MoreHorizontal className="h-4 w-4" />
                               </Button>
                             </DropdownMenuTrigger>
                             <DropdownMenuContent align="end">
                               <DropdownMenuItem onClick={(e) => {
                                 e.stopPropagation();
                                 navigate(`/invoices/${invoice.id}`);
                               }}>
                                 <Eye className="h-4 w-4 mr-2" />
                                 View Details
                               </DropdownMenuItem>
                               <DropdownMenuItem onClick={(e) => e.stopPropagation()}>
                                 <Download className="h-4 w-4 mr-2" />
                                 Download PDF
                               </DropdownMenuItem>
                               <DropdownMenuItem onClick={(e) => e.stopPropagation()}>
                                 <Send className="h-4 w-4 mr-2" />
                                 Send Invoice
                               </DropdownMenuItem>
                             </DropdownMenuContent>
                           </DropdownMenu>
                         </TableCell>
                       </TableRow>
                     );
                   })}
                  </TableBody>
                </Table>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      <InvoiceForm
        open={showInvoiceForm}
        onOpenChange={setShowInvoiceForm}
      />
    </div>
  );
}
