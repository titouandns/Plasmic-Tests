import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { OnboardingStep } from "@/components/onboarding/OnboardingStep";
import { useOnboarding } from "@/hooks/useOnboarding";
import { useAuth } from "@/components/AuthProvider";
import { ArrowRight, ArrowLeft, Sparkles, Plus, X } from "lucide-react";

export default function Onboarding() {
  const navigate = useNavigate();
  const { user, loading: authLoading } = useAuth();
  const [emailInput, setEmailInput] = useState("");
  const {
    currentStep,
    onboardingData,
    loading,
    updateOnboardingData,
    nextStep,
    prevStep,
    completeOnboarding,
  } = useOnboarding();

  useEffect(() => {
    if (!authLoading && !user) {
      navigate("/auth");
    }
  }, [user, authLoading, navigate]);

  const handleNext = () => {
    if (currentStep === 1 && (!onboardingData.firstName || !onboardingData.lastName)) {
      return;
    }
    if (currentStep === 2 && !onboardingData.teamName) {
      return;
    }
    nextStep();
  };

  const addEmail = () => {
    if (emailInput.trim() && !onboardingData.inviteEmails.includes(emailInput.trim())) {
      updateOnboardingData({ 
        inviteEmails: [...onboardingData.inviteEmails, emailInput.trim()] 
      });
      setEmailInput("");
    }
  };

  const removeEmail = (emailToRemove: string) => {
    updateOnboardingData({
      inviteEmails: onboardingData.inviteEmails.filter(email => email !== emailToRemove)
    });
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      addEmail();
    }
  };

  const handleComplete = async () => {
    const success = await completeOnboarding();
    if (success) {
      navigate("/");
    }
  };

  if (authLoading) {
    return <div className="min-h-screen bg-background flex items-center justify-center">
      <div className="text-muted-foreground">Loading...</div>
    </div>;
  }

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <OnboardingStep
          step={1}
          title="Welcome to Trinevo"
          description="Let's get you set up with your workspace"
        >
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="firstName">First Name</Label>
                <Input
                  id="firstName"
                  placeholder="Enter your first name"
                  value={onboardingData.firstName}
                  onChange={(e) => updateOnboardingData({ firstName: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="lastName">Last Name</Label>
                <Input
                  id="lastName"
                  placeholder="Enter your last name"
                  value={onboardingData.lastName}
                  onChange={(e) => updateOnboardingData({ lastName: e.target.value })}
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="teamName">Team Name</Label>
              <Input
                id="teamName"
                placeholder="Enter your team name"
                value={onboardingData.teamName}
                onChange={(e) => updateOnboardingData({ teamName: e.target.value })}
              />
            </div>
            <Button
              onClick={handleComplete}
              disabled={!onboardingData.firstName || !onboardingData.lastName || !onboardingData.teamName || loading}
              variant="dark"
              className="w-full mt-6"
            >
              {loading ? "Setting up..." : "Get Started"}
              <Sparkles className="w-4 h-4 ml-2" />
            </Button>
          </div>
        </OnboardingStep>
      </div>
    </div>
  );
}