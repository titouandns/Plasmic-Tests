import { useState, useEffect } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  ArrowLeft, 
  Download,
  Edit,
  FileText,
  Send
} from "lucide-react";
import { useCustomers, useProfile, useQuotes } from "@/hooks/useSupabase";
import { useInvoices, useInvoiceLines } from "@/hooks/useInvoices";
import { useToast } from "@/hooks/use-toast";
import { exportInvoiceToPDF } from "@/lib/pdfExport";
import { StatusBadge } from "@/components/StatusBadge";

export default function InvoicePreview() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { toast } = useToast();
  const { invoices, updateInvoice } = useInvoices();
  const { invoiceLines } = useInvoiceLines(id);
  const { customers } = useCustomers();
  const { profile } = useProfile();
  const { quotes } = useQuotes();
  
  const [invoice, setInvoice] = useState<any>(null);
  const [sourceQuote, setSourceQuote] = useState<any>(null);

  useEffect(() => {
    if (id) {
      const foundInvoice = invoices.find(i => i.id === id);
      if (foundInvoice) {
        setInvoice(foundInvoice);
        
        // Find source quote if exists
        if (foundInvoice.quote_id) {
          const quote = quotes.find(q => q.id === foundInvoice.quote_id);
          setSourceQuote(quote);
        }
      }
    }
  }, [id, invoices, quotes]);

  const selectedCustomer = customers.find(c => c.id === invoice?.client_id);

  const handleStatusUpdate = async (newStatus: string) => {
    if (!invoice) return;
    await updateInvoice(invoice.id, { status: newStatus as any });
  };

  const handleExportPDF = async () => {
    if (!invoice || !profile) {
      toast({
        title: "Error",
        description: "Invoice or profile data not available",
        variant: "destructive",
      });
      return;
    }

    try {
      const defaultOptionsConfig = {
        showDeliveryAddress: false,
        showCompanyNumber: false,
        showTaxNumber: false,
        showAcceptanceConditions: false,
        showSignatureField: false,
        showFreeField: false,
        documentTitle: 'Invoice',
        globalDiscount: 0,
        acceptanceConditionsText: '',
        freeFieldContent: ''
      };

      await exportInvoiceToPDF(
        invoice,
        invoiceLines || [],
        selectedCustomer,
        profile,
        defaultOptionsConfig,
        {
          filename: `Invoice_${invoice.invoice_number}.pdf`
        }
      );
      
      toast({
        title: "Success",
        description: "PDF exported successfully!",
      });
    } catch (error) {
      console.error("Error exporting PDF:", error);
      toast({
        title: "Error",
        description: "Failed to export PDF",
        variant: "destructive",
      });
    }
  };

  if (!invoice) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-background border-b px-6 py-4 flex items-center justify-between sticky top-0 z-10">
        <div className="flex items-center space-x-4">
          <Button variant="ghost" size="icon" onClick={() => navigate("/invoices")}>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div>
            <h1 className="text-xl font-semibold">
              Invoice {invoice.invoice_number}
            </h1>
            <p className="text-sm text-muted-foreground">
              {selectedCustomer?.company_name || "Unknown Customer"}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <Button variant="outline" onClick={handleExportPDF}>
            <Download className="h-4 w-4 mr-2" />
            Download PDF
          </Button>
          <Button variant="outline">
            <Send className="h-4 w-4 mr-2" />
            Send Invoice
          </Button>
          <Link to={`/invoices/${invoice.id}/edit`}>
            <Button variant="outline">
              <Edit className="h-4 w-4 mr-2" />
              Edit Invoice
            </Button>
          </Link>
        </div>
      </div>

      <div className="flex">
        {/* Main Content - Invoice Preview */}
        <div className="flex-1 py-12 px-8 bg-muted/20">
          <div className="max-w-4xl mx-auto">
            {/* Invoice Document Preview */}
            <div className="bg-card shadow-sm border border-border/40 rounded-lg overflow-hidden" style={{ minHeight: '800px' }}>
              <div className="p-8 md:p-12 space-y-8">
                {/* Header Section */}
                <div className="grid grid-cols-2 gap-16 pb-8 border-b border-border/50">
                  {/* Company Info */}
                  <div className="space-y-4">
                    <div className="flex items-start gap-3">
                      {profile?.company_logo && (
                        <img 
                          src={profile.company_logo.startsWith('http') 
                            ? profile.company_logo 
                            : `https://dvoudscaqazfdyannodt.supabase.co/storage/v1/object/public/company-logos/${profile.company_logo}`
                          }
                          alt="Company Logo" 
                          className="h-10 w-auto object-contain"
                          onError={(e) => {
                            e.currentTarget.style.display = 'none';
                          }}
                        />
                      )}
                      <div className="space-y-1">
                        <h1 className="text-xl font-semibold" style={profile?.accent_color ? { color: profile.accent_color } : {}}>
                          {profile?.company_name || "Your Company Name"}
                        </h1>
                        <p className="text-xs text-muted-foreground font-medium uppercase tracking-wide">
                          Individual Business
                        </p>
                      </div>
                    </div>
                    
                    <div className="space-y-0.5 text-sm text-muted-foreground">
                      {profile?.street_address && (
                        <div>{profile.street_address}</div>
                      )}
                      {profile?.address_complement && (
                        <div>{profile.address_complement}</div>
                      )}
                      {(profile?.zip_code || profile?.city) && (
                        <div>{profile?.zip_code} {profile?.city}</div>
                      )}
                      {profile?.country && (
                        <div>{profile.country}</div>
                      )}
                    </div>
                  </div>

                  {/* Invoice Info */}
                  <div className="space-y-6 text-right">
                    <div className="space-y-2">
                      <h2 className="text-2xl font-bold tracking-tight" style={profile?.accent_color ? { color: profile.accent_color } : {}}>
                        INVOICE
                      </h2>
                      <p className="text-sm font-mono text-muted-foreground">
                        #{invoice.invoice_number}
                      </p>
                    </div>
                    
                    <div className="space-y-1 text-xs">
                      <div className="flex justify-end items-center gap-3">
                        <span className="text-muted-foreground font-medium">Issue Date</span>
                        <span className="font-mono text-foreground">
                          {invoice.issue_date ? new Date(invoice.issue_date).toLocaleDateString() : "Not set"}
                        </span>
                      </div>
                      <div className="flex justify-end items-center gap-3">
                        <span className="text-muted-foreground font-medium">Due Date</span>
                        <span className="font-mono text-foreground">
                          {invoice.due_date ? new Date(invoice.due_date).toLocaleDateString() : "Not set"}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Customer Section */}
                <div className="space-y-6">
                  <div>
                    <h3 className="text-sm font-medium mb-4 text-muted-foreground uppercase tracking-wide" style={profile?.accent_color ? { color: profile.accent_color } : {}}>
                      Bill To
                    </h3>
                    {selectedCustomer && (
                      <div className="bg-muted/20 border border-border/30 p-4 rounded-md max-w-sm">
                        <div className="font-semibold text-foreground text-base">
                          {selectedCustomer.company_name}
                        </div>
                        {selectedCustomer.contact_name && (
                          <div className="text-sm text-muted-foreground mt-1">
                            {selectedCustomer.contact_name}
                          </div>
                        )}
                        {selectedCustomer.billing_address && (
                          <div className="text-sm text-muted-foreground mt-3 whitespace-pre-line leading-relaxed">
                            {selectedCustomer.billing_address}
                          </div>
                        )}
                        {selectedCustomer.email && (
                          <div className="text-sm text-muted-foreground mt-1">
                            {selectedCustomer.email}
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </div>

                {/* Line Items Section */}
                <div className="space-y-4">
                  <div className="overflow-hidden border border-border/30 rounded-lg shadow-sm">
                    <table className="w-full border-collapse bg-card">
                      <thead>
                        <tr className="bg-muted/50 border-b border-border">
                          <th className="text-left px-6 py-4 text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                            Description
                          </th>
                          <th className="text-center px-6 py-4 text-xs font-semibold text-muted-foreground uppercase tracking-wider w-24">
                            Qty
                          </th>
                          <th className="text-center px-6 py-4 text-xs font-semibold text-muted-foreground uppercase tracking-wider w-32">
                            Unit Price
                          </th>
                          <th className="text-center px-6 py-4 text-xs font-semibold text-muted-foreground uppercase tracking-wider w-32">
                            Total
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        {(invoiceLines || []).map((line: any, index: number) => (
                          <tr key={line.id} className="border-b border-border/20 last:border-b-0 hover:bg-muted/20 transition-colors">
                            <td className="px-6 py-4">
                              <div className="font-semibold text-sm text-foreground">{line.title}</div>
                              {line.description && (
                                <div className="text-xs text-muted-foreground mt-1 leading-relaxed">
                                  {line.description}
                                </div>
                              )}
                            </td>
                            <td className="px-6 py-4 text-center text-sm font-mono text-foreground">
                              {line.quantity}
                            </td>
                            <td className="px-6 py-4 text-center text-sm font-mono text-foreground">
                              €{parseFloat(line.unit_price || 0).toFixed(2)}
                            </td>
                            <td className="px-6 py-4 text-center text-sm font-mono font-semibold text-foreground">
                              €{parseFloat(line.total || 0).toFixed(2)}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>

                  {/* Totals Section */}
                  <div className="flex justify-end">
                    <div className="w-80 space-y-2 text-sm">
                      <div className="flex justify-between py-2 border-b border-border/30">
                        <span className="font-medium">Subtotal</span>
                        <span className="font-mono">€{invoice.subtotal.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between py-2">
                        <span className="text-lg font-semibold">Total</span>
                        <span className="text-lg font-bold font-mono" style={profile?.accent_color ? { color: profile.accent_color } : {}}>
                          €{invoice.total.toFixed(2)}
                        </span>
                      </div>
                    </div>
                  </div>

                  {invoice.notes && (
                    <div className="mt-8 pt-6 border-t border-border/30">
                      <h4 className="text-sm font-medium mb-2 text-muted-foreground uppercase tracking-wide">
                        Notes
                      </h4>
                      <p className="text-sm text-muted-foreground leading-relaxed">
                        {invoice.notes}
                      </p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Sidebar */}
        <div className="w-80 bg-background border-l p-6 space-y-6">
          {/* Status Badge */}
          <Card>
            <CardHeader>
              <CardTitle>Status</CardTitle>
            </CardHeader>
            <CardContent>
              <StatusBadge
                status={invoice.status}
                options={["draft", "sent", "paid", "overdue", "cancelled"]}
                onChange={handleStatusUpdate}
                model="invoice"
                id={invoice.id}
              />
            </CardContent>
          </Card>

          {/* Customer Info */}
          <Card>
            <CardHeader>
              <CardTitle>Customer</CardTitle>
            </CardHeader>
            <CardContent>
              {selectedCustomer ? (
                <div className="space-y-2">
                  <p className="font-medium">{selectedCustomer.company_name}</p>
                  {selectedCustomer.contact_name && (
                    <p className="text-sm text-muted-foreground">{selectedCustomer.contact_name}</p>
                  )}
                  {selectedCustomer.email && (
                    <p className="text-sm text-muted-foreground">{selectedCustomer.email}</p>
                  )}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground">No customer selected</p>
              )}
            </CardContent>
          </Card>

          {/* Source Quote */}
          {sourceQuote && (
            <Card>
              <CardHeader>
                <CardTitle>Source Quote</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">{sourceQuote.quote_number}</span>
                    <Badge variant="outline">{sourceQuote.status}</Badge>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Created: {new Date(sourceQuote.created_at).toLocaleDateString()}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    Total: €{sourceQuote.total.toLocaleString()}
                  </p>
                  <Link to={`/quotes/${sourceQuote.id}`} className="inline-block">
                    <Button variant="outline" size="sm" className="w-full mt-2">
                      <FileText className="h-4 w-4 mr-2" />
                      View Quote
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}