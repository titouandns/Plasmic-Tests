import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  ArrowLeft, 
  Plus, 
  Trash2, 
  Settings as SettingsIcon,
  Download
} from "lucide-react";
import { useCustomers, useProfile } from "@/hooks/useSupabase";
import { useInvoices, useInvoiceLines } from "@/hooks/useInvoices";
import { useToast } from "@/hooks/use-toast";
import { exportInvoiceToPDF } from "@/lib/pdfExport";
import { CustomerSearchSelect } from "@/components/CustomerSearchSelect";
import { CustomerForm } from "@/components/forms/CustomerForm";

export default function InvoiceNew() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const { addInvoice } = useInvoices();
  const { customers } = useCustomers();
  const { profile } = useProfile();
  
  const [hasChanges, setHasChanges] = useState(false);
  const [showCustomerForm, setShowCustomerForm] = useState(false);
  
  const [invoice, setInvoice] = useState({
    invoice_number: `INV-${Date.now()}`,
    client_id: "",
    currency: "EUR",
    subtotal: 0,
    total: 0,
    status: "draft" as const,
    type: "normal" as const,
    issue_date: new Date().toISOString().split('T')[0],
    due_date: "",
    notes: ""
  });
  
  const [editingLines, setEditingLines] = useState<any[]>([]);

  const handleInvoiceChange = (field: string, value: any) => {
    setInvoice(prev => ({ ...prev, [field]: value }));
    setHasChanges(true);
  };

  const handleLineChange = (index: number, field: string, value: any) => {
    const updatedLines = [...editingLines];
    updatedLines[index] = { ...updatedLines[index], [field]: value };
    
    // Recalculate line total
    if (field === 'quantity' || field === 'unit_price') {
      const quantity = parseFloat(updatedLines[index].quantity) || 0;
      const unitPrice = parseFloat(updatedLines[index].unit_price) || 0;
      updatedLines[index].total = quantity * unitPrice;
    }
    
    setEditingLines(updatedLines);
    setHasChanges(true);
  };

  const addNewLine = () => {
    const newLine = {
      id: `temp-${Date.now()}`,
      title: "",
      description: "",
      quantity: 1,
      unit_price: 0,
      total: 0,
      display_order: editingLines.length
    };
    setEditingLines([...editingLines, newLine]);
    setHasChanges(true);
  };

  const removeLine = (index: number) => {
    const updatedLines = editingLines.filter((_, i) => i !== index);
    setEditingLines(updatedLines);
    setHasChanges(true);
  };

  const calculateTotals = () => {
    const subtotal = editingLines.reduce((sum, line) => sum + (parseFloat(line.total) || 0), 0);
    const tva = subtotal * 0.2; // 20% TVA
    const total = subtotal + tva;
    
    return { subtotal, tva, total };
  };

  const { subtotal, tva, total } = calculateTotals();
  const selectedCustomer = customers.find(c => c.id === invoice?.client_id);

  const handleSave = async () => {
    if (!invoice.client_id) {
      toast({
        title: "Error",
        description: "Please select a customer",
        variant: "destructive",
      });
      return;
    }

    if (editingLines.length === 0) {
      toast({
        title: "Error", 
        description: "Please add at least one invoice line",
        variant: "destructive",
      });
      return;
    }

    try {
      const savedInvoice = await addInvoice({
        ...invoice,
        subtotal,
        total
      });

      // Note: Invoice lines would need to be saved separately via invoice lines API
      // This is similar to how quotes work in the QuoteEdit component

      toast({
        title: "Success",
        description: "Invoice created successfully",
      });

      navigate(`/invoices/${savedInvoice.id}`);
      setHasChanges(false);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to create invoice",
        variant: "destructive",
      });
    }
  };

  const handleExportPDF = async () => {
    if (!invoice || !profile) {
      toast({
        title: "Error",
        description: "Invoice or profile data not available",
        variant: "destructive",
      });
      return;
    }

    if (!editingLines || editingLines.length === 0) {
      toast({
        title: "Error",
        description: "No invoice lines available for export",
        variant: "destructive",
      });
      return;
    }

    try {
      const defaultOptionsConfig = {
        showDeliveryAddress: false,
        showCompanyNumber: false,
        showTaxNumber: false,
        showAcceptanceConditions: false,
        showSignatureField: false,
        showFreeField: false,
        documentTitle: 'Invoice',
        globalDiscount: 0,
        acceptanceConditionsText: '',
        freeFieldContent: ''
      };

      await exportInvoiceToPDF(
        { ...invoice, subtotal, total },
        editingLines,
        selectedCustomer,
        profile,
        defaultOptionsConfig,
        {
          filename: `Invoice_${invoice.invoice_number}.pdf`
        }
      );
      
      toast({
        title: "Success",
        description: "PDF exported successfully!",
      });
    } catch (error) {
      console.error("Error exporting PDF:", error);
      toast({
        title: "Error",
        description: "Failed to export PDF",
        variant: "destructive",
      });
    }
  };

  // Initialize with one empty line
  useEffect(() => {
    if (editingLines.length === 0) {
      addNewLine();
    }
  }, []);

  return (
    <>
      <div className="min-h-screen bg-background">
        {/* Header */}
        <div className="bg-background border-b px-6 py-4 flex items-center justify-between sticky top-0 z-10">
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="icon" onClick={() => navigate("/invoices")}>
              <ArrowLeft className="h-4 w-4" />
            </Button>
            <div>
              <h1 className="text-xl font-semibold">New Invoice</h1>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Button variant="outline" onClick={handleExportPDF} disabled={!selectedCustomer || editingLines.length === 0}>
              <Download className="h-4 w-4 mr-2" />
              Download PDF
            </Button>
            <Button variant="outline" onClick={handleSave} disabled={!hasChanges}>
              Create Invoice
            </Button>
          </div>
        </div>

        <div className="flex">
          {/* Main Content - Invoice Preview */}
          <div className="flex-1 py-12 px-8 bg-muted/20 pr-4">
            <div className="max-w-4xl mx-auto">
              {/* Invoice Document Preview */}
              <div className="bg-card shadow-sm border border-border/40 rounded-lg overflow-hidden" style={{ minHeight: '800px' }}>
                <div className="p-8 md:p-12 space-y-8">
                  {/* Header Section */}
                  <div className="grid grid-cols-2 gap-16 pb-8 border-b border-border/50">
                    {/* Company Info */}
                    <div className="space-y-4">
                      <div className="flex items-start gap-3">
                        {profile?.company_logo && (
                          <img 
                            src={profile.company_logo.startsWith('http') 
                              ? profile.company_logo 
                              : `https://dvoudscaqazfdyannodt.supabase.co/storage/v1/object/public/company-logos/${profile.company_logo}`
                            }
                            alt="Company Logo" 
                            className="h-10 w-auto object-contain"
                            onError={(e) => {
                              e.currentTarget.style.display = 'none';
                            }}
                          />
                        )}
                        <div className="space-y-1">
                          <h1 className="text-xl font-semibold" style={profile?.accent_color ? { color: profile.accent_color } : {}}>
                            {profile?.company_name || "Your Company Name"}
                          </h1>
                          <p className="text-xs text-muted-foreground font-medium uppercase tracking-wide">
                            Individual Business
                          </p>
                        </div>
                      </div>
                      
                      <div className="space-y-0.5 text-sm text-muted-foreground">
                        {profile?.street_address && (
                          <div>{profile.street_address}</div>
                        )}
                        {profile?.address_complement && (
                          <div>{profile.address_complement}</div>
                        )}
                        {(profile?.zip_code || profile?.city) && (
                          <div>{profile?.zip_code} {profile?.city}</div>
                        )}
                        {profile?.country && (
                          <div>{profile.country}</div>
                        )}
                      </div>
                    </div>

                    {/* Invoice Info */}
                    <div className="space-y-6 text-right">
                      <div className="space-y-2">
                        <h2 className="text-2xl font-bold tracking-tight" style={profile?.accent_color ? { color: profile.accent_color } : {}}>
                          INVOICE
                        </h2>
                        <p className="text-sm font-mono text-muted-foreground">
                          #{invoice.invoice_number}
                        </p>
                      </div>
                      
                      <div className="space-y-1 text-xs">
                        <div className="flex justify-end items-center gap-3">
                          <span className="text-muted-foreground font-medium">Issue Date</span>
                          <input
                            type="date"
                            value={invoice.issue_date}
                            onChange={(e) => handleInvoiceChange("issue_date", e.target.value)}
                            className="font-mono border-none outline-none bg-transparent text-right text-foreground"
                          />
                        </div>
                        <div className="flex justify-end items-center gap-3">
                          <span className="text-muted-foreground font-medium">Due Date</span>
                          <input
                            type="date"
                            value={invoice.due_date}
                            onChange={(e) => handleInvoiceChange("due_date", e.target.value)}
                            className="font-mono border-none outline-none bg-transparent text-right text-foreground"
                          />
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Customer Section */}
                  <div className="space-y-6">
                    <div>
                      <h3 className="text-sm font-medium mb-4 text-muted-foreground uppercase tracking-wide" style={profile?.accent_color ? { color: profile.accent_color } : {}}>
                        Bill To
                      </h3>
                      <div className="space-y-4">
                        <CustomerSearchSelect
                          customers={customers}
                          selectedCustomerId={invoice.client_id}
                          onSelect={(customerId) => handleInvoiceChange("client_id", customerId)}
                          onCreateNew={() => setShowCustomerForm(true)}
                          placeholder="Search and select a customer..."
                          className="max-w-sm"
                        />
                        
                        {selectedCustomer && (
                          <div className="bg-muted/20 border border-border/30 p-4 rounded-md max-w-sm">
                            <div className="font-medium text-foreground">{selectedCustomer.company_name}</div>
                            {selectedCustomer.contact_name && (
                              <div className="text-xs text-muted-foreground mt-1">
                                {selectedCustomer.contact_name}
                              </div>
                            )}
                            {selectedCustomer.billing_address && (
                              <div className="text-xs text-muted-foreground mt-2 whitespace-pre-line leading-relaxed">
                                {selectedCustomer.billing_address}
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Line Items Section */}
                  <div className="space-y-4">
                    <div className="overflow-hidden border border-border/30 rounded-md">
                      <table className="w-full border-collapse">
                        <thead>
                          <tr className="bg-muted border-b border-border">
                            <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground uppercase tracking-wider">
                              Description
                            </th>
                            <th className="text-center px-4 py-3 text-xs font-medium text-muted-foreground uppercase tracking-wider w-20">
                              Qty
                            </th>
                            <th className="text-center px-4 py-3 text-xs font-medium text-muted-foreground uppercase tracking-wider w-28">
                              Unit Price
                            </th>
                            <th className="text-center px-4 py-3 text-xs font-medium text-muted-foreground uppercase tracking-wider w-24">
                              Total
                            </th>
                            <th className="w-12"></th>
                          </tr>
                        </thead>
                        <tbody>
                          {editingLines.map((line, index) => (
                            <tr key={line.id} className="border-b border-border/20 last:border-b-0">
                              <td className="px-4 py-3">
                                <div className="space-y-2">
                                  <Input
                                    placeholder="Service or product title"
                                    value={line.title}
                                    onChange={(e) => handleLineChange(index, "title", e.target.value)}
                                    className="border-none bg-transparent p-0 font-medium text-sm"
                                  />
                                  <Textarea
                                    placeholder="Description (optional)"
                                    value={line.description}
                                    onChange={(e) => handleLineChange(index, "description", e.target.value)}
                                    className="border-none bg-transparent p-0 text-xs text-muted-foreground resize-none min-h-[20px]"
                                    rows={1}
                                  />
                                </div>
                              </td>
                              <td className="px-4 py-3 text-center">
                                <Input
                                  type="number"
                                  value={line.quantity}
                                  onChange={(e) => handleLineChange(index, "quantity", e.target.value)}
                                  className="w-16 mx-auto text-center border-none bg-transparent p-0 text-sm font-mono"
                                  min="0"
                                  step="0.01"
                                />
                              </td>
                              <td className="px-4 py-3 text-center">
                                <div className="flex items-center justify-center">
                                  <span className="text-xs text-muted-foreground mr-1">€</span>
                                  <Input
                                    type="number"
                                    value={line.unit_price}
                                    onChange={(e) => handleLineChange(index, "unit_price", e.target.value)}
                                    className="w-20 text-center border-none bg-transparent p-0 text-sm font-mono"
                                    min="0"
                                    step="0.01"
                                  />
                                </div>
                              </td>
                              <td className="px-4 py-3 text-center text-sm font-mono font-medium">
                                €{parseFloat(line.total || 0).toFixed(2)}
                              </td>
                              <td className="px-4 py-3">
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => removeLine(index)}
                                  className="h-6 w-6 p-0 text-muted-foreground hover:text-destructive"
                                >
                                  <Trash2 className="h-3 w-3" />
                                </Button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>

                    <Button
                      variant="ghost"
                      onClick={addNewLine}
                      className="w-full border border-dashed border-border/50 hover:border-primary/50 text-muted-foreground hover:text-primary"
                    >
                      <Plus className="h-4 w-4 mr-2" />
                      Add Line Item
                    </Button>

                    {/* Totals Section */}
                    <div className="flex justify-end">
                      <div className="w-80 space-y-2 text-sm">
                        <div className="flex justify-between py-2 border-b border-border/30">
                          <span className="font-medium">Subtotal</span>
                          <span className="font-mono">€{subtotal.toFixed(2)}</span>
                        </div>
                        <div className="flex justify-between py-2 border-b border-border/30">
                          <span className="font-medium">TVA (20%)</span>
                          <span className="font-mono">€{tva.toFixed(2)}</span>
                        </div>
                        <div className="flex justify-between py-2">
                          <span className="text-lg font-semibold">Total</span>
                          <span className="text-lg font-bold font-mono" style={profile?.accent_color ? { color: profile.accent_color } : {}}>
                            €{total.toFixed(2)}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Notes Section */}
                    <div className="mt-8 pt-6 border-t border-border/30">
                      <Label htmlFor="notes" className="text-sm font-medium mb-2 text-muted-foreground uppercase tracking-wide">
                        Notes
                      </Label>
                      <Textarea
                        id="notes"
                        placeholder="Add any additional notes or terms..."
                        value={invoice.notes}
                        onChange={(e) => handleInvoiceChange("notes", e.target.value)}
                        className="mt-2 min-h-[60px] border-none bg-transparent resize-none text-sm"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <CustomerForm
        open={showCustomerForm}
        onOpenChange={setShowCustomerForm}
      />
    </>
  );
}