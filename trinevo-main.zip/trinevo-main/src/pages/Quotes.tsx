import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { StatusBadge } from "@/components/StatusBadge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { 
  Plus, 
  Search, 
  FileText, 
  Download,
  Send,
  Eye,
  MoreHorizontal,
  Calendar,
  Euro,
  Filter,
  Edit,
  Trash2,
  Copy
} from "lucide-react";
import { SearchIcon } from "@/components/LottieIcon";
import { useQuotes, useProfile } from "@/hooks/useSupabase";
import { Link, useNavigate } from "react-router-dom";
import { exportQuoteToPDF, createPrintableQuoteHTML } from "@/lib/pdfExport";
import { toast } from "sonner";

export default function Quotes() {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const { quotes, loading, updateQuote } = useQuotes();
  const { profile } = useProfile();
  const navigate = useNavigate();


  const filteredQuotes = quotes.filter(quote => {
    const matchesSearch = 
      quote.customer?.company_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      quote.quote_number?.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = statusFilter === "all" || quote.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });

  const totalValue = filteredQuotes.reduce((sum, quote) => sum + (quote.total || 0), 0);
  const acceptedValue = filteredQuotes
    .filter(quote => quote.status === "Accepted")
    .reduce((sum, quote) => sum + (quote.total || 0), 0);

  const handleStatusUpdate = async (quoteId: string, newStatus: string) => {
    await updateQuote(quoteId, { status: newStatus as any });
  };

  const handleExportPDF = async (quote: any) => {
    if (!profile) {
      toast.error("Profile data not available");
      return;
    }

    try {
      // Basic options config (you might want to store this in user preferences)
      const defaultOptionsConfig = {
        showDeliveryAddress: false,
        showCompanyNumber: false,
        showTaxNumber: false,
        showAcceptanceConditions: true,
        showSignatureField: false,
        showFreeField: false,
        documentTitle: 'Quotation',
        globalDiscount: 0,
        acceptanceConditionsText: 'This quote is valid for 30 days from the date of issue. Payment terms: 30 days net.',
        freeFieldContent: ''
      };

      await exportQuoteToPDF(
        quote,
        quote.quote_lines || [],
        quote.customer,
        profile,
        defaultOptionsConfig,
        {
          filename: `Quote_${quote.quote_number}.pdf`
        }
      );
      
      toast.success("PDF exported successfully!");
    } catch (error) {
      console.error("Error exporting PDF:", error);
      toast.error("Failed to export PDF");
    }
  };

  if (loading) {
    return <div className="p-6">Loading quotes...</div>;
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl md:text-2xl lg:text-3xl">Quotes</h1>
        </div>
        <Link to="/quotes/new">
          <Button variant="dark">
            <Plus className="h-4 w-4 mr-2" />
            New Quote
          </Button>
        </Link>
      </div>

      {/* Search and Filters */}
      <Card className="border-none shadow-none">
        <CardContent className="shadow-none p-0">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1 group">
              <div className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4">
                <SearchIcon delay={150} onHover={true} />
              </div>
              <Input
                placeholder="Search quotes..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full h-8 rounded-xl px-3 pl-10 text-sm bg-gray-100 border border-gray-300 placeholder:text-gray-500 text-gray-900 focus-visible:ring-2 focus-visible:ring-gray-200 transition duration-200 ease-in-out outline-none disabled:opacity-70 disabled:cursor-not-allowed"
              />
            </div>
            
            <div className="flex gap-2">
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-[140px]">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="Saved">Saved</SelectItem>
                  <SelectItem value="Sent">Sent</SelectItem>
                  <SelectItem value="Accepted">Accepted</SelectItem>
                  <SelectItem value="Declined">Declined</SelectItem>
                </SelectContent>
              </Select>

              <Select value="newest" onValueChange={() => {}}>
                <SelectTrigger className="w-[140px]">
                  <SelectValue placeholder="Sort" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="newest">Newest First</SelectItem>
                  <SelectItem value="oldest">Oldest First</SelectItem>
                  <SelectItem value="amount-high">Amount High-Low</SelectItem>
                  <SelectItem value="amount-low">Amount Low-High</SelectItem>
                  <SelectItem value="company">Company A-Z</SelectItem>
                </SelectContent>
              </Select>

              <Select value="all-time" onValueChange={() => {}}>
                <SelectTrigger className="w-[140px]">
                  <SelectValue placeholder="Period" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all-time">All Time</SelectItem>
                  <SelectItem value="this-week">This Week</SelectItem>
                  <SelectItem value="this-month">This Month</SelectItem>
                  <SelectItem value="this-quarter">This Quarter</SelectItem>
                  <SelectItem value="this-year">This Year</SelectItem>
                  <SelectItem value="last-week">Last Week</SelectItem>
                  <SelectItem value="last-month">Last Month</SelectItem>
                  <SelectItem value="last-quarter">Last Quarter</SelectItem>
                  <SelectItem value="last-year">Last Year</SelectItem>
                  <SelectItem value="custom">Custom Period</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>


      {/* Quotes Table */}
      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <div className="min-w-[700px]">
              {/* Custom header that matches input styling */}
              <div className="flex h-8 w-full rounded-xl px-4 py-2 text-sm bg-gray-100 border border-gray-300 text-gray-500 mb-0 items-center">
                <div className="w-32 font-medium text-left">Date</div>
                <div className="w-40 font-medium text-left">Number</div>
                <div className="w-48 font-medium text-left">Customer</div>
                <div className="w-32 font-medium text-left">Total</div>
                <div className="w-32 font-medium text-left">Status</div>
                <div className="w-24 font-medium text-right">Actions</div>
              </div>
              <Table>
              <TableBody>
              {filteredQuotes.map((quote) => (
                <TableRow key={quote.id} className="hover:bg-muted/50" style={{ backgroundColor: '#fbfbfb' }}>
                  <TableCell className="w-32 text-left">
                    {new Date(quote.created_at).toLocaleDateString()}
                  </TableCell>
                  <TableCell className="w-40 font-medium text-left">
                    <Link 
                      to={`/quotes/${quote.id}`}
                      className="hover:text-primary underline"
                    >
                      {quote.quote_number}
                    </Link>
                  </TableCell>
                  <TableCell className="w-48 text-left">
                    <span className="truncate">{quote.customer?.company_name || "Unknown Customer"}</span>
                  </TableCell>
                  <TableCell className="w-32 font-medium text-left">
                    €{quote.total.toLocaleString()}
                  </TableCell>
                  <TableCell className="w-32 text-left" onClick={(e) => e.stopPropagation()}>
                    <StatusBadge
                      status={quote.status}
                      options={["Saved", "Sent", "Accepted", "Declined"]}
                      onChange={async (newStatus) => {
                        await handleStatusUpdate(quote.id, newStatus);
                      }}
                      model="quote"
                      id={quote.id}
                    />
                  </TableCell>
                  <TableCell className="w-24 text-right">
                    <div className="flex items-center gap-2 justify-end">
                      <Button 
                        variant="ghost" 
                        size="icon"
                        onClick={() => handleExportPDF(quote)}
                        title="Download PDF"
                      >
                        <Download className="h-4 w-4" />
                      </Button>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem asChild>
                            <Link to={`/quotes/${quote.id}`}>
                              <Eye className="h-4 w-4 mr-2" />
                              View
                            </Link>
                          </DropdownMenuItem>
                          <DropdownMenuItem asChild>
                            <Link to={`/quotes/${quote.id}/edit`}>
                              <Edit className="h-4 w-4 mr-2" />
                              Edit
                            </Link>
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <Copy className="h-4 w-4 mr-2" />
                            Duplicate
                          </DropdownMenuItem>
                          <DropdownMenuItem className="text-destructive">
                            <Trash2 className="h-4 w-4 mr-2" />
                            Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
              </TableBody>
            </Table>
            </div>
          </div>
          {filteredQuotes.length === 0 && (
            <div className="text-center py-12">
              <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-semibold">No quotes found</h3>
              <p className="text-muted-foreground mb-4">
                {searchTerm || statusFilter !== "all" 
                  ? "Try adjusting your search or filters"
                  : "Get started by creating your first quote"
                }
              </p>
              {!searchTerm && statusFilter === "all" && (
                <Link to="/quotes/new">
                  <Button>
                    <Plus className="h-4 w-4 mr-2" />
                    Create Quote
                  </Button>
                </Link>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
