import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Receipt, FolderKanban, CheckSquare, Plus, Calendar } from "lucide-react";
export function Dashboard() {
  const recentActivities = [{
    type: "invoice",
    message: "Invoice #1234 sent to Acme Corp",
    time: "2 hours ago"
  }, {
    type: "project",
    message: "Website Redesign project completed",
    time: "4 hours ago"
  }, {
    type: "client",
    message: "New client TechStart added",
    time: "1 day ago"
  }, {
    type: "quote",
    message: "Quote #567 approved by Digital Agency",
    time: "2 days ago"
  }];
  const upcomingDeadlines = [{
    project: "E-commerce Platform",
    task: "Payment Integration",
    due: "Tomorrow"
  }, {
    project: "Mobile App",
    task: "UI Testing",
    due: "In 3 days"
  }, {
    project: "Brand Identity",
    task: "Logo Revisions",
    due: "In 5 days"
  }];
  return <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl md:text-2xl lg:text-3xl font-semibold tracking-tight">Dashboard</h1>
          
        </div>
        <div className="flex items-center space-x-2">
          <Button variant="outline">
            <Calendar className="h-4 w-4 mr-2" />
            This Month
          </Button>
          <Button variant="grey">
            <Plus className="h-4 w-4 mr-2" />
            Quick Action
          </Button>
        </div>
      </div>


      <div className="grid gap-6 lg:grid-cols-2">
        {/* Recent Activities */}
        <Card className="shadow-soft">
          <CardHeader>
            <CardTitle>Recent Activities</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentActivities.map((activity, index) => <div key={index} className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-primary rounded-full mt-2" />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium">{activity.message}</p>
                    <p className="text-xs text-muted-foreground">{activity.time}</p>
                  </div>
                </div>)}
            </div>
          </CardContent>
        </Card>

        {/* Upcoming Deadlines */}
        <Card className="shadow-soft">
          <CardHeader>
            <CardTitle>Upcoming Deadlines</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {upcomingDeadlines.map((deadline, index) => <div key={index} className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                  <div>
                    <p className="text-sm font-medium">{deadline.project}</p>
                    <p className="text-xs text-muted-foreground">{deadline.task}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-xs font-medium text-warning">{deadline.due}</p>
                  </div>
                </div>)}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <Card className="shadow-soft">
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-4">
            <Button variant="outline" className="h-16 mx-0 text-sm">
              <Plus className="h-6 w-6" />
              Add Client
            </Button>
            <Button variant="outline" className="h-16 text-sm">
              <Receipt className="h-6 w-6" />
              Create Invoice
            </Button>
            <Button variant="outline" className="h-16 text-sm">
              <FolderKanban className="h-6 w-6" />
              New Project
            </Button>
            <Button variant="outline" className="h-16 text-sm">
              <CheckSquare className="h-6 w-6" />
              Add Task
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>;
}