import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart";
import { Users, Receipt, FolderKanban, CheckSquare, TrendingUp, Euro, Calendar, Filter, Download, BarChart3, LineChart, PieChart } from "lucide-react";
import { useState } from "react";
import { LineChart as RechartsLineChart, Line, XAxis, YAxis, CartesianGrid, ResponsiveContainer, BarChart as RechartsBarChart, Bar, PieChart as RechartsPieChart, Cell, Pie } from "recharts";
export function Analytics() {
  const [dateRange, setDateRange] = useState("30days");
  const [customerFilter, setCustomerFilter] = useState("all");

  // Mock data - replace with real data from Supabase
  const globalStats = [{
    title: "Total Customers",
    value: "24",
    change: "+12%",
    icon: Users,
    color: "text-primary"
  }, {
    title: "Total Revenue",
    value: "€45,200",
    change: "+18%",
    icon: Euro,
    color: "text-success"
  }, {
    title: "Active Projects",
    value: "8",
    change: "+2",
    icon: FolderKanban,
    color: "text-warning"
  }, {
    title: "Completed Tasks",
    value: "156",
    change: "+23",
    icon: CheckSquare,
    color: "text-info"
  }];
  const quotesOverTimeData = [{
    month: "Jan",
    quotes: 12,
    value: 15400
  }, {
    month: "Feb",
    quotes: 19,
    value: 22100
  }, {
    month: "Mar",
    quotes: 15,
    value: 18900
  }, {
    month: "Apr",
    quotes: 23,
    value: 28500
  }, {
    month: "May",
    quotes: 18,
    value: 21200
  }, {
    month: "Jun",
    quotes: 25,
    value: 31800
  }];
  const topCustomersData = [{
    name: "Acme Corp",
    revenue: 12500,
    projects: 3
  }, {
    name: "TechStart",
    revenue: 8900,
    projects: 2
  }, {
    name: "Digital Agency",
    revenue: 7200,
    projects: 4
  }, {
    name: "StartupCo",
    revenue: 5800,
    projects: 1
  }, {
    name: "Innovation Labs",
    revenue: 4200,
    projects: 2
  }];
  const statusDistributionData = [{
    name: "Active",
    value: 45,
    color: "#22c55e"
  }, {
    name: "Lead",
    value: 30,
    color: "#f59e0b"
  }, {
    name: "Inactive",
    value: 25,
    color: "#6b7280"
  }];
  const revenueByMonthData = [{
    month: "Jan",
    revenue: 15400
  }, {
    month: "Feb",
    revenue: 22100
  }, {
    month: "Mar",
    revenue: 18900
  }, {
    month: "Apr",
    revenue: 28500
  }, {
    month: "May",
    revenue: 21200
  }, {
    month: "Jun",
    revenue: 31800
  }];
  return <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl md:text-2xl lg:text-3xl font-semibold tracking-tight">Analytics & Reports</h1>
          
        </div>
        <div className="flex items-center space-x-2">
          <Button variant="outline">
            <Download className="h-4 w-4 mr-2" />
            Export Report
          </Button>
        </div>
      </div>

      {/* Filters */}
      <Card className="shadow-soft">
        <CardContent className="p-4">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <Filter className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm font-medium">Filters:</span>
            </div>
            
            <Select value={dateRange} onValueChange={setDateRange}>
              <SelectTrigger className="w-40">
                <Calendar className="h-4 w-4 mr-2" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="7days">Last 7 days</SelectItem>
                <SelectItem value="30days">Last 30 days</SelectItem>
                <SelectItem value="90days">Last 90 days</SelectItem>
                <SelectItem value="year">This year</SelectItem>
                <SelectItem value="custom">Custom range</SelectItem>
              </SelectContent>
            </Select>

            <Select value={customerFilter} onValueChange={setCustomerFilter}>
              <SelectTrigger className="w-40">
                <Users className="h-4 w-4 mr-2" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All customers</SelectItem>
                <SelectItem value="active">Active only</SelectItem>
                <SelectItem value="leads">Leads only</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Global Stats */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        {globalStats.map(stat => <Card key={stat.title} className="shadow-soft hover:shadow-medium transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                {stat.title}
              </CardTitle>
              <stat.icon className={`h-4 w-4 ${stat.color}`} />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stat.value}</div>
              <div className="flex items-center text-xs text-muted-foreground">
                <TrendingUp className="h-3 w-3 mr-1" />
                {stat.change} from last period
              </div>
            </CardContent>
          </Card>)}
      </div>

      {/* Charts Grid */}
      <div className="grid gap-6 lg:grid-cols-2">
        {/* Revenue Trend */}
        <Card className="shadow-soft">
          <CardHeader>
            <CardTitle className="flex items-center">
              <LineChart className="h-5 w-5 mr-2" />
              Revenue Trend
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ChartContainer config={{
            revenue: {
              label: "Revenue",
              color: "hsl(var(--primary))"
            }
          }} className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <RechartsLineChart data={revenueByMonthData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Line type="monotone" dataKey="revenue" stroke="hsl(var(--primary))" strokeWidth={2} dot={{
                  r: 4
                }} />
                </RechartsLineChart>
              </ResponsiveContainer>
            </ChartContainer>
          </CardContent>
        </Card>

        {/* Quotes Over Time */}
        <Card className="shadow-soft">
          <CardHeader>
            <CardTitle className="flex items-center">
              <BarChart3 className="h-5 w-5 mr-2" />
              Quotes Created
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ChartContainer config={{
            quotes: {
              label: "Quotes",
              color: "hsl(var(--secondary))"
            }
          }} className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <RechartsBarChart data={quotesOverTimeData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Bar dataKey="quotes" fill="hsl(var(--secondary))" radius={[4, 4, 0, 0]} />
                </RechartsBarChart>
              </ResponsiveContainer>
            </ChartContainer>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Customer Status Distribution */}
        <Card className="shadow-soft">
          <CardHeader>
            <CardTitle className="flex items-center">
              <PieChart className="h-5 w-5 mr-2" />
              Customer Status
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ChartContainer config={{
            status: {
              label: "Status"
            }
          }} className="h-[250px]">
              <ResponsiveContainer width="100%" height="100%">
                <RechartsPieChart>
                  <Pie data={statusDistributionData} cx="50%" cy="50%" outerRadius={80} dataKey="value" label={({
                  name,
                  value
                }) => `${name}: ${value}%`}>
                    {statusDistributionData.map((entry, index) => <Cell key={`cell-${index}`} fill={entry.color} />)}
                  </Pie>
                  <ChartTooltip content={<ChartTooltipContent />} />
                </RechartsPieChart>
              </ResponsiveContainer>
            </ChartContainer>
          </CardContent>
        </Card>

        {/* Top Customers */}
        <Card className="shadow-soft lg:col-span-2">
          <CardHeader>
            <CardTitle>Top Customers by Revenue</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {topCustomersData.map((customer, index) => <div key={customer.name} className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 rounded-full bg-gradient-primary flex items-center justify-center text-primary-foreground font-semibold text-sm">
                      {index + 1}
                    </div>
                    <div>
                      <p className="font-medium">{customer.name}</p>
                      <p className="text-sm text-muted-foreground">{customer.projects} projects</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold">€{customer.revenue.toLocaleString()}</p>
                    <Badge variant="secondary" className="text-xs">
                      {(customer.revenue / 45200 * 100).toFixed(1)}%
                    </Badge>
                  </div>
                </div>)}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Quick Insights */}
      <Card className="shadow-soft">
        <CardHeader>
          <CardTitle>Quick Insights</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            <div className="p-4 bg-accent/50 rounded-lg">
              <h4 className="font-semibold text-sm mb-2">Best Performing Month</h4>
              <p className="text-2xl font-bold text-primary">June</p>
              <p className="text-sm text-muted-foreground">€31,800 in revenue</p>
            </div>
            <div className="p-4 bg-accent/50 rounded-lg">
              <h4 className="font-semibold text-sm mb-2">Average Quote Value</h4>
              <p className="text-2xl font-bold text-primary">€1,810</p>
              <p className="text-sm text-muted-foreground">Up 15% from last period</p>
            </div>
            <div className="p-4 bg-accent/50 rounded-lg">
              <h4 className="font-semibold text-sm mb-2">Quote Acceptance Rate</h4>
              <p className="text-2xl font-bold text-primary">68%</p>
              <p className="text-sm text-muted-foreground">Above industry average</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>;
}