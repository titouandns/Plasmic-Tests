import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  FolderOpen,
  Loader2,
  GripVertical
} from "lucide-react";
import { useProjects, useTasks, Project } from "@/hooks/useSupabase";
import { supabase } from "@/integrations/supabase/client";
import { KanbanBoard } from "@/components/kanban/KanbanBoard";
import { TaskForm } from "@/components/forms/TaskForm";
import { cn } from "@/lib/utils";
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragEndEvent,
} from '@dnd-kit/core';
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  verticalListSortingStrategy,
} from '@dnd-kit/sortable';
import {
  useSortable,
} from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';

interface SortableProjectItemProps {
  project: any;
  selectedProject: string | null;
  onSelect: (projectId: string) => void;
  taskCount: number;
}

function SortableProjectItem({ project, selectedProject, onSelect, taskCount }: SortableProjectItemProps) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: project.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
  };

  const isSelected = selectedProject === project.id;

  return (
    <div
      ref={setNodeRef}
      style={style}
      className={cn(
        "flex items-center gap-2 w-full p-2 rounded-md transition-colors cursor-pointer",
        isSelected ? "bg-muted" : "hover:bg-muted/50",
        isDragging && "opacity-50"
      )}
      onClick={() => onSelect(project.id)}
    >
      <div
        {...attributes}
        {...listeners}
        className="cursor-grab active:cursor-grabbing p-1 -ml-1 text-muted-foreground hover:text-foreground"
      >
        <GripVertical className="h-4 w-4" />
      </div>
      <div 
        className="w-3 h-3 rounded-full flex-shrink-0" 
        style={{ backgroundColor: project.color_tag || '#3b82f6' }}
      />
      <span className="flex-1 text-sm font-medium truncate">
        {project.project_name}
      </span>
      <Badge variant="outline" className="text-xs">
        {taskCount}
      </Badge>
    </div>
  );
}

export function Tasks() {
  const [selectedProject, setSelectedProject] = useState<string | null>(null);
  const [showTaskForm, setShowTaskForm] = useState(false);
  const [sortedProjects, setSortedProjects] = useState<(Project & { order?: number })[]>([]);
  const [projectTaskCounts, setProjectTaskCounts] = useState<Record<string, number>>({});
  
  const { projects, loading: projectsLoading, updateProject } = useProjects();
  const { tasks: projectTasks, loading: tasksLoading } = useTasks(selectedProject);

  const loading = tasksLoading || projectsLoading;

  // Initialize sorted projects and set first project as default selection
  useEffect(() => {
    if (projects.length > 0) {
      // Sort projects by their order field (if exists) or maintain current order
      const sorted = [...projects].map((project, index) => ({ 
        ...project, 
        order: (project as any).order ?? index 
      })).sort((a, b) => a.order - b.order);
      setSortedProjects(sorted);
      
      // Set first project as default if no project is selected
      if (!selectedProject) {
        setSelectedProject(sorted[0].id);
      }
    }
  }, [projects, selectedProject]);

  // Fetch task counts for all projects
  useEffect(() => {
    const fetchTaskCounts = async () => {
      if (projects.length === 0) return;
      
      try {
        const { data, error } = await supabase
          .from('tasks')
          .select('project_id')
          .in('project_id', projects.map(p => p.id));

        if (error) {
          console.error('Error fetching task counts:', error);
          return;
        }

        // Count tasks per project
        const counts: Record<string, number> = {};
        projects.forEach(project => {
          counts[project.id] = data?.filter(task => task.project_id === project.id).length || 0;
        });
        
        setProjectTaskCounts(counts);
      } catch (error) {
        console.error('Error fetching task counts:', error);
      }
    };

    fetchTaskCounts();
  }, [projects]);

  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 8,
      },
    }),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  const handleDragEnd = async (event: DragEndEvent) => {
    const { active, over } = event;

    if (over && active.id !== over.id) {
      const oldIndex = sortedProjects.findIndex(project => project.id === active.id);
      const newIndex = sortedProjects.findIndex(project => project.id === over.id);

      const newSortedProjects = arrayMove(sortedProjects, oldIndex, newIndex);
      setSortedProjects(newSortedProjects);

      // Update the order in the database
      try {
        await Promise.all(
          newSortedProjects.map((project, index) =>
            updateProject(project.id, { order: index } as any)
          )
        );
      } catch (error) {
        console.error('Failed to update project order:', error);
        // Revert on error
        setSortedProjects(sortedProjects);
      }
    }
  };

  const selectedProjectData = sortedProjects.find(p => p.id === selectedProject);

  // Get task count for each project
  const getTaskCountForProject = (projectId: string) => {
    return projectTaskCounts[projectId] || 0;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="flex h-screen">
      {/* Project Sidebar */}
      <div className="w-80">
<div className="bg-background rounded-2xl border border-gray-300 shadow-lg max-h-96 max-w-[31.5rem] cursor-pointer overflow-hidden p-4 m-4">
          <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <FolderOpen className="h-5 w-5" />
            Projects
          </h2>
          <DndContext
            sensors={sensors}
            collisionDetection={closestCenter}
            onDragEnd={handleDragEnd}
          >
            <SortableContext
              items={sortedProjects.map(p => p.id)}
              strategy={verticalListSortingStrategy}
            >
              <div className="space-y-1">
                {sortedProjects.map((project) => (
                  <SortableProjectItem
                    key={project.id}
                    project={project}
                    selectedProject={selectedProject}
                    onSelect={setSelectedProject}
                    taskCount={getTaskCountForProject(project.id)}
                  />
                ))}
              </div>
            </SortableContext>
          </DndContext>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col">
        <div className="p-6 border-none border-border">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-xl md:text-2xl lg:text-3xl">
                {selectedProjectData ? selectedProjectData.project_name : "Tasks"}
              </h1>
              {selectedProjectData && (
                <p className="text-muted-foreground mt-1">
                  {selectedProjectData.customer?.company_name}
                </p>
              )}
            </div>
          </div>
        </div>

        <div className="flex-1 p-6 space-y-6">
          {/* Kanban Board */}
          {selectedProject ? (
            <Card className="border-none shadow-none">
              <CardContent className="p-0">
                <KanbanBoard projectId={selectedProject} />
              </CardContent>
            </Card>
          ) : (
            <Card className="shadow-soft">
              <CardContent className="flex items-center justify-center p-12">
                <div className="text-center">
                  <FolderOpen className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-medium mb-2">No Projects</h3>
                  <p className="text-muted-foreground">
                    Create a project to start managing tasks
                  </p>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      <TaskForm
        open={showTaskForm}
        onOpenChange={setShowTaskForm}
        projectId={selectedProject || ""}
        defaultStatus="todo"
      />
    </div>
  );
}
