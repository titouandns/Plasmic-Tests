import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/components/AuthProvider";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Loader2, Users, CheckCircle, XCircle } from "lucide-react";

interface InviteData {
  id: string;
  email: string;
  team_id: string;
  role: string;
  expires_at: string;
  used: boolean;
  teams: {
    name: string;
    logo?: string;
  };
}

export default function TeamJoin() {
  const { token } = useParams();
  const navigate = useNavigate();
  const { user, loading: authLoading } = useAuth();
  const [invite, setInvite] = useState<InviteData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [joining, setJoining] = useState(false);
  const [success, setSuccess] = useState(false);

  useEffect(() => {
    const fetchInvite = async () => {
      if (!token) {
        setError("Invalid invitation link");
        setLoading(false);
        return;
      }

      try {
        const { data, error } = await supabase
          .from('invites')
          .select(`
            id,
            email,
            team_id,
            role,
            expires_at,
            used,
            teams (
              name,
              logo
            )
          `)
          .eq('token', token)
          .single();

        if (error || !data) {
          setError("Invitation not found or invalid");
          return;
        }

        if (data.used) {
          setError("This invitation has already been used");
          return;
        }

        if (new Date(data.expires_at) < new Date()) {
          setError("This invitation has expired");
          return;
        }

        setInvite(data);
      } catch (err) {
        console.error('Error fetching invite:', err);
        setError("Failed to load invitation details");
      } finally {
        setLoading(false);
      }
    };

    fetchInvite();
  }, [token]);

  const handleJoinTeam = async () => {
    if (!invite || !user) return;

    setJoining(true);
    try {
      // Check if user email matches invite email
      if (user.email !== invite.email) {
        setError(`This invitation was sent to ${invite.email}. Please sign in with that email address.`);
        setJoining(false);
        return;
      }

      // Add user to team
      const { error: memberError } = await supabase
        .from('team_members')
        .insert({
          team_id: invite.team_id,
          user_id: user.id,
          role: invite.role,
          invited_by: user.id
        });

      if (memberError) throw memberError;

      // Mark invite as used
      const { error: inviteError } = await supabase
        .from('invites')
        .update({ used: true })
        .eq('id', invite.id);

      if (inviteError) throw inviteError;

      // Update user's profile with team_id
      const { error: profileError } = await supabase
        .from('profiles')
        .update({ team_id: invite.team_id })
        .eq('user_id', user.id);

      if (profileError) throw profileError;

      setSuccess(true);
      
      // Redirect to dashboard after a short delay
      setTimeout(() => {
        navigate('/dashboard');
      }, 2000);

    } catch (err) {
      console.error('Error joining team:', err);
      setError("Failed to join team. Please try again.");
    } finally {
      setJoining(false);
    }
  };

  if (authLoading || loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="flex items-center space-x-2">
          <Loader2 className="h-4 w-4 animate-spin" />
          <span>Loading invitation...</span>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background p-4">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <XCircle className="h-12 w-12 text-destructive mx-auto mb-2" />
            <CardTitle>Invitation Error</CardTitle>
          </CardHeader>
          <CardContent>
            <Alert variant="destructive">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
            <Button 
              variant="outline" 
              className="w-full mt-4"
              onClick={() => navigate('/auth')}
            >
              Go to Sign In
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (success) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background p-4">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <CheckCircle className="h-12 w-12 text-green-500 mx-auto mb-2" />
            <CardTitle>Welcome to the Team!</CardTitle>
            <CardDescription>
              You've successfully joined {invite?.teams.name}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-center text-muted-foreground mb-4">
              Redirecting you to the dashboard...
            </p>
            <div className="flex justify-center">
              <Loader2 className="h-4 w-4 animate-spin" />
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background p-4">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <Users className="h-12 w-12 text-primary mx-auto mb-2" />
            <CardTitle>Team Invitation</CardTitle>
            <CardDescription>
              You've been invited to join {invite?.teams.name}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Alert className="mb-4">
              <AlertDescription>
                Please sign in to accept this team invitation.
              </AlertDescription>
            </Alert>
            <Button 
              className="w-full"
              onClick={() => navigate('/auth')}
            >
              Sign In to Join Team
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <Users className="h-12 w-12 text-primary mx-auto mb-2" />
          <CardTitle>Team Invitation</CardTitle>
          <CardDescription>
            You've been invited to join {invite?.teams.name}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="text-center">
              <p className="text-sm text-muted-foreground">
                Role: <span className="capitalize font-medium">{invite?.role}</span>
              </p>
              <p className="text-sm text-muted-foreground">
                Invited to: {invite?.email}
              </p>
            </div>
            
            <Button 
              className="w-full" 
              onClick={handleJoinTeam}
              disabled={joining}
            >
              {joining ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Joining Team...
                </>
              ) : (
                'Join Team'
              )}
            </Button>
            
            <Button 
              variant="outline" 
              className="w-full"
              onClick={() => navigate('/dashboard')}
            >
              Cancel
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}