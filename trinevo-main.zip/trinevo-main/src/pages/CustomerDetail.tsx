import { useState, useEffect, useRef } from "react";
import { useLocation, useNavigate, useParams } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { ArrowLeft, Mail, Phone, MapPin } from "lucide-react";
import { SaveChangesBar } from "@/components/SaveChangesBar";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/components/AuthProvider";
import { cn } from "@/lib/utils";
type Customer = {
  id: string;
  company_name: string;
  contact_name: string;
  email: string;
  phone?: string;
  status: 'active' | 'inactive' | 'lead';
  billing_address?: string; // Legacy field
  street_address?: string;
  city?: string;
  postcode?: string;
  country?: string;
  state_region?: string;
  company_number?: string;
  tax_number?: string;
  notes?: string;
  created_at: string;
  updated_at: string;
  user_id: string;
};
type PlacePrediction = {
  place_id: string;
  description: string;
  structured_formatting: {
    main_text: string;
    secondary_text: string;
  };
};
export function CustomerDetail() {
  const navigate = useNavigate();
  const {
    toast
  } = useToast();
  const {
    user
  } = useAuth();
  const {
    id
  } = useParams();

  // Get customer ID from URL parameter
  const customerId = id === 'new' ? null : id;
  const isNewCustomer = id === 'new';
  const [loading, setLoading] = useState(false);
  const [originalData, setOriginalData] = useState<Customer | null>(null);
  const [currentData, setCurrentData] = useState<Partial<Customer>>({
    company_name: '',
    contact_name: '',
    email: '',
    phone: '',
    status: 'lead',
    street_address: '',
    city: '',
    postcode: '',
    country: '',
    state_region: '',
    company_number: '',
    tax_number: '',
    notes: ''
  });
  const [saving, setSaving] = useState(false);

  // Google Places Autocomplete state
  const [placesService, setPlacesService] = useState<google.maps.places.AutocompleteService | null>(null);
  const [placeDetailsService, setPlaceDetailsService] = useState<google.maps.places.PlacesService | null>(null);
  const [predictions, setPredictions] = useState<PlacePrediction[]>([]);
  const [showDropdown, setShowDropdown] = useState(false);
  const [selectedIndex, setSelectedIndex] = useState(-1);
  const streetInputRef = useRef<HTMLInputElement>(null);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Initialize Google Places Services
  useEffect(() => {
    const initPlacesServices = async () => {
      try {
        // Fetch API key from edge function
        const {
          data,
          error
        } = await supabase.functions.invoke('get-maps-api-key');
        if (error || !data?.apiKey) {
          console.error('Error fetching Google Maps API key:', error);
          return;
        }

        // Load Google Maps API
        const script = document.createElement('script');
        script.src = `https://maps.googleapis.com/maps/api/js?key=${data.apiKey}&libraries=places`;
        script.async = true;
        script.defer = true;
        script.onload = () => {
          const autocompleteService = new google.maps.places.AutocompleteService();
          const placesService = new google.maps.places.PlacesService(document.createElement('div'));
          setPlacesService(autocompleteService);
          setPlaceDetailsService(placesService);
        };
        script.onerror = () => {
          console.error('Failed to load Google Maps script');
        };
        document.head.appendChild(script);
        return () => {
          document.head.removeChild(script);
        };
      } catch (error) {
        console.error('Error initializing Google Places:', error);
      }
    };
    initPlacesServices();
  }, []);

  // Handle address input changes and get predictions
  const handleAddressInputChange = (value: string) => {
    updateField('street_address', value);
    if (!placesService || value.length < 3) {
      setPredictions([]);
      setShowDropdown(false);
      return;
    }
    placesService.getPlacePredictions({
      input: value,
      types: ['address']
    }, (predictions, status) => {
      if (status === google.maps.places.PlacesServiceStatus.OK && predictions) {
        setPredictions(predictions as PlacePrediction[]);
        setShowDropdown(true);
        setSelectedIndex(-1);
      } else {
        setPredictions([]);
        setShowDropdown(false);
      }
    });
  };

  // Handle place selection
  const handlePlaceSelect = (prediction: PlacePrediction) => {
    if (!placeDetailsService) return;
    placeDetailsService.getDetails({
      placeId: prediction.place_id,
      fields: ['address_components', 'formatted_address']
    }, (place, status) => {
      if (status === google.maps.places.PlacesServiceStatus.OK && place?.address_components) {
        let street = '';
        let city = '';
        let postcode = '';
        let country = '';
        let state = '';
        place.address_components.forEach(component => {
          const types = component.types;
          if (types.includes('street_number')) {
            street = component.long_name + ' ';
          }
          if (types.includes('route')) {
            street += component.long_name;
          }
          if (types.includes('locality') || types.includes('administrative_area_level_2')) {
            city = component.long_name;
          }
          if (types.includes('postal_code')) {
            postcode = component.long_name;
          }
          if (types.includes('country')) {
            country = component.long_name;
          }
          if (types.includes('administrative_area_level_1')) {
            state = component.long_name;
          }
        });

        // Update the form fields
        setCurrentData(prev => ({
          ...prev,
          street_address: street.trim(),
          city,
          postcode,
          country,
          state_region: state
        }));
        setShowDropdown(false);
        setPredictions([]);
      }
    });
  };

  // Handle keyboard navigation
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (!showDropdown || predictions.length === 0) return;
    switch (e.key) {
      case 'ArrowDown':
        e.preventDefault();
        setSelectedIndex(prev => prev < predictions.length - 1 ? prev + 1 : prev);
        break;
      case 'ArrowUp':
        e.preventDefault();
        setSelectedIndex(prev => prev > 0 ? prev - 1 : prev);
        break;
      case 'Enter':
        e.preventDefault();
        if (selectedIndex >= 0 && selectedIndex < predictions.length) {
          handlePlaceSelect(predictions[selectedIndex]);
        }
        break;
      case 'Escape':
        setShowDropdown(false);
        setSelectedIndex(-1);
        break;
    }
  };

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node) && streetInputRef.current && !streetInputRef.current.contains(event.target as Node)) {
        setShowDropdown(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Format address for display
  const formatAddress = (customer: Partial<Customer>) => {
    const parts = [customer.street_address, customer.city, customer.state_region, customer.postcode, customer.country].filter(Boolean);
    return parts.length > 0 ? parts.join(', ') : customer.billing_address || '';
  };
  const getAvatarColor = (name: string) => {
    const colors = ["hsl(210, 40%, 85%)", "hsl(200, 45%, 85%)", "hsl(190, 40%, 85%)", "hsl(180, 35%, 85%)", "hsl(170, 40%, 85%)", "hsl(160, 45%, 85%)", "hsl(150, 40%, 85%)", "hsl(140, 35%, 85%)", "hsl(130, 40%, 85%)", "hsl(120, 45%, 85%)", "hsl(60, 40%, 85%)", "hsl(50, 45%, 85%)", "hsl(40, 40%, 85%)", "hsl(30, 45%, 85%)", "hsl(20, 40%, 85%)", "hsl(10, 35%, 85%)", "hsl(350, 40%, 85%)", "hsl(340, 45%, 85%)", "hsl(330, 40%, 85%)", "hsl(320, 35%, 85%)"];
    let hash = 0;
    for (let i = 0; i < name.length; i++) {
      hash = name.charCodeAt(i) + ((hash << 5) - hash);
    }
    return colors[Math.abs(hash) % colors.length];
  };

  // Check if any field has been modified from original or if it's a new customer with data
  const hasChanges = () => {
    if (isNewCustomer) {
      return !!(currentData.company_name || currentData.contact_name);
    }
    if (!originalData) return false;
    return currentData.company_name !== originalData.company_name || currentData.contact_name !== originalData.contact_name || currentData.email !== originalData.email || currentData.phone !== originalData.phone || currentData.status !== originalData.status || currentData.street_address !== originalData.street_address || currentData.city !== originalData.city || currentData.postcode !== originalData.postcode || currentData.country !== originalData.country || currentData.state_region !== originalData.state_region || currentData.company_number !== originalData.company_number || currentData.tax_number !== originalData.tax_number || currentData.notes !== originalData.notes;
  };
  const fetchCustomer = async () => {
    if (!customerId || isNewCustomer) return;
    try {
      setLoading(true);
      const {
        data,
        error
      } = await supabase.from('customers').select('*').eq('id', customerId).maybeSingle();
      if (error) {
        console.error('Error fetching customer:', error);
        toast({
          title: "Error",
          description: "Failed to fetch customer details",
          variant: "destructive"
        });
        return;
      }
      if (!data) {
        toast({
          title: "Not Found",
          description: "Customer not found",
          variant: "destructive"
        });
        navigate('/customers');
        return;
      }
      const customerData = data as Customer;
      setOriginalData(customerData);
      setCurrentData(customerData);
    } catch (error) {
      console.error('Error fetching customer:', error);
      toast({
        title: "Error",
        description: "Failed to fetch customer details",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };
  const handleSave = async () => {
    if (!currentData.company_name && !currentData.contact_name) {
      toast({
        title: "Validation Error",
        description: "Either company name or contact name is required",
        variant: "destructive"
      });
      return;
    }
    try {
      setSaving(true);
      if (isNewCustomer) {
        // Create new customer
        const insertData = {
          company_name: currentData.company_name || '',
          contact_name: currentData.contact_name || '',
          email: currentData.email || null,
          phone: currentData.phone || '',
          status: currentData.status || 'lead',
          street_address: currentData.street_address || null,
          city: currentData.city || null,
          postcode: currentData.postcode || null,
          country: currentData.country || null,
          state_region: currentData.state_region || null,
          company_number: currentData.company_number || null,
          tax_number: currentData.tax_number || null,
          notes: currentData.notes || '',
          user_id: user!.id
        };
        const {
          data,
          error
        } = await supabase.from('customers').insert([insertData]).select().single();
        if (error) {
          console.error('Error creating customer:', error);
          toast({
            title: "Error",
            description: "Failed to create customer",
            variant: "destructive"
          });
          return;
        }
        const newCustomer = data as Customer;
        toast({
          title: "Success",
          description: "Customer created successfully"
        });

        // Update state to switch to edit mode with the new customer data
        setOriginalData(newCustomer);
        setCurrentData(newCustomer);

        // Navigate to the customer detail page with the new ID
        navigate(`/customers/${newCustomer.id}`, {
          replace: true
        });
      } else {
        // Update existing customer
        if (!originalData || !customerId) return;
        const {
          data,
          error
        } = await supabase.from('customers').update(currentData).eq('id', customerId).select().single();
        if (error) {
          console.error('Error updating customer:', error);
          toast({
            title: "Error",
            description: "Failed to update customer",
            variant: "destructive"
          });
          return;
        }
        const updatedCustomer = data as Customer;
        setOriginalData(updatedCustomer);
        setCurrentData(updatedCustomer);
        toast({
          title: "Success",
          description: "Customer updated successfully"
        });
      }
    } catch (error) {
      console.error('Error saving customer:', error);
      toast({
        title: "Error",
        description: "Failed to save customer",
        variant: "destructive"
      });
    } finally {
      setSaving(false);
    }
  };
  const updateField = (field: keyof Customer, value: string) => {
    setCurrentData(prev => ({
      ...prev,
      [field]: value
    }));
  };
  useEffect(() => {
    if (!isNewCustomer && customerId) {
      setLoading(true);
      fetchCustomer();
    }
  }, [customerId, isNewCustomer]);
  if (loading) {
    return <div className="space-y-6">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={() => navigate('/customers')}>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <h1 className="text-3xl font-bold">Loading...</h1>
        </div>
      </div>;
  }

  // Only show "Customer Not Found" if we expected to load a customer but couldn't
  if (!isNewCustomer && customerId && !loading && !originalData) {
    return <div className="space-y-6">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={() => navigate('/customers')}>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <h1 className="text-3xl font-bold">Customer Not Found</h1>
        </div>
      </div>;
  }
  return <div className="space-y-6 relative">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={() => navigate('/customers')}>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          
        </div>
      </div>

      {/* Customer Profile Section */}
      <Card>
        <CardHeader>
          <CardTitle>Customer Profile</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-start gap-6">
            <Avatar className="h-16 w-16" style={{
            backgroundColor: getAvatarColor(currentData.company_name || '')
          }}>
              <AvatarFallback className="text-lg font-medium" style={{
              backgroundColor: getAvatarColor(currentData.company_name || ''),
              color: 'hsl(var(--foreground))'
            }}>
                {(currentData.company_name || '').charAt(0).toUpperCase()}
              </AvatarFallback>
            </Avatar>
            
            <div className="flex-1 space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <div>
                  <Label className="text-sm font-medium text-muted-foreground">Company Name</Label>
                  <Input value={currentData.company_name || ''} onChange={e => updateField('company_name', e.target.value)} className="mt-1" placeholder="Company name" />
                </div>
                
                <div>
                  <Label className="text-sm font-medium text-muted-foreground">Contact Name</Label>
                  <Input value={currentData.contact_name || ''} onChange={e => updateField('contact_name', e.target.value)} className="mt-1" placeholder="Contact name" />
                </div>
              </div>

              <div className="grid gap-4 md:grid-cols-2">
                <div>
                  <Label className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                    <Mail className="h-4 w-4" />
                    Email
                  </Label>
                  <Input type="email" value={currentData.email || ''} onChange={e => updateField('email', e.target.value)} className="mt-1" placeholder="Email address" />
                </div>
                
                <div>
                  <Label className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                    <Phone className="h-4 w-4" />
                    Phone
                  </Label>
                  <Input value={currentData.phone || ''} onChange={e => updateField('phone', e.target.value)} className="mt-1" placeholder="Phone number" />
                </div>
              </div>

              <div className="grid gap-4 md:grid-cols-2">
                <div>
                  <Label className="text-sm font-medium text-muted-foreground">Company Number</Label>
                  <Input value={currentData.company_number || ''} onChange={e => updateField('company_number', e.target.value)} className="mt-1" placeholder="12345678" />
                </div>
                
                <div>
                  <Label className="text-sm font-medium text-muted-foreground">Tax Number</Label>
                  <Input value={currentData.tax_number || ''} onChange={e => updateField('tax_number', e.target.value)} className="mt-1" placeholder="GB123456789" />
                </div>
              </div>

              <div>
                <Label className="text-sm font-medium text-muted-foreground">Status</Label>
                <Select value={currentData.status || 'lead'} onValueChange={(value: "active" | "inactive" | "lead") => updateField('status', value)}>
                  <SelectTrigger className="w-32 mt-1">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="lead">Lead</SelectItem>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="inactive">Inactive</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Additional Details Section */}
      <Card>
        <CardHeader>
          <CardTitle>Additional Details</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label className="text-sm font-medium text-muted-foreground flex items-center gap-2">
              <MapPin className="h-4 w-4" />
              Address
            </Label>
            <div className="space-y-4 mt-2">
              <div className="relative">
                <Label className="text-xs text-muted-foreground">Street Address</Label>
                <Input ref={streetInputRef} value={currentData.street_address || ''} onChange={e => handleAddressInputChange(e.target.value)} onKeyDown={handleKeyDown} placeholder="Start typing an address for suggestions..." className="mt-1" autoComplete="off" />
                
                {/* Custom dropdown for address suggestions */}
                {showDropdown && predictions.length > 0 && <div ref={dropdownRef} className="absolute z-50 w-full mt-1 bg-background border border-border rounded-md shadow-lg max-h-60 overflow-y-auto">
                    {predictions.map((prediction, index) => <div key={prediction.place_id} className={cn("px-3 py-2 cursor-pointer text-sm hover:bg-muted transition-colors", index === selectedIndex && "bg-muted")} onClick={() => handlePlaceSelect(prediction)}>
                        <div className="font-medium text-foreground">
                          {prediction.structured_formatting.main_text}
                        </div>
                        <div className="text-xs text-muted-foreground">
                          {prediction.structured_formatting.secondary_text}
                        </div>
                      </div>)}
                  </div>}
              </div>
              
              <div className="grid gap-4 md:grid-cols-2">
                <div>
                  <Label className="text-xs text-muted-foreground">City</Label>
                  <Input value={currentData.city || ''} onChange={e => updateField('city', e.target.value)} placeholder="City" className="mt-1" />
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground">Postcode</Label>
                  <Input value={currentData.postcode || ''} onChange={e => updateField('postcode', e.target.value)} placeholder="Postcode" className="mt-1" />
                </div>
              </div>
              
              <div className="grid gap-4 md:grid-cols-2">
                <div>
                  <Label className="text-xs text-muted-foreground">Country</Label>
                  <Input value={currentData.country || ''} onChange={e => updateField('country', e.target.value)} placeholder="Country" className="mt-1" />
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground">State/Region <span className="text-xs">(optional)</span></Label>
                  <Input value={currentData.state_region || ''} onChange={e => updateField('state_region', e.target.value)} placeholder="State or region" className="mt-1" />
                </div>
              </div>
            </div>
          </div>

          <div>
            <Label className="text-sm font-medium text-muted-foreground">Notes</Label>
            <Textarea value={currentData.notes || ''} onChange={e => updateField('notes', e.target.value)} placeholder="Add notes about this customer..." className="mt-1" rows={4} />
          </div>

          {!isNewCustomer && originalData && <div className="grid gap-4 md:grid-cols-2 text-xs text-muted-foreground">
              <div>
                <Label className="text-xs font-medium">Created</Label>
                <p>{new Date(originalData.created_at).toLocaleDateString()}</p>
              </div>
              <div>
                <Label className="text-xs font-medium">Last Updated</Label>
                <p>{new Date(originalData.updated_at).toLocaleDateString()}</p>
              </div>
            </div>}
        </CardContent>
      </Card>

      <SaveChangesBar isDirty={hasChanges()} onSave={handleSave} isLoading={saving} />
    </div>;
}