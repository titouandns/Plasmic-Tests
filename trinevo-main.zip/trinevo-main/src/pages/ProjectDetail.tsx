import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { format } from "date-fns";
import { 
  ArrowLeft, 
  Calendar as CalendarIcon,
  Target,
  Plus,
  Clock,
  CheckCircle,
  PlayCircle,
  BarChart3,
  Edit,
  Save,
  X,
  Palette,
  FileText,
  ExternalLink
} from "lucide-react";
import { useProjects, useTasks, useQuotes, Project } from "@/hooks/useSupabase";
import { KanbanBoard } from "@/components/kanban/KanbanBoard";
import { TaskForm } from "@/components/forms/TaskForm";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";

const COLOR_OPTIONS = [
  { value: '#3b82f6', label: 'Blue' },
  { value: '#10b981', label: 'Green' },
  { value: '#f59e0b', label: 'Orange' },
  { value: '#ef4444', label: 'Red' },
  { value: '#8b5cf6', label: 'Purple' },
  { value: '#06b6d4', label: 'Cyan' },
  { value: '#84cc16', label: 'Lime' },
  { value: '#f97316', label: 'Orange' },
  { value: '#ec4899', label: 'Pink' },
  { value: '#6b7280', label: 'Gray' }
];

export function ProjectDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { projects } = useProjects();
  const { quotes } = useQuotes();
  const { tasks } = useTasks(id);
  const [project, setProject] = useState<Project | null>(null);
  const [linkedQuote, setLinkedQuote] = useState<any>(null);
  const [showTaskForm, setShowTaskForm] = useState(false);
  const { toast } = useToast();

  // Edit states
  const [editingField, setEditingField] = useState<string | null>(null);
  const [editValues, setEditValues] = useState({
    project_name: '',
    description: '',
    status: '',
    color_tag: '',
    due_date: null as Date | null,
    start_date: null as Date | null
  });

  useEffect(() => {
    const foundProject = projects.find(p => p.id === id);
    setProject(foundProject || null);
    if (foundProject) {
      setEditValues({
        project_name: foundProject.project_name || '',
        description: foundProject.description || '',
        status: foundProject.status || '',
        color_tag: foundProject.color_tag || '#3b82f6',
        due_date: foundProject.due_date ? new Date(foundProject.due_date) : null,
        start_date: foundProject.start_date ? new Date(foundProject.start_date) : null
      });
      
      // Find linked quote if exists
      if (foundProject.quote_id) {
        const quote = quotes.find(q => q.id === foundProject.quote_id);
        setLinkedQuote(quote || null);
      }
    }
  }, [projects, quotes, id]);

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "bg-success text-success-foreground";
      case "in_progress":
        return "bg-primary text-primary-foreground";
      case "not_started":
        return "bg-warning text-warning-foreground";
      case "cancelled":
        return "bg-muted text-muted-foreground";
      default:
        return "bg-secondary text-secondary-foreground";
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "completed":
        return CheckCircle;
      case "in_progress":
        return PlayCircle;
      case "not_started":
        return Target;
      case "cancelled":
        return Clock;
      default:
        return Target;
    }
  };

  const handleSaveField = async (field: string) => {
    if (!project || !id) return;

    try {
      const updateData: any = {};
      
      if (field === 'due_date' || field === 'start_date') {
        updateData[field] = editValues[field] ? editValues[field]!.toISOString().split('T')[0] : null;
      } else {
        updateData[field] = editValues[field as keyof typeof editValues];
      }

      const { error } = await supabase
        .from('projects')
        .update(updateData)
        .eq('id', id);

      if (error) throw error;

      // Update local state
      setProject(prev => prev ? { ...prev, ...updateData } : null);
      setEditingField(null);
      
      toast({
        title: "Success",
        description: "Project updated successfully"
      });
    } catch (error) {
      console.error('Error updating project:', error);
      toast({
        title: "Error",
        description: "Failed to update project",
        variant: "destructive"
      });
    }
  };

  const handleCancelEdit = () => {
    if (project) {
      setEditValues({
        project_name: project.project_name || '',
        description: project.description || '',
        status: project.status || '',
        color_tag: project.color_tag || '#3b82f6',
        due_date: project.due_date ? new Date(project.due_date) : null,
        start_date: project.start_date ? new Date(project.start_date) : null
      });
    }
    setEditingField(null);
  };

  const totalTasks = tasks.length;
  const completedTasks = tasks.filter(task => task.status === 'done').length;
  const inProgressTasks = tasks.filter(task => task.status === 'in_progress').length;
  const todoTasks = tasks.filter(task => task.status === 'todo').length;

  if (!project) {
    return (
      <div className="p-6">
        <div className="flex items-center gap-4 mb-6">
          <Button variant="ghost" onClick={() => navigate("/projects")}>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div>Project not found</div>
        </div>
      </div>
    );
  }

  const StatusIcon = getStatusIcon(project.status);

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="sm" onClick={() => navigate("/projects")}>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          
          <div className="flex items-center gap-3">
            <div 
              className="w-2 h-2 rounded-full" 
              style={{ backgroundColor: project.color_tag || '#3b82f6' }}
            />
            
            {/* Editable Project Name */}
            {editingField === 'project_name' ? (
              <div className="flex items-center gap-2">
                <Input
                  value={editValues.project_name}
                  onChange={(e) => setEditValues(prev => ({ ...prev, project_name: e.target.value }))}
                  className="text-xl font-semibold border-none bg-transparent p-0 h-auto focus-visible:ring-0 shadow-none"
                  autoFocus
                  onBlur={() => handleSaveField('project_name')}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') handleSaveField('project_name');
                    if (e.key === 'Escape') handleCancelEdit();
                  }}
                />
              </div>
            ) : (
              <h1 
                className="text-xl font-semibold cursor-pointer hover:opacity-70" 
                onClick={() => setEditingField('project_name')}
              >
                {project.project_name}
              </h1>
            )}

            {/* Editable Status */}
            {editingField === 'status' ? (
              <Select 
                value={editValues.status} 
                onValueChange={(value) => {
                  setEditValues(prev => ({ ...prev, status: value }));
                  handleSaveField('status');
                }}
              >
                <SelectTrigger className="w-[130px] h-7 text-xs">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-background border shadow-md z-50">
                  <SelectItem value="not_started">Not Started</SelectItem>
                  <SelectItem value="in_progress">In Progress</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                  <SelectItem value="cancelled">Cancelled</SelectItem>
                </SelectContent>
              </Select>
            ) : (
              <Badge 
                className={`${getStatusColor(project.status)} cursor-pointer text-xs px-2 py-1 hover:opacity-80`}
                onClick={() => setEditingField('status')}
              >
                {project.status.replace('_', ' ')}
              </Badge>
            )}
          </div>
        </div>
        
        <div className="flex items-center gap-3">
          <span className="text-sm text-muted-foreground">{project.customer?.company_name}</span>
          <Button variant="outline" size="sm" onClick={() => setShowTaskForm(true)}>
            <Plus className="h-3 w-3 mr-2" />
            Add Task
          </Button>
        </div>
      </div>

      {/* Project Details */}
      <div className="space-y-6">
        {/* Progress & Stats */}
        <div className="flex items-center gap-8 py-4 border-b">
          <div className="flex items-center gap-4">
            <span className="text-sm text-muted-foreground w-16">Progress</span>
            <div className="flex items-center gap-3 min-w-[200px]">
              <Progress value={project.progress || 0} className="h-1.5 flex-1" />
              <span className="text-sm font-medium w-10">{project.progress || 0}%</span>
            </div>
          </div>
          
          <div className="flex items-center gap-6 text-sm">
            <span className="text-muted-foreground">
              <span className="font-medium text-foreground">{completedTasks}</span> of <span className="font-medium text-foreground">{totalTasks}</span> tasks
            </span>
            <span className="text-muted-foreground">
              <span className="font-medium text-foreground">{inProgressTasks}</span> in progress
            </span>
          </div>
        </div>

        {/* Dates */}
        <div className="flex items-center gap-8 py-4 border-b">
          <span className="text-sm text-muted-foreground w-16">Timeline</span>
          <div className="flex items-center gap-8">
            <div className="flex items-center gap-2">
              <span className="text-sm text-muted-foreground">Start:</span>
              {editingField === 'start_date' ? (
                <Popover open={true} onOpenChange={(open) => !open && setEditingField(null)}>
                  <PopoverContent className="w-auto p-0 bg-background border shadow-md z-50" align="start">
                    <Calendar
                      mode="single"
                      selected={editValues.start_date}
                      onSelect={(date) => {
                        setEditValues(prev => ({ ...prev, start_date: date || null }));
                        handleSaveField('start_date');
                      }}
                      initialFocus
                      className="p-3 pointer-events-auto"
                    />
                  </PopoverContent>
                </Popover>
              ) : (
                <span 
                  className="text-sm cursor-pointer hover:underline"
                  onClick={() => setEditingField('start_date')}
                >
                  {project.start_date ? format(new Date(project.start_date), "MMM d, yyyy") : "Not set"}
                </span>
              )}
            </div>
            
            <div className="flex items-center gap-2">
              <span className="text-sm text-muted-foreground">Due:</span>
              {editingField === 'due_date' ? (
                <Popover open={true} onOpenChange={(open) => !open && setEditingField(null)}>
                  <PopoverContent className="w-auto p-0 bg-background border shadow-md z-50" align="start">
                    <Calendar
                      mode="single"
                      selected={editValues.due_date}
                      onSelect={(date) => {
                        setEditValues(prev => ({ ...prev, due_date: date || null }));
                        handleSaveField('due_date');
                      }}
                      initialFocus
                      className="p-3 pointer-events-auto"
                    />
                  </PopoverContent>
                </Popover>
              ) : (
                <span 
                  className="text-sm cursor-pointer hover:underline"
                  onClick={() => setEditingField('due_date')}
                >
                  {project.due_date ? format(new Date(project.due_date), "MMM d, yyyy") : "Not set"}
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Description */}
        <div className="flex gap-8 py-4 border-b">
          <span className="text-sm text-muted-foreground w-16">About</span>
          <div className="flex-1">
            {editingField === 'description' ? (
              <Textarea
                value={editValues.description}
                onChange={(e) => setEditValues(prev => ({ ...prev, description: e.target.value }))}
                placeholder="Add a description..."
                rows={3}
                autoFocus
                className="resize-none border-none p-0 shadow-none focus-visible:ring-0"
                onBlur={() => handleSaveField('description')}
                onKeyDown={(e) => {
                  if (e.key === 'Escape') handleCancelEdit();
                }}
              />
            ) : (
              <p 
                className="text-sm cursor-pointer hover:opacity-70 min-h-[20px]"
                onClick={() => setEditingField('description')}
              >
                {project.description || "Add a description..."}
              </p>
            )}
          </div>
        </div>

        {/* Color Tag */}
        <div className="flex items-center gap-8 py-4 border-b">
          <span className="text-sm text-muted-foreground w-16">Color</span>
          {editingField === 'color_tag' ? (
            <div className="flex gap-2">
              {COLOR_OPTIONS.map((color) => (
                <button
                  key={color.value}
                  className={`w-6 h-6 rounded-full border-2 hover:scale-110 transition-transform ${
                    editValues.color_tag === color.value ? 'border-foreground' : 'border-border'
                  }`}
                  style={{ backgroundColor: color.value }}
                  onClick={() => {
                    setEditValues(prev => ({ ...prev, color_tag: color.value }));
                    handleSaveField('color_tag');
                  }}
                />
              ))}
            </div>
          ) : (
            <div 
              className="w-6 h-6 rounded-full border-2 border-border cursor-pointer hover:scale-110 transition-transform" 
              style={{ backgroundColor: project.color_tag || '#3b82f6' }}
              onClick={() => setEditingField('color_tag')}
            />
          )}
        </div>

        {/* Linked Quote */}
        {linkedQuote && (
          <div className="flex items-center gap-8 py-4 border-b">
            <span className="text-sm text-muted-foreground w-16">Quote</span>
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <FileText className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm font-medium">
                  Quote {linkedQuote.quote_number}
                </span>
                <Badge variant="outline" className="text-xs">
                  {linkedQuote.status}
                </Badge>
              </div>
              <div className="text-sm text-muted-foreground">
                Total: €{linkedQuote.total.toFixed(2)}
              </div>
              <Button 
                variant="ghost" 
                size="sm"
                onClick={() => navigate(`/quotes/${linkedQuote.id}`)}
                className="h-auto p-1"
              >
                <ExternalLink className="h-3 w-3" />
              </Button>
            </div>
          </div>
        )}
      </div>

      {/* Tasks */}
      <div className="space-y-4">
        <h2 className="text-sm font-medium">Tasks</h2>
        <KanbanBoard projectId={id!} />
      </div>

      {/* Task Form */}
      <TaskForm
        open={showTaskForm}
        onOpenChange={setShowTaskForm}
        projectId={id!}
      />
    </div>
  );
}
