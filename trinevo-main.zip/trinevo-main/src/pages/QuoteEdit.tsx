import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  ArrowLeft, 
  Plus, 
  Trash2, 
  Settings as SettingsIcon,
  Download,
  Sparkles
} from "lucide-react";
import { useQuotes, useQuoteLines, useCustomers, useProfile } from "@/hooks/useSupabase";
import { useToast } from "@/hooks/use-toast";
import { exportQuoteToPDF } from "@/lib/pdfExport";
import { CustomerSearchSelect } from "@/components/CustomerSearchSelect";
import { CustomerForm } from "@/components/forms/CustomerForm";
import { AIQuoteGenerationModal } from "@/components/ai/AIQuoteGenerationModal";

export default function QuoteEdit() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { toast } = useToast();
  const { quotes, updateQuote, addQuote } = useQuotes();
  const { quoteLines, addQuoteLine, updateQuoteLine, deleteQuoteLine } = useQuoteLines(id);
  const { customers } = useCustomers();
  const { profile } = useProfile();
  
  const [hasChanges, setHasChanges] = useState(false);
  const [quote, setQuote] = useState<any>(null);
  const [editingLines, setEditingLines] = useState<any[]>([]);
  const [showCustomerForm, setShowCustomerForm] = useState(false);
  const [showAIModal, setShowAIModal] = useState(false);
   
  // Settings state
  const [settings, setSettings] = useState({
    showDeliveryAddress: false,
    showCompanyNumber: false,
    showTaxNumber: false,
    showAcceptanceConditions: false,
    showSignature: false,
    showDocumentTitle: false,
    showFreeField: false,
    showGlobalDiscount: false,
    documentTitle: "QUOTE",
    freeText: "",
    globalDiscount: 0,
    acceptanceConditions: "Payment terms: Net 30 days. This quote is valid for 60 days from the date of issue."
  });

  const handleSettingChange = (setting: string, value: any) => {
    setSettings(prev => ({ ...prev, [setting]: value }));
    setHasChanges(true);
  };

  const isNewQuote = id === "new";

  useEffect(() => {
    if (isNewQuote) {
      // Initialize new quote
      const newQuote = {
        quote_number: `QUO-${Date.now()}`,
        client_id: "",
        currency: "EUR",
        subtotal: 0,
        total: 0,
        status: "Saved" as const,
        notes: "",
        created_at: new Date().toISOString(),
        validity_days: 60
      };
      setQuote(newQuote);
      setEditingLines([]);
    } else if (id) {
      const foundQuote = quotes.find(q => q.id === id);
      if (foundQuote) {
        setQuote({
          ...foundQuote,
          validity_days: 60
        });
        setEditingLines(quoteLines);
      }
    }
  }, [id, quotes, quoteLines, isNewQuote]);

  useEffect(() => {
    setEditingLines(quoteLines);
  }, [quoteLines]);

  const handleQuoteChange = (field: string, value: any) => {
    setQuote(prev => ({ ...prev, [field]: value }));
    setHasChanges(true);
  };

  const handleLineChange = (index: number, field: string, value: any) => {
    const updatedLines = [...editingLines];
    updatedLines[index] = { ...updatedLines[index], [field]: value };
    
    // Recalculate line total
    if (field === 'quantity' || field === 'unit_price') {
      const quantity = parseFloat(updatedLines[index].quantity) || 0;
      const unitPrice = parseFloat(updatedLines[index].unit_price) || 0;
      updatedLines[index].total = quantity * unitPrice;
    }
    
    setEditingLines(updatedLines);
    setHasChanges(true);
  };

  const addNewLine = () => {
    const newLine = {
      id: `temp-${Date.now()}`,
      title: "",
      description: "",
      quantity: 1,
      unit_price: 0,
      total: 0,
      display_order: editingLines.length
    };
    setEditingLines([...editingLines, newLine]);
    setHasChanges(true);
  };

  const removeLine = (index: number) => {
    const updatedLines = editingLines.filter((_, i) => i !== index);
    setEditingLines(updatedLines);
    setHasChanges(true);
  };

  const calculateTotals = () => {
    const subtotal = editingLines.reduce((sum, line) => sum + (parseFloat(line.total) || 0), 0);
    const discount = settings.showGlobalDiscount ? (subtotal * settings.globalDiscount) / 100 : 0;
    const subtotalAfterDiscount = subtotal - discount;
    const tva = subtotalAfterDiscount * 0.2; // 20% TVA
    const total = subtotalAfterDiscount + tva;
    
    return { subtotal, discount, tva, total };
  };

  const { subtotal, discount, tva, total } = calculateTotals();
  const selectedCustomer = customers.find(c => c.id === quote?.client_id);

  const handleSave = async () => {
    if (!quote) return;

    try {
      let savedQuote;
      
      if (isNewQuote) {
        const { id: tempId, ...quoteData } = quote;
        savedQuote = await addQuote({
          ...quoteData,
          subtotal,
          total
        });
      } else {
        // Extract only the quote fields, excluding the customer relation
        const { customer, ...quoteFields } = quote;
        savedQuote = await updateQuote(quote.id, {
          ...quoteFields,
          subtotal,
          total
        });
      }

      // Save quote lines
      for (const line of editingLines) {
        if (line.id?.startsWith('temp-')) {
          await addQuoteLine({
            quote_id: savedQuote.id,
            title: line.title,
            description: line.description,
            quantity: line.quantity,
            unit_price: line.unit_price,
            total: line.total,
            display_order: line.display_order
          });
        } else {
          await updateQuoteLine(line.id, line);
        }
      }

      toast({
        title: "Success",
        description: isNewQuote ? "Quote created successfully" : "Quote updated successfully",
      });

      if (isNewQuote) {
        navigate(`/quotes/${savedQuote.id}`);
      } else {
        navigate(`/quotes/${savedQuote.id}`);
      }
      
      setHasChanges(false);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to save quote",
        variant: "destructive",
      });
    }
  };

  const handleExportPDF = async () => {
    if (!quote || !profile) {
      toast({
        title: "Error",
        description: "Quote or profile data not available",
        variant: "destructive",
      });
      return;
    }

    if (!editingLines || editingLines.length === 0) {
      toast({
        title: "Error",
        description: "No quote lines available for export",
        variant: "destructive",
      });
      return;
    }

    try {
      await exportQuoteToPDF(quote, profile, selectedCustomer, editingLines, settings);
      toast({
        title: "Success",
        description: "PDF exported successfully!",
      });
    } catch (error) {
      console.error("Error exporting PDF:", error);
      toast({
        title: "Error",
        description: "Failed to export PDF",
        variant: "destructive",
      });
    }
  };

  const handleAIGenerate = (lineItems: Array<{title: string, description: string, price: number}>) => {
    const newLines = lineItems.map((item, index) => ({
      id: `temp-${Date.now()}-${index}`,
      title: item.title,
      description: item.description,
      quantity: 1,
      unit_price: item.price,
      total: item.price,
      display_order: editingLines.length + index
    }));
    
    setEditingLines([...editingLines, ...newLines]);
    setHasChanges(true);
  };

  if (!quote) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <>
      <div className="min-h-screen bg-background">
        {/* Header */}
        <div className="bg-background border-b px-6 py-4 flex items-center justify-between sticky top-0 z-10">
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="icon" onClick={() => navigate(isNewQuote ? "/quotes" : `/quotes/${quote.id}`)}>
              <ArrowLeft className="h-4 w-4" />
            </Button>
            <div>
              <h1 className="text-xl font-semibold">
                {isNewQuote ? "New Quote" : `Edit Quote ${quote.quote_number}`}
              </h1>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Button variant="outline" onClick={handleExportPDF} disabled={isNewQuote}>
              <Download className="h-4 w-4 mr-2" />
              Download PDF
            </Button>
            <Button variant="outline" onClick={handleSave} disabled={!hasChanges}>
              {isNewQuote ? "Create Quote" : "Save Changes"}
            </Button>
            <Button variant="outline" size="sm">
              <SettingsIcon className="h-4 w-4 mr-2" />
              Options
            </Button>
          </div>
        </div>

        <div className="flex" style={{ paddingLeft: 0, paddingRight: 0 }}>
          {/* Main Content - Quote Preview */}
          <div className="flex-1 py-12 px-8 bg-muted/20 pr-4">
            <div className="max-w-4xl mx-auto">
              {/* Quote Document Preview */}
              <div id="quote-preview" className="bg-card shadow-sm border border-border/40 rounded-lg overflow-hidden" style={{ minHeight: '800px' }}>
                <div className="p-8 md:p-12 space-y-8">
                  {/* Header Section */}
                  <div className="grid grid-cols-2 gap-16 pb-8 border-b border-border/50">
                    {/* Company Info */}
                    <div className="space-y-4">
                      <div className="flex items-start gap-3">
                        {profile?.company_logo && (
                          <img 
                            src={profile.company_logo.startsWith('http') 
                              ? profile.company_logo 
                              : `https://dvoudscaqazfdyannodt.supabase.co/storage/v1/object/public/company-logos/${profile.company_logo}`
                            }
                            alt="Company Logo" 
                            className="h-10 w-auto object-contain"
                            onError={(e) => {
                              e.currentTarget.style.display = 'none';
                            }}
                          />
                        )}
                        <div className="space-y-1">
                          <h1 className="text-xl font-semibold" style={profile?.accent_color ? { color: profile.accent_color } : {}}>
                            {profile?.company_name || "Your Company Name"}
                          </h1>
                          <p className="text-xs text-muted-foreground font-medium uppercase tracking-wide">
                            Individual Business
                          </p>
                        </div>
                      </div>
                      
                      <div className="space-y-0.5 text-sm text-muted-foreground">
                        {profile?.street_address && (
                          <div>{profile.street_address}</div>
                        )}
                        {profile?.address_complement && (
                          <div>{profile.address_complement}</div>
                        )}
                        {(profile?.zip_code || profile?.city) && (
                          <div>{profile?.zip_code} {profile?.city}</div>
                        )}
                        {profile?.country && (
                          <div>{profile.country}</div>
                        )}
                      </div>
                    </div>

                    {/* Quote Info */}
                    <div className="space-y-6 text-right">
                      <div className="space-y-2">
                        <h2 className="text-2xl font-bold tracking-tight" style={profile?.accent_color ? { color: profile.accent_color } : {}}>
                          {settings.showDocumentTitle ? settings.documentTitle : "QUOTE"}
                        </h2>
                        <p className="text-sm font-mono text-muted-foreground">
                          #{quote.quote_number}
                        </p>
                      </div>
                      
                      <div className="space-y-1 text-xs">
                        <div className="flex justify-end items-center gap-3">
                          <span className="text-muted-foreground font-medium">Issue Date</span>
                          <input
                            type="date"
                            value={quote.created_at ? quote.created_at.split('T')[0] : ""}
                            onChange={(e) => handleQuoteChange("created_at", e.target.value + "T00:00:00Z")}
                            className="font-mono border-none outline-none bg-transparent text-right text-foreground"
                          />
                        </div>
                        <div className="flex justify-end items-center gap-3">
                          <span className="text-muted-foreground font-medium">Valid for</span>
                          <span className="font-mono text-foreground">{quote.validity_days || 60} days</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Customer Section */}
                  <div className="space-y-6">
                    <div>
                      <h3 className="text-sm font-medium mb-4 text-muted-foreground uppercase tracking-wide" style={profile?.accent_color ? { color: profile.accent_color } : {}}>
                        Bill To
                      </h3>
                      <div className="space-y-4">
                        <CustomerSearchSelect
                          customers={customers}
                          selectedCustomerId={quote.client_id}
                          onSelect={(customerId) => handleQuoteChange("client_id", customerId)}
                          onCreateNew={() => setShowCustomerForm(true)}
                          placeholder="Search and select a customer..."
                          className="max-w-sm"
                        />
                        
                         {selectedCustomer && (
                           <div className="bg-muted/20 border border-border/30 p-4 rounded-md max-w-sm">
                             <div className="font-medium text-foreground">{selectedCustomer.company_name}</div>
                             {selectedCustomer.contact_name && (
                               <div className="text-xs text-muted-foreground mt-1">
                                 {selectedCustomer.contact_name}
                               </div>
                             )}
                              {settings.showCompanyNumber && (
                                <div className="text-xs text-muted-foreground mt-1">
                                  Company Number: [To be added]
                                </div>
                              )}
                              {settings.showTaxNumber && (
                                <div className="text-xs text-muted-foreground mt-1">
                                  Tax Number: [To be added]
                                </div>
                              )}
                             {selectedCustomer.billing_address && (
                               <div className="text-xs text-muted-foreground mt-2 whitespace-pre-line leading-relaxed">
                                 {selectedCustomer.billing_address}
                               </div>
                             )}
                           </div>
                         )}

                         {/* Delivery Address Section */}
                         {settings.showDeliveryAddress && selectedCustomer && (
                           <div className="mt-6">
                             <h4 className="text-xs font-medium mb-2 text-muted-foreground uppercase tracking-wide" style={profile?.accent_color ? { color: profile.accent_color } : {}}>
                               Delivery Address
                             </h4>
                             <div className="bg-muted/20 border border-border/30 p-4 rounded-md max-w-sm">
                                <Textarea
                                  placeholder="Enter delivery address..."
                                  className="min-h-[60px] border-none bg-transparent resize-none text-xs"
                                  value=""
                                  onChange={(e) => {
                                    // This would need to update customer data in a real implementation
                                    console.log("Update delivery address:", e.target.value);
                                  }}
                                />
                             </div>
                           </div>
                         )}
                      </div>
                    </div>
                  </div>

                  {/* Line Items Section */}
                  <div className="space-y-4">
                    <div className="overflow-hidden border border-border/30 rounded-md">
                      <table className="w-full border-collapse">
                         <thead>
                           <tr className="bg-muted border-b border-border">
                             <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground uppercase tracking-wider">
                               Description
                             </th>
                             <th className="text-center px-4 py-3 text-xs font-medium text-muted-foreground uppercase tracking-wider w-20">
                               Qty
                             </th>
                             <th className="text-center px-4 py-3 text-xs font-medium text-muted-foreground uppercase tracking-wider w-28">
                               Unit Price
                             </th>
                             <th className="text-center px-4 py-3 text-xs font-medium text-muted-foreground uppercase tracking-wider w-16">
                               VAT
                             </th>
                             <th className="text-right px-4 py-3 text-xs font-medium text-muted-foreground uppercase tracking-wider w-28">
                               Total
                             </th>
                             <th className="w-12"></th>
                           </tr>
                         </thead>
                         <tbody>
                           {editingLines.map((line, index) => (
                             <tr key={line.id || index} className="border-b border-border/30 hover:bg-muted/10">
                               <td className="px-4 py-3">
                                 <div className="space-y-2">
                                   <Input
                                     placeholder="Item title"
                                     value={line.title}
                                     onChange={(e) => handleLineChange(index, 'title', e.target.value)}
                                     className="border-none p-0 h-auto text-sm font-medium bg-transparent focus-visible:ring-0"
                                   />
                                   <Textarea
                                     placeholder="Item description (optional)"
                                     value={line.description || ""}
                                     onChange={(e) => handleLineChange(index, 'description', e.target.value)}
                                     className="border-none p-0 h-auto text-xs text-muted-foreground bg-transparent resize-none min-h-[20px] focus-visible:ring-0"
                                     rows={1}
                                   />
                                 </div>
                               </td>
                               <td className="px-4 py-3 text-center">
                                 <Input
                                   type="number"
                                   value={line.quantity}
                                   onChange={(e) => handleLineChange(index, 'quantity', parseFloat(e.target.value) || 0)}
                                   className="border-none p-0 h-auto text-sm text-center bg-transparent focus-visible:ring-0 w-full"
                                   min="0"
                                   step="0.01"
                                 />
                               </td>
                               <td className="px-4 py-3 text-center">
                                 <Input
                                   type="number"
                                   value={line.unit_price}
                                   onChange={(e) => handleLineChange(index, 'unit_price', parseFloat(e.target.value) || 0)}
                                   className="border-none p-0 h-auto text-sm text-center bg-transparent focus-visible:ring-0 w-full"
                                   min="0"
                                   step="0.01"
                                 />
                               </td>
                               <td className="px-4 py-3 text-center">
                                 <span className="text-xs text-muted-foreground">20%</span>
                               </td>
                               <td className="px-4 py-3 text-right">
                                 <span className="text-sm font-medium">
                                   €{(parseFloat(line.total) || 0).toFixed(2)}
                                 </span>
                               </td>
                               <td className="px-4 py-3">
                                 <Button
                                   variant="ghost"
                                   size="icon"
                                   onClick={() => removeLine(index)}
                                   className="h-6 w-6 hover:bg-destructive/20 hover:text-destructive"
                                 >
                                   <Trash2 className="h-3 w-3" />
                                 </Button>
                               </td>
                             </tr>
                           ))}
                         </tbody>
                      </table>
                    </div>
                    
                    <div className="flex gap-2 mt-2">
                      <Button
                        onClick={addNewLine}
                        variant="outline"
                        size="sm"
                      >
                        <Plus className="h-4 w-4 mr-2" />
                        Add Line Item
                      </Button>
                      <Button
                        onClick={() => setShowAIModal(true)}
                        variant="outline"
                        size="sm"
                        className="bg-gradient-to-r from-primary/10 to-primary/5 border-primary/20 hover:from-primary/20 hover:to-primary/10"
                      >
                        <Sparkles className="h-4 w-4 mr-2" />
                        Generate with AI
                      </Button>
                    </div>
                  </div>

                  
                  <div className="space-y-6 pt-8">
                    {/* Totals Section */}
                    <div className="flex justify-end">
                      <div className="w-80 space-y-2 text-sm">
                        <div className="flex justify-between pb-2">
                          <span className="text-muted-foreground">Subtotal:</span>
                          <span className="font-medium">€{subtotal.toFixed(2)}</span>
                        </div>
                        
                        {settings.showGlobalDiscount && discount > 0 && (
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Discount ({settings.globalDiscount}%):</span>
                            <span className="font-medium text-destructive">-€{discount.toFixed(2)}</span>
                          </div>
                        )}
                        
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">TVA (20%):</span>
                          <span className="font-medium">€{tva.toFixed(2)}</span>
                        </div>
                        
                        <div className="flex justify-between pt-2 border-t border-border text-base font-semibold" style={profile?.accent_color ? { color: profile.accent_color } : {}}>
                          <span>Total:</span>
                          <span>€{total.toFixed(2)}</span>
                        </div>
                      </div>
                    </div>

                    {/* Notes Section */}
                    <div className="space-y-3">
                      <Label htmlFor="notes" className="text-sm font-medium text-muted-foreground uppercase tracking-wide" style={profile?.accent_color ? { color: profile.accent_color } : {}}>
                        Notes
                      </Label>
                      <Textarea
                        id="notes"
                        placeholder="Additional notes or terms..."
                        value={quote.notes || ""}
                        onChange={(e) => handleQuoteChange("notes", e.target.value)}
                        className="min-h-[100px] border border-border/30 rounded-md text-sm"
                        rows={4}
                      />
                    </div>

                    {/* Acceptance Conditions */}
                    {settings.showAcceptanceConditions && (
                      <div className="space-y-3">
                        <Label className="text-sm font-medium text-muted-foreground uppercase tracking-wide" style={profile?.accent_color ? { color: profile.accent_color } : {}}>
                          Terms & Conditions
                        </Label>
                        <div className="text-xs text-muted-foreground leading-relaxed border border-border/30 rounded-md p-4 bg-muted/10">
                          {settings.acceptanceConditions}
                        </div>
                      </div>
                    )}

                    {/* Signature Section */}
                    {settings.showSignature && (
                      <div className="pt-12">
                        <div className="grid grid-cols-2 gap-16">
                          <div className="space-y-3">
                            <div className="border-b border-border/50 pb-1">
                              <span className="text-xs text-muted-foreground">Client Signature</span>
                            </div>
                            <div className="text-xs text-muted-foreground">
                              Date: ___________________
                            </div>
                          </div>
                          <div className="space-y-3">
                            <div className="border-b border-border/50 pb-1">
                              <span className="text-xs text-muted-foreground">Company Representative</span>
                            </div>
                            <div className="text-xs text-muted-foreground">
                              Date: ___________________
                            </div>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* Free Field */}
                    {settings.showFreeField && (
                      <div className="space-y-3">
                        <Label className="text-sm font-medium text-muted-foreground uppercase tracking-wide" style={profile?.accent_color ? { color: profile.accent_color } : {}}>
                          Additional Information
                        </Label>
                        <div className="text-sm leading-relaxed border border-border/30 rounded-md p-4 bg-muted/10">
                          {settings.freeText || "Enter additional information..."}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Sidebar - Settings Panel */}
          <div className="w-80 bg-background border-l border-border p-6 overflow-y-auto">
            <h3 className="font-medium mb-6">Quote Settings</h3>
            
            <div className="space-y-6">
              {/* Display Options */}
              <div className="space-y-4">
                <h4 className="text-sm font-medium text-muted-foreground">Display Options</h4>
                
                <div className="space-y-3">
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="showDeliveryAddress"
                      checked={settings.showDeliveryAddress}
                      onCheckedChange={(checked) => handleSettingChange('showDeliveryAddress', checked)}
                    />
                    <Label htmlFor="showDeliveryAddress" className="text-sm">Show delivery address</Label>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="showCompanyNumber"
                      checked={settings.showCompanyNumber}
                      onCheckedChange={(checked) => handleSettingChange('showCompanyNumber', checked)}
                    />
                    <Label htmlFor="showCompanyNumber" className="text-sm">Show company number</Label>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="showTaxNumber"
                      checked={settings.showTaxNumber}
                      onCheckedChange={(checked) => handleSettingChange('showTaxNumber', checked)}
                    />
                    <Label htmlFor="showTaxNumber" className="text-sm">Show tax number</Label>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="showDocumentTitle"
                      checked={settings.showDocumentTitle}
                      onCheckedChange={(checked) => handleSettingChange('showDocumentTitle', checked)}
                    />
                    <Label htmlFor="showDocumentTitle" className="text-sm">Custom document title</Label>
                  </div>
                  
                  {settings.showDocumentTitle && (
                    <Input
                      value={settings.documentTitle}
                      onChange={(e) => handleSettingChange('documentTitle', e.target.value)}
                      className="ml-6 h-8"
                      placeholder="Document title"
                    />
                  )}
                </div>
              </div>

              {/* Document Options */}
              <div className="space-y-4">
                <h4 className="text-sm font-medium text-muted-foreground">Document Options</h4>
                
                <div className="space-y-3">
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="showAcceptanceConditions"
                      checked={settings.showAcceptanceConditions}
                      onCheckedChange={(checked) => handleSettingChange('showAcceptanceConditions', checked)}
                    />
                    <Label htmlFor="showAcceptanceConditions" className="text-sm">Show terms & conditions</Label>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="showSignature"
                      checked={settings.showSignature}
                      onCheckedChange={(checked) => handleSettingChange('showSignature', checked)}
                    />
                    <Label htmlFor="showSignature" className="text-sm">Show signature fields</Label>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="showFreeField"
                      checked={settings.showFreeField}
                      onCheckedChange={(checked) => handleSettingChange('showFreeField', checked)}
                    />
                    <Label htmlFor="showFreeField" className="text-sm">Show free text field</Label>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="showGlobalDiscount"
                      checked={settings.showGlobalDiscount}
                      onCheckedChange={(checked) => handleSettingChange('showGlobalDiscount', checked)}
                    />
                    <Label htmlFor="showGlobalDiscount" className="text-sm">Apply global discount</Label>
                  </div>
                  
                  {settings.showGlobalDiscount && (
                    <div className="ml-6 space-y-2">
                      <Label htmlFor="globalDiscount" className="text-xs">Discount %</Label>
                      <Input
                        id="globalDiscount"
                        type="number"
                        value={settings.globalDiscount}
                        onChange={(e) => handleSettingChange('globalDiscount', parseFloat(e.target.value) || 0)}
                        className="h-8"
                        min="0"
                        max="100"
                      />
                    </div>
                  )}
                </div>
              </div>

              {/* Custom Text Fields */}
              <div className="space-y-4">
                <h4 className="text-sm font-medium text-muted-foreground">Custom Text</h4>
                
                <div className="space-y-3">
                  <div>
                    <Label htmlFor="acceptanceConditions" className="text-xs">Terms & Conditions</Label>
                    <Textarea
                      id="acceptanceConditions"
                      value={settings.acceptanceConditions}
                      onChange={(e) => handleSettingChange('acceptanceConditions', e.target.value)}
                      className="mt-1 h-20 text-xs"
                      placeholder="Enter terms and conditions..."
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="freeText" className="text-xs">Free Text</Label>
                    <Textarea
                      id="freeText"
                      value={settings.freeText}
                      onChange={(e) => handleSettingChange('freeText', e.target.value)}
                      className="mt-1 h-20 text-xs"
                      placeholder="Enter additional information..."
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Customer Form Modal */}
      {showCustomerForm && (
        <CustomerForm
          open={showCustomerForm}
          onOpenChange={setShowCustomerForm}
        />
      )}

      {/* AI Quote Generation Modal */}
      <AIQuoteGenerationModal
        open={showAIModal}
        onOpenChange={setShowAIModal}
        onGenerate={handleAIGenerate}
      />
    </>
  );
}
