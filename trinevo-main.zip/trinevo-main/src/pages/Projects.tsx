import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { StatusBadge } from "@/components/StatusBadge";
import { Progress } from "@/components/ui/progress";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Plus, Search, MoreHorizontal, PlayCircle, Clock, CheckCircle, Target, FolderKanban, Eye, Edit, Copy, Archive } from "lucide-react";
import { SearchIcon } from "@/components/LottieIcon";
import { useProjects } from "@/hooks/useSupabase";
import { ProjectForm } from "@/components/forms/ProjectForm";
import { useNavigate } from "react-router-dom";
type SortOption = "name_asc" | "name_desc" | "due_asc" | "due_desc" | "progress_asc" | "progress_desc" | "created_asc" | "created_desc" | "customer_asc" | "customer_desc";
type FilterOptions = {
  status: string[];
  customers: string[];
  overdue: boolean;
};
export function Projects() {
  const [searchTerm, setSearchTerm] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [sortBy, setSortBy] = useState<SortOption>("created_desc");
  const [filters, setFilters] = useState<FilterOptions>({
    status: [],
    customers: [],
    overdue: false
  });
  const {
    projects,
    loading,
    updateProject
  } = useProjects();
  const navigate = useNavigate();
  const getStatusIcon = (status: string) => {
    switch (status) {
      case "completed":
        return CheckCircle;
      case "in_progress":
        return PlayCircle;
      case "not_started":
        return Target;
      case "cancelled":
        return Clock;
      default:
        return FolderKanban;
    }
  };

  // Check if project is overdue
  const isOverdue = (project: any) => {
    if (!project.due_date || project.status === 'completed') return false;
    return new Date(project.due_date) < new Date();
  };

  // Filter and sort logic
  const getFilteredAndSortedProjects = () => {
    let filtered = projects.filter(project => {
      // Search filter
      const searchLower = searchTerm.toLowerCase();
      const projectName = (project.project_name || '').toLowerCase();
      const customerName = (project.customer?.company_name || '').toLowerCase();
      const description = (project.description || '').toLowerCase();
      const matchesSearch = projectName.includes(searchLower) || customerName.includes(searchLower) || description.includes(searchLower);
      if (!matchesSearch) return false;

      // Status filter
      if (filters.status.length > 0 && !filters.status.includes(project.status)) {
        return false;
      }

      // Customer filter
      if (filters.customers.length > 0 && !filters.customers.includes(project.customer_id)) {
        return false;
      }

      // Overdue filter
      if (filters.overdue && !isOverdue(project)) {
        return false;
      }
      return true;
    });

    // Sort
    filtered.sort((a, b) => {
      switch (sortBy) {
        case "name_asc":
          return (a.project_name || '').localeCompare(b.project_name || '');
        case "name_desc":
          return (b.project_name || '').localeCompare(a.project_name || '');
        case "due_asc":
          if (!a.due_date && !b.due_date) return 0;
          if (!a.due_date) return 1;
          if (!b.due_date) return -1;
          return new Date(a.due_date).getTime() - new Date(b.due_date).getTime();
        case "due_desc":
          if (!a.due_date && !b.due_date) return 0;
          if (!a.due_date) return 1;
          if (!b.due_date) return -1;
          return new Date(b.due_date).getTime() - new Date(a.due_date).getTime();
        case "progress_asc":
          return (a.progress || 0) - (b.progress || 0);
        case "progress_desc":
          return (b.progress || 0) - (a.progress || 0);
        case "created_asc":
          return new Date(a.created_at).getTime() - new Date(b.created_at).getTime();
        case "created_desc":
          return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
        case "customer_asc":
          return (a.customer?.company_name || '').localeCompare(b.customer?.company_name || '');
        case "customer_desc":
          return (b.customer?.company_name || '').localeCompare(a.customer?.company_name || '');
        default:
          return 0;
      }
    });
    return filtered;
  };
  const filteredProjects = getFilteredAndSortedProjects();

  // Stats
  const totalProjects = projects.length;
  const activeProjects = projects.filter(p => p.status === "in_progress" || p.status === "not_started").length;
  const completedProjects = projects.filter(p => p.status === "completed").length;
  const overdueProjects = projects.filter(p => isOverdue(p)).length;

  // Clear filters function (not needed anymore but kept for future use)
  const clearFilters = () => {
    setFilters({
      status: [],
      customers: [],
      overdue: false
    });
    setSortBy("created_desc");
  };

  // Get unique customers for filter
  const uniqueCustomers = Array.from(new Map(projects.map(p => [p.customer_id, p.customer])).values()).filter(Boolean);
  if (loading) {
    return <div className="p-6">Loading projects...</div>;
  }
  return <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl md:text-2xl lg:text-3xl">Projects</h1>
        </div>
        <Button variant="dark" onClick={() => setShowForm(true)}>
          <Plus className="h-4 w-4 mr-2" />
          New Project
        </Button>
      </div>

      {/* Stats Cards */}
      

      {/* Search and Filters */}
      <Card className="shadow-none">
        <CardContent>
          <div className="flex items-center space-x-4">
            <div className="relative flex-1 group">
              <div className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4">
                <SearchIcon delay={150} onHover={true} />
              </div>
              <Input placeholder="Search projects..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)} className="w-full h-8 rounded-xl px-3 pl-10 text-sm bg-gray-100 border border-gray-300 placeholder:text-gray-500 text-gray-900 focus-visible:ring-2 focus-visible:ring-gray-200 transition duration-200 ease-in-out outline-none disabled:opacity-70 disabled:cursor-not-allowed" />
            </div>
            
            {/* Sort Select */}
            <Select value={sortBy} onValueChange={(value: SortOption) => setSortBy(value)}>
              <SelectTrigger className="w-[200px]">
                <SelectValue placeholder="Sort by..." />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="created_desc">Newest first</SelectItem>
                <SelectItem value="created_asc">Oldest first</SelectItem>
                <SelectItem value="name_asc">Name A-Z</SelectItem>
                <SelectItem value="name_desc">Name Z-A</SelectItem>
                <SelectItem value="due_asc">Due date (nearest)</SelectItem>
                <SelectItem value="due_desc">Due date (furthest)</SelectItem>
                <SelectItem value="progress_desc">Progress (highest)</SelectItem>
                <SelectItem value="progress_asc">Progress (lowest)</SelectItem>
                <SelectItem value="customer_asc">Customer A-Z</SelectItem>
                <SelectItem value="customer_desc">Customer Z-A</SelectItem>
              </SelectContent>
            </Select>
            
            {/* Filters */}
            <div className="flex gap-2">
              <Select value={filters.status.length === 1 ? filters.status[0] : "all"} onValueChange={value => {
              if (value === "all") {
                setFilters(prev => ({
                  ...prev,
                  status: []
                }));
              } else {
                setFilters(prev => ({
                  ...prev,
                  status: [value]
                }));
              }
            }}>
                <SelectTrigger className="w-[140px]">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="not_started">Not Started</SelectItem>
                  <SelectItem value="in_progress">In Progress</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                  <SelectItem value="cancelled">Cancelled</SelectItem>
                </SelectContent>
              </Select>

              {uniqueCustomers.length > 0 && <Select value={filters.customers.length === 1 ? filters.customers[0] : "all"} onValueChange={value => {
              if (value === "all") {
                setFilters(prev => ({
                  ...prev,
                  customers: []
                }));
              } else {
                setFilters(prev => ({
                  ...prev,
                  customers: [value]
                }));
              }
            }}>
                  <SelectTrigger className="w-[160px]">
                    <SelectValue placeholder="Customer" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Customers</SelectItem>
                    {uniqueCustomers.map(customer => <SelectItem key={customer.id} value={customer.id}>
                        {customer.company_name}
                      </SelectItem>)}
                  </SelectContent>
                </Select>}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Projects Table */}
      <Card className="shadow-none">
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <div className="min-w-[800px]">
              {/* Custom header that matches input styling */}
              <div className="flex h-8 w-full rounded-xl px-4 py-2 text-sm bg-gray-100 border border-gray-300 text-gray-500 mb-0 items-center">
                <div className="w-80 font-medium text-left">Project</div>
                <div className="w-48 font-medium text-left">Customer</div>
                <div className="w-40 font-medium text-left">Progress</div>
                <div className="w-32 font-medium text-left">Due Date</div>
                <div className="w-32 font-medium text-left">Status</div>
                <div className="w-24 font-medium text-right">Actions</div>
              </div>
              <Table>
              <TableBody>
              {filteredProjects.length === 0 ? <TableRow>
                  <TableCell colSpan={6} className="h-24 text-center text-muted-foreground">
                    {searchTerm || filters.status.length > 0 || filters.customers.length > 0 ? "No projects match your search criteria" : "No projects yet. Create your first project!"}
                  </TableCell>
                </TableRow> : filteredProjects.map(project => {
                const StatusIcon = getStatusIcon(project.status);
                const projectIsOverdue = isOverdue(project);
                return (
                    <TableRow key={project.id} className="cursor-pointer hover:bg-muted/50 border-border/40" style={{ backgroundColor: '#fbfbfb' }} onClick={() => navigate(`/projects/${project.id}`)}>
                      <TableCell className="w-80 text-left">
                        <div className="flex items-center space-x-3">
                          <div className="w-3 h-3 rounded-full flex-shrink-0" style={{
                        backgroundColor: project.color_tag || '#3b82f6'
                      }} />
                          <div className="flex-1 min-w-0">
                            <div className="font-medium truncate">{project.project_name}</div>
                            {project.description && <div className="text-sm text-muted-foreground truncate">
                                {project.description}
                              </div>}
                          </div>
                        </div>
                      </TableCell>
                      <TableCell className="w-48 text-left">
                        <div className="font-medium truncate">
                          {project.customer?.company_name || 'No customer'}
                        </div>
                      </TableCell>
                      <TableCell className="w-40 text-left">
                        <div className="space-y-1">
                          <div className="flex justify-between text-sm">
                            <span>{project.progress || 0}%</span>
                          </div>
                          <Progress value={project.progress || 0} className="h-2 [&>div]:bg-black" />
                        </div>
                      </TableCell>
                      <TableCell className="w-32 text-left">
                        {project.due_date ? <div className={`text-sm ${projectIsOverdue ? 'text-destructive font-medium' : ''}`}>
                            {new Date(project.due_date).toLocaleDateString()}
                            {projectIsOverdue && <div className="text-xs text-destructive">Overdue</div>}
                          </div> : <span className="text-muted-foreground text-sm">No due date</span>}
                      </TableCell>
                      <TableCell className="w-32 text-left" onClick={(e) => e.stopPropagation()}>
                        <StatusBadge
                          status={project.status}
                          options={["not_started", "in_progress", "completed", "cancelled"]}
                          onChange={async (newStatus) => {
                            await updateProject(project.id, { status: newStatus as any });
                          }}
                          model="project"
                          id={project.id}
                        />
                      </TableCell>
                      <TableCell className="w-24 text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild onClick={e => e.stopPropagation()}>
                            <Button variant="ghost" size="icon">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={e => {
                          e.stopPropagation();
                          navigate(`/projects/${project.id}`);
                        }}>
                              <Eye className="h-4 w-4 mr-2" />
                              View Details
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={e => {
                          e.stopPropagation();
                          // TODO: Navigate to kanban view
                        }}>
                              <FolderKanban className="h-4 w-4 mr-2" />
                              View Kanban
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={e => {
                          e.stopPropagation();
                          // TODO: Edit project
                        }}>
                              <Edit className="h-4 w-4 mr-2" />
                              Edit Project
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={e => {
                          e.stopPropagation();
                          // TODO: Duplicate project
                        }}>
                              <Copy className="h-4 w-4 mr-2" />
                              Duplicate
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={e => {
                          e.stopPropagation();
                          // TODO: Archive project
                        }}>
                              <Archive className="h-4 w-4 mr-2" />
                              Archive
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                );
              })}
              </TableBody>
              </Table>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Project Form */}
      <ProjectForm open={showForm} onOpenChange={setShowForm} />
    </div>;
}
