import { useState, useEffect } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  ArrowLeft, 
  Download,
  Edit,
  FileText,
  Plus,
  Euro,
  FolderPlus,
  ExternalLink
} from "lucide-react";
import { useQuotes, useQuoteLines, useCustomers, useProfile, useProjects } from "@/hooks/useSupabase";
import { useInvoices } from "@/hooks/useInvoices";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { exportQuoteToPDF } from "@/lib/pdfExport";
import { StatusBadge } from "@/components/StatusBadge";

export default function QuotePreview() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { toast } = useToast();
  const { quotes, updateQuote } = useQuotes();
  const { quoteLines } = useQuoteLines(id);
  const { customers } = useCustomers();
  const { profile } = useProfile();
  const { addInvoice } = useInvoices();
  const { addProject } = useProjects();
  
  const [quote, setQuote] = useState<any>(null);
  const [relatedInvoices, setRelatedInvoices] = useState<any[]>([]);
  const [relatedProjects, setRelatedProjects] = useState<any[]>([]);
  const [showDepositModal, setShowDepositModal] = useState(false);
  const [depositPercentage, setDepositPercentage] = useState(30);

  useEffect(() => {
    if (id) {
      const foundQuote = quotes.find(q => q.id === id);
      if (foundQuote) {
        setQuote(foundQuote);
        // Fetch related invoices and projects
        fetchRelatedInvoices(id);
        fetchRelatedProjects(id);
      }
    }
  }, [id, quotes]);

  const fetchRelatedInvoices = async (quoteId: string) => {
    // This would fetch invoices linked to this quote
    // For now, mock empty array
    setRelatedInvoices([]);
  };

  const fetchRelatedProjects = async (quoteId: string) => {
    try {
      const { data, error } = await supabase
        .from('projects')
        .select(`
          *,
          customer:customers(*)
        `)
        .eq('quote_id', quoteId);

      if (error) {
        console.error("Error fetching related projects:", error);
        return;
      }

      setRelatedProjects(data || []);
    } catch (error) {
      console.error("Error fetching related projects:", error);
    }
  };

  const selectedCustomer = customers.find(c => c.id === quote?.client_id);

  const handleStatusUpdate = async (newStatus: string) => {
    if (!quote) return;
    await updateQuote(quote.id, { status: newStatus as any });
  };

  const handleExportPDF = async () => {
    if (!quote || !profile) {
      toast({
        title: "Error",
        description: "Quote or profile data not available",
        variant: "destructive",
      });
      return;
    }

    try {
      const defaultOptionsConfig = {
        showDeliveryAddress: false,
        showCompanyNumber: false,
        showTaxNumber: false,
        showAcceptanceConditions: true,
        showSignatureField: false,
        showFreeField: false,
        documentTitle: 'Quotation',
        globalDiscount: 0,
        acceptanceConditionsText: 'This quote is valid for 30 days from the date of issue. Payment terms: 30 days net.',
        freeFieldContent: ''
      };

      await exportQuoteToPDF(
        quote,
        quoteLines || [],
        selectedCustomer,
        profile,
        defaultOptionsConfig,
        {
          filename: `Quote_${quote.quote_number}.pdf`
        }
      );
      
      toast({
        title: "Success",
        description: "PDF exported successfully!",
      });
    } catch (error) {
      console.error("Error exporting PDF:", error);
      toast({
        title: "Error",
        description: "Failed to export PDF",
        variant: "destructive",
      });
    }
  };

  const handleCreateInvoice = async () => {
    if (!quote || !selectedCustomer) {
      toast({
        title: "Error",
        description: "Quote or customer data not available",
        variant: "destructive",
      });
      return;
    }

    try {
      // Check for existing deposit invoices for this quote
      const { data: depositInvoices, error } = await supabase
        .from('invoices')
        .select('*')
        .eq('quote_id', quote.id)
        .eq('type', 'deposit');

      if (error) {
        console.error("Error fetching deposit invoices:", error);
      }

      const totalDepositAmount = depositInvoices?.reduce((sum, inv) => sum + Number(inv.total), 0) || 0;
      const finalAmount = Math.max(0, quote.total - totalDepositAmount);

      let invoiceNotes = quote.notes || "";
      if (totalDepositAmount > 0) {
        const depositNote = `\n\nDeposit invoices paid: ${depositInvoices?.map(inv => inv.invoice_number).join(', ')} (Total: ${quote.currency} ${totalDepositAmount.toFixed(2)})`;
        invoiceNotes += depositNote;
      }

      const newInvoice = {
        invoice_number: `INV-${Date.now()}`,
        client_id: quote.client_id,
        quote_id: quote.id,
        currency: quote.currency,
        subtotal: finalAmount,
        total: finalAmount,
        status: "draft" as const,
        type: "final" as const,
        issue_date: new Date().toISOString().split('T')[0],
        notes: invoiceNotes
      };

      const savedInvoice = await addInvoice(newInvoice);
      
      if (savedInvoice) {
        toast({
          title: "Success",
          description: totalDepositAmount > 0 
            ? `Final invoice created (${quote.currency} ${finalAmount.toFixed(2)} after ${quote.currency} ${totalDepositAmount.toFixed(2)} deposit deduction)`
            : "Invoice created successfully from quote",
        });
        navigate(`/invoices/${savedInvoice.id}`);
      }
    } catch (error) {
      console.error("Error creating invoice:", error);
      toast({
        title: "Error",
        description: "Failed to create invoice",
        variant: "destructive",
      });
    }
  };

  const handleCreateDepositInvoice = async () => {
    if (!quote || !selectedCustomer) return;

    try {
      const depositAmount = (quote.total * depositPercentage) / 100;
      
      const newInvoice = {
        invoice_number: `INV-DEP-${Date.now()}`,
        client_id: quote.client_id,
        quote_id: quote.id,
        currency: quote.currency,
        subtotal: depositAmount,
        total: depositAmount,
        status: "draft" as const,
        type: "deposit" as const,
        issue_date: new Date().toISOString().split('T')[0],
        notes: `Deposit invoice (${depositPercentage}%) for quote ${quote.quote_number}`
      };

      const savedInvoice = await addInvoice(newInvoice);
      
      if (savedInvoice) {
        toast({
          title: "Success",
          description: "Deposit invoice created successfully",
        });
        setShowDepositModal(false);
        navigate(`/invoices/${savedInvoice.id}`);
      }
    } catch (error) {
      console.error("Error creating deposit invoice:", error);
      toast({
        title: "Error",
        description: "Failed to create deposit invoice",
        variant: "destructive",
      });
    }
  };

  const handleCreateProject = async () => {
    if (!quote || !selectedCustomer) {
      toast({
        title: "Error",
        description: "Quote or customer data not available",
        variant: "destructive",
      });
      return;
    }

    try {
      // Create a meaningful project name from the quote
      const projectName = `Project for Quote ${quote.quote_number}`;
      
      // Create project data based on quote information
      const newProject = {
        project_name: projectName,
        description: quote.notes || `Project created from quote ${quote.quote_number}`,
        customer_id: quote.client_id,
        quote_id: quote.id, // Link to the original quote
        status: "not_started" as const,
        progress: 0,
        color_tag: "#3b82f6" // Default blue color
      };

      const savedProject = await addProject(newProject);
      
      if (savedProject) {
        toast({
          title: "Success",
          description: "Project created successfully from quote",
        });
        navigate(`/projects/${savedProject.id}`);
      }
    } catch (error) {
      console.error("Error creating project:", error);
      toast({
        title: "Error",
        description: "Failed to create project",
        variant: "destructive",
      });
    }
  };

  if (!quote) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-background border-b px-6 py-4 flex items-center justify-between sticky top-0 z-10">
        <div className="flex items-center space-x-4">
          <Button variant="ghost" size="icon" onClick={() => navigate("/quotes")}>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div>
            <h1 className="text-xl font-semibold">
              Quote {quote.quote_number}
            </h1>
            <p className="text-sm text-muted-foreground">
              {selectedCustomer?.company_name || "Unknown Customer"}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <Button variant="outline" onClick={handleExportPDF}>
            <Download className="h-4 w-4 mr-2" />
            Download PDF
          </Button>
          <Link to={`/quotes/${quote.id}/edit`}>
            <Button variant="outline">
              <Edit className="h-4 w-4 mr-2" />
              Edit Quote
            </Button>
          </Link>
        </div>
      </div>

      <div className="flex">
        {/* Main Content - Quote Preview */}
        <div className="flex-1 py-12 px-8 bg-muted/20">
          <div className="max-w-4xl mx-auto">
            {/* Quote Document Preview */}
            <div className="bg-card shadow-sm border border-border/40 rounded-lg overflow-hidden" style={{ minHeight: '800px' }}>
              <div className="p-8 md:p-12 space-y-8">
                {/* Header Section */}
                <div className="grid grid-cols-2 gap-16 pb-8 border-b border-border/50">
                  {/* Company Info */}
                  <div className="space-y-4">
                    <div className="flex items-start gap-3">
                      {profile?.company_logo && (
                        <img 
                          src={profile.company_logo.startsWith('http') 
                            ? profile.company_logo 
                            : `https://dvoudscaqazfdyannodt.supabase.co/storage/v1/object/public/company-logos/${profile.company_logo}`
                          }
                          alt="Company Logo" 
                          className="h-10 w-auto object-contain"
                          onError={(e) => {
                            e.currentTarget.style.display = 'none';
                          }}
                        />
                      )}
                      <div className="space-y-1">
                        <h1 className="text-xl font-semibold" style={profile?.accent_color ? { color: profile.accent_color } : {}}>
                          {profile?.company_name || "Your Company Name"}
                        </h1>
                        <p className="text-xs text-muted-foreground font-medium uppercase tracking-wide">
                          Individual Business
                        </p>
                      </div>
                    </div>
                    
                    <div className="space-y-0.5 text-sm text-muted-foreground">
                      {profile?.street_address && (
                        <div>{profile.street_address}</div>
                      )}
                      {profile?.address_complement && (
                        <div>{profile.address_complement}</div>
                      )}
                      {(profile?.zip_code || profile?.city) && (
                        <div>{profile?.zip_code} {profile?.city}</div>
                      )}
                      {profile?.country && (
                        <div>{profile.country}</div>
                      )}
                    </div>
                  </div>

                  {/* Quote Info */}
                  <div className="space-y-6 text-right">
                    <div className="space-y-2">
                      <h2 className="text-2xl font-bold tracking-tight" style={profile?.accent_color ? { color: profile.accent_color } : {}}>
                        QUOTE
                      </h2>
                      <p className="text-sm font-mono text-muted-foreground">
                        #{quote.quote_number}
                      </p>
                    </div>
                    
                    <div className="space-y-1 text-xs">
                      <div className="flex justify-end items-center gap-3">
                        <span className="text-muted-foreground font-medium">Issue Date</span>
                        <span className="font-mono text-foreground">
                          {new Date(quote.created_at).toLocaleDateString()}
                        </span>
                      </div>
                      <div className="flex justify-end items-center gap-3">
                        <span className="text-muted-foreground font-medium">Valid for</span>
                        <span className="font-mono text-foreground">60 days</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Customer Section */}
                <div className="space-y-6">
                  <div>
                    <h3 className="text-sm font-medium mb-4 text-muted-foreground uppercase tracking-wide" style={profile?.accent_color ? { color: profile.accent_color } : {}}>
                      Bill To
                    </h3>
                    {selectedCustomer && (
                      <div className="bg-muted/20 border border-border/30 p-4 rounded-md max-w-sm">
                        <div className="font-semibold text-foreground text-base">
                          {selectedCustomer.company_name}
                        </div>
                        {selectedCustomer.contact_name && (
                          <div className="text-sm text-muted-foreground mt-1">
                            {selectedCustomer.contact_name}
                          </div>
                        )}
                        {selectedCustomer.billing_address && (
                          <div className="text-sm text-muted-foreground mt-3 whitespace-pre-line leading-relaxed">
                            {selectedCustomer.billing_address}
                          </div>
                        )}
                        {selectedCustomer.email && (
                          <div className="text-sm text-muted-foreground mt-1">
                            {selectedCustomer.email}
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </div>

                {/* Line Items Section */}
                <div className="space-y-4">
                  <div className="overflow-hidden border border-border/30 rounded-lg shadow-sm">
                    <table className="w-full border-collapse bg-card">
                      <thead>
                        <tr className="bg-muted/50 border-b border-border">
                          <th className="text-left px-6 py-4 text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                            Description
                          </th>
                          <th className="text-center px-6 py-4 text-xs font-semibold text-muted-foreground uppercase tracking-wider w-24">
                            Qty
                          </th>
                          <th className="text-center px-6 py-4 text-xs font-semibold text-muted-foreground uppercase tracking-wider w-32">
                            Unit Price
                          </th>
                          <th className="text-center px-6 py-4 text-xs font-semibold text-muted-foreground uppercase tracking-wider w-32">
                            Total
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        {(quoteLines || []).map((line: any, index: number) => (
                          <tr key={line.id} className="border-b border-border/20 last:border-b-0 hover:bg-muted/20 transition-colors">
                            <td className="px-6 py-4">
                              <div className="font-semibold text-sm text-foreground">{line.title}</div>
                              {line.description && (
                                <div className="text-xs text-muted-foreground mt-1 leading-relaxed">
                                  {line.description}
                                </div>
                              )}
                            </td>
                            <td className="px-6 py-4 text-center text-sm font-mono text-foreground">
                              {line.quantity}
                            </td>
                            <td className="px-6 py-4 text-center text-sm font-mono text-foreground">
                              €{parseFloat(line.unit_price || 0).toFixed(2)}
                            </td>
                            <td className="px-6 py-4 text-center text-sm font-mono font-semibold text-foreground">
                              €{parseFloat(line.total || 0).toFixed(2)}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>

                  {/* Totals Section */}
                  <div className="flex justify-end">
                    <div className="w-80 space-y-2 text-sm">
                      <div className="flex justify-between py-2 border-b border-border/30">
                        <span className="font-medium">Subtotal</span>
                        <span className="font-mono">€{quote.subtotal.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between py-2">
                        <span className="text-lg font-semibold">Total</span>
                        <span className="text-lg font-bold font-mono" style={profile?.accent_color ? { color: profile.accent_color } : {}}>
                          €{quote.total.toFixed(2)}
                        </span>
                      </div>
                    </div>
                  </div>

                  {quote.notes && (
                    <div className="mt-8 pt-6 border-t border-border/30">
                      <h4 className="text-sm font-medium mb-2 text-muted-foreground uppercase tracking-wide">
                        Notes
                      </h4>
                      <p className="text-sm text-muted-foreground leading-relaxed">
                        {quote.notes}
                      </p>
                    </div>
                  )}

                  <div className="mt-8 pt-6 border-t border-border/30">
                    <p className="text-xs text-muted-foreground leading-relaxed">
                      This quote is valid for 30 days from the date of issue. Payment terms: 30 days net.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Sidebar */}
        <div className="w-80 bg-background border-l p-6 space-y-6">
          {/* Status Badge */}
          <Card>
            <CardHeader>
              <CardTitle>Status</CardTitle>
            </CardHeader>
            <CardContent>
              <StatusBadge
                status={quote.status}
                options={["Saved", "Sent", "Accepted", "Declined"]}
                onChange={handleStatusUpdate}
                model="quote"
                id={quote.id}
              />
            </CardContent>
          </Card>

          {/* Customer Info */}
          <Card>
            <CardHeader>
              <CardTitle>Customer</CardTitle>
            </CardHeader>
            <CardContent>
              {selectedCustomer ? (
                <div className="space-y-2">
                  <p className="font-medium">{selectedCustomer.company_name}</p>
                  {selectedCustomer.contact_name && (
                    <p className="text-sm text-muted-foreground">{selectedCustomer.contact_name}</p>
                  )}
                  {selectedCustomer.email && (
                    <p className="text-sm text-muted-foreground">{selectedCustomer.email}</p>
                  )}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground">No customer selected</p>
              )}
            </CardContent>
          </Card>

          {/* Actions */}
          <Card>
            <CardHeader>
              <CardTitle>Actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {quote.status === "Accepted" ? (
                <>
                  <Button onClick={handleCreateInvoice} className="w-full">
                    <FileText className="h-4 w-4 mr-2" />
                    Create Invoice
                  </Button>
                  <Button 
                    onClick={() => setShowDepositModal(true)} 
                    variant="outline" 
                    className="w-full"
                  >
                    <Euro className="h-4 w-4 mr-2" />
                    Create Deposit Invoice
                  </Button>
                  <Button 
                    onClick={handleCreateProject} 
                    variant="outline" 
                    className="w-full"
                  >
                    <FolderPlus className="h-4 w-4 mr-2" />
                    Create Project
                  </Button>
                </>
              ) : (
                <div className="space-y-2">
                  <p className="text-sm text-muted-foreground">
                    Quote must be accepted to create invoices
                  </p>
                  <Button 
                    onClick={() => handleStatusUpdate("Accepted")} 
                    variant="outline" 
                    className="w-full"
                  >
                    Mark as Accepted
                  </Button>
                  <Button 
                    onClick={handleCreateProject} 
                    variant="outline" 
                    className="w-full"
                  >
                    <FolderPlus className="h-4 w-4 mr-2" />
                    Create Project
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Related Invoices */}
          <Card>
            <CardHeader>
              <CardTitle>Related Invoices</CardTitle>
            </CardHeader>
            <CardContent>
              {relatedInvoices.length > 0 ? (
                <div className="space-y-2">
                  {relatedInvoices.map((invoice) => (
                    <div key={invoice.id} className="flex items-center justify-between p-2 bg-muted/20 rounded">
                      <span className="text-sm">{invoice.invoice_number}</span>
                      <Badge variant="outline">{invoice.status}</Badge>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground">No related invoices</p>
              )}
            </CardContent>
          </Card>

          {/* Related Projects */}
          <Card>
            <CardHeader>
              <CardTitle>Related Projects</CardTitle>
            </CardHeader>
            <CardContent>
              {relatedProjects.length > 0 ? (
                <div className="space-y-2">
                  {relatedProjects.map((project) => (
                    <div key={project.id} className="flex items-center justify-between p-2 bg-muted/20 rounded">
                      <div className="flex-1">
                        <span className="text-sm font-medium">{project.project_name}</span>
                        <div className="text-xs text-muted-foreground">{project.progress}% complete</div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">{project.status.replace('_', ' ')}</Badge>
                        <Button 
                          variant="ghost" 
                          size="sm"
                          onClick={() => navigate(`/projects/${project.id}`)}
                          className="h-auto p-1"
                        >
                          <ExternalLink className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground">No related projects</p>
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Deposit Modal */}
      {showDepositModal && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0">
          <div className="bg-background border rounded-2xl shadow-lg max-w-md w-full mx-4 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95">
            <div className="p-6 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold">Create Deposit Invoice</h3>
                <Button 
                  variant="ghost" 
                  size="icon"
                  onClick={() => setShowDepositModal(false)}
                  className="h-8 w-8"
                >
                  <Plus className="h-4 w-4 rotate-45" />
                </Button>
              </div>
              
              <div className="space-y-3">
                <div>
                  <label className="text-sm font-medium text-foreground">Deposit Percentage</label>
                  <input
                    type="number"
                    value={depositPercentage}
                    onChange={(e) => setDepositPercentage(Number(e.target.value))}
                    className="w-full mt-1 px-3 py-2 border border-border rounded-lg bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-ring"
                    min="1"
                    max="100"
                  />
                </div>
                <div className="text-sm text-muted-foreground bg-muted/20 p-3 rounded-lg">
                  Deposit Amount: <span className="font-mono font-medium">€{((quote.total * depositPercentage) / 100).toFixed(2)}</span>
                </div>
              </div>
              
              <div className="flex gap-3 pt-4">
                <Button onClick={handleCreateDepositInvoice} className="flex-1">
                  Create Deposit Invoice
                </Button>
                <Button 
                  onClick={() => setShowDepositModal(false)} 
                  variant="outline" 
                  className="flex-1"
                >
                  Cancel
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}