import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

export interface Invoice {
  id: string;
  invoice_number: string;
  client_id: string;
  author_id: string;
  created_at: string;
  updated_at: string;
  subtotal: number;
  total: number;
  due_date?: string;
  issue_date?: string;
  quote_id?: string;
  currency: string;
  status: string;
  notes?: string;
  type: string;
}

export interface InvoiceLine {
  id: string;
  invoice_id: string;
  title: string;
  description?: string;
  quantity: number;
  unit_price: number;
  total: number;
  display_order: number;
  created_at: string;
  updated_at: string;
}

export function useInvoices() {
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  const fetchInvoices = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('invoices')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching invoices:', error);
        return;
      }

      setInvoices((data || []) as Invoice[]);
    } catch (error) {
      console.error('Error fetching invoices:', error);
    } finally {
      setLoading(false);
    }
  };

  const addInvoice = async (invoice: Omit<Invoice, 'id' | 'created_at' | 'updated_at' | 'author_id'>) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from('invoices')
        .insert([{ ...invoice, author_id: user.id }])
        .select()
        .single();

      if (error) throw error;

      setInvoices(prev => [data as Invoice, ...prev]);
      return data as Invoice;
    } catch (error) {
      throw error;
    }
  };

  const updateInvoice = async (id: string, updates: Partial<Invoice>) => {
    try {
      const { data, error } = await supabase
        .from('invoices')
        .update(updates)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;

      setInvoices(prev => prev.map(invoice => 
        invoice.id === id ? { ...invoice, ...data as Invoice } : invoice
      ));
      return data as Invoice;
    } catch (error) {
      throw error;
    }
  };

  useEffect(() => {
    fetchInvoices();
  }, []);

  return { invoices, loading, addInvoice, updateInvoice, refetch: fetchInvoices };
}

export function useInvoiceLines(invoiceId?: string) {
  const [invoiceLines, setInvoiceLines] = useState<InvoiceLine[]>([]);
  const [loading, setLoading] = useState(false);

  const fetchInvoiceLines = async () => {
    if (!invoiceId) {
      setInvoiceLines([]);
      return;
    }

    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('invoice_lines')
        .select('*')
        .eq('invoice_id', invoiceId)
        .order('display_order', { ascending: true });

      if (error) return;

      setInvoiceLines((data || []) as InvoiceLine[]);
    } catch (error) {
      console.error('Error fetching invoice lines:', error);
    } finally {
      setLoading(false);
    }
  };

  const addInvoiceLine = async (line: Omit<InvoiceLine, 'id' | 'created_at' | 'updated_at'>) => {
    const { data, error } = await supabase
      .from('invoice_lines')
      .insert([line])
      .select()
      .single();
    if (!error) setInvoiceLines(prev => [...prev, data]);
    return data;
  };

  const updateInvoiceLine = async (id: string, updates: Partial<InvoiceLine>) => {
    const { data, error } = await supabase
      .from('invoice_lines')
      .update(updates)
      .eq('id', id)
      .select()
      .single();
    if (!error) setInvoiceLines(prev => prev.map(line => line.id === id ? data : line));
    return data;
  };

  const deleteInvoiceLine = async (id: string) => {
    const { error } = await supabase
      .from('invoice_lines')
      .delete()
      .eq('id', id);
    if (!error) setInvoiceLines(prev => prev.filter(line => line.id !== id));
  };

  useEffect(() => {
    fetchInvoiceLines();
  }, [invoiceId]);

  return { invoiceLines, loading, addInvoiceLine, updateInvoiceLine, deleteInvoiceLine, refetch: fetchInvoiceLines };
}