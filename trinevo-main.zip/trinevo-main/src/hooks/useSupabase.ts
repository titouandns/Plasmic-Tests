import { useEffect, useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

// Define types directly since database is empty
type Customer = {
  id: string;
  company_name: string;
  contact_name: string;
  email: string;
  phone?: string;
  status: 'active' | 'inactive' | 'lead';
  billing_address?: string;
  street_address?: string;
  city?: string;
  postcode?: string;
  country?: string;
  state_region?: string;
  company_number?: string;
  tax_number?: string;
  notes?: string;
  archived: boolean;
  created_at: string;
  updated_at: string;
  user_id: string;
};

export interface Project {
  id: string;
  project_name: string;
  description?: string;
  customer_id: string;
  quote_id?: string; // Reference to the quote this project was created from
  start_date?: string;
  due_date?: string;
  status: 'not_started' | 'in_progress' | 'completed' | 'cancelled';
  progress: number;
  color_tag?: string;
  created_by: string;
  created_at: string;
  updated_at: string;
  customer?: Customer;
}

type Quote = {
  id: string;
  quote_number: string;
  status: 'Saved' | 'Sent' | 'Accepted' | 'Declined';
  client_id: string;
  currency: string;
  subtotal: number;
  total: number;
  notes?: string;
  created_at: string;
  updated_at: string;
  author_id: string;
  customer?: Customer;
}

type QuoteLine = {
  id: string;
  quote_id: string;
  title: string;
  description?: string;
  quantity: number;
  unit_price: number;
  total: number;
  display_order: number;
  created_at: string;
  updated_at: string;
}

export interface Task {
  id: string;
  project_id: string;
  title: string;
  description?: string;
  status: 'todo' | 'in_progress' | 'done';
  due_date?: string;
  priority: 'low' | 'medium' | 'high';
  estimated_time?: number;
  time_logged?: number;
  position: number;
  created_at: string;
  updated_at: string;
}

export function useCustomers() {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  const fetchCustomers = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('customers')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching customers:', error);
        toast({
          title: "Error",
          description: "Failed to fetch customers",
          variant: "destructive"
        });
        return;
      }

      setCustomers((data || []) as Customer[]);
    } catch (error) {
      console.error('Error fetching customers:', error);
      toast({
        title: "Error",
        description: "Failed to fetch customers",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const addCustomer = async (customer: Omit<Customer, 'id' | 'created_at' | 'updated_at' | 'user_id' | 'archived'>) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        toast({
          title: "Authentication Error",
          description: "Please log in to add customers",
          variant: "destructive"
        });
        return;
      }

      const { data, error } = await supabase
        .from('customers')
        .insert([{ ...customer, user_id: user.id, archived: false }])
        .select()
        .single();

      if (error) {
        console.error('Error adding customer:', error);
        toast({
          title: "Error",
          description: "Failed to add customer",
          variant: "destructive"
        });
        return;
      }

      setCustomers(prev => [data as Customer, ...prev]);
      toast({
        title: "Success",
        description: "Customer added successfully"
      });
    } catch (error) {
      console.error('Error adding customer:', error);
      toast({
        title: "Error",
        description: "Failed to add customer",
        variant: "destructive"
      });
    }
  };

  const updateCustomer = async (id: string, updates: Partial<Customer>) => {
    try {
      const { data, error } = await supabase
        .from('customers')
        .update(updates)
        .eq('id', id)
        .select()
        .single();

      if (error) {
        console.error('Error updating customer:', error);
        toast({
          title: "Error",
          description: "Failed to update customer",
          variant: "destructive"
        });
        return;
      }

      setCustomers(prev => prev.map(customer => 
        customer.id === id ? { ...customer, ...data as Customer } : customer
      ));
      toast({
        title: "Success",
        description: "Customer updated successfully"
      });
    } catch (error) {
      console.error('Error updating customer:', error);
      toast({
        title: "Error",
        description: "Failed to update customer",
        variant: "destructive"
      });
    }
  };

  useEffect(() => {
    fetchCustomers();
  }, []);

  return { customers, loading, addCustomer, updateCustomer, refetch: fetchCustomers };
}

export function useQuotes() {
  const [quotes, setQuotes] = useState<Quote[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  const fetchQuotes = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('quotes')
        .select(`
          *,
          customer:customers(*)
        `)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching quotes:', error);
        toast({
          title: "Error",
          description: "Failed to fetch quotes",
          variant: "destructive"
        });
        return;
      }

      setQuotes((data || []) as Quote[]);
    } catch (error) {
      console.error('Error fetching quotes:', error);
      toast({
        title: "Error",
        description: "Failed to fetch quotes",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const addQuote = async (quote: Omit<Quote, 'id' | 'created_at' | 'updated_at' | 'author_id'>) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        toast({
          title: "Authentication Error",
          description: "Please log in to add quotes",
          variant: "destructive"
        });
        return;
      }

      const { data, error } = await supabase
        .from('quotes')
        .insert([{ ...quote, author_id: user.id }])
        .select(`
          *,
          customer:customers(*)
        `)
        .single();

      if (error) {
        console.error('Error adding quote:', error);
        toast({
          title: "Error",
          description: "Failed to add quote",
          variant: "destructive"
        });
        return;
      }

      setQuotes(prev => [data as Quote, ...prev]);
      toast({
        title: "Success",
        description: "Quote added successfully"
      });
      return data as Quote;
    } catch (error) {
      console.error('Error adding quote:', error);
      toast({
        title: "Error",
        description: "Failed to add quote",
        variant: "destructive"
      });
      throw error;
    }
  };

  const updateQuote = async (id: string, updates: Partial<Quote>) => {
    try {
      const { data, error } = await supabase
        .from('quotes')
        .update(updates)
        .eq('id', id)
        .select(`
          *,
          customer:customers(*)
        `)
        .single();

      if (error) {
        console.error('Error updating quote:', error);
        toast({
          title: "Error",
          description: "Failed to update quote",
          variant: "destructive"
        });
        return;
      }

      setQuotes(prev => prev.map(quote => 
        quote.id === id ? { ...quote, ...data as Quote } : quote
      ));
      toast({
        title: "Success",
        description: "Quote updated successfully"
      });
      return data as Quote;
    } catch (error) {
      console.error('Error updating quote:', error);
      toast({
        title: "Error",
        description: "Failed to update quote",
        variant: "destructive"
      });
      throw error;
    }
  };

  useEffect(() => {
    fetchQuotes();
  }, []);

  return { quotes, loading, addQuote, updateQuote, refetch: fetchQuotes };
}

export function useQuoteLines(quoteId?: string) {
  const [quoteLines, setQuoteLines] = useState<QuoteLine[]>([]);
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const fetchQuoteLines = async () => {
    if (!quoteId) {
      setQuoteLines([]);
      return;
    }

    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('quote_lines')
        .select('*')
        .eq('quote_id', quoteId)
        .order('display_order', { ascending: true });

      if (error) {
        console.error('Error fetching quote lines:', error);
        toast({
          title: "Error",
          description: "Failed to fetch quote lines",
          variant: "destructive"
        });
        return;
      }

      setQuoteLines((data || []) as QuoteLine[]);
    } catch (error) {
      console.error('Error fetching quote lines:', error);
    } finally {
      setLoading(false);
    }
  };

  const addQuoteLine = async (quoteLine: Omit<QuoteLine, 'id' | 'created_at' | 'updated_at'>) => {
    try {
      const { data, error } = await supabase
        .from('quote_lines')
        .insert([quoteLine])
        .select()
        .single();

      if (error) {
        console.error('Error adding quote line:', error);
        toast({
          title: "Error",
          description: "Failed to add quote line",
          variant: "destructive"
        });
        return;
      }

      setQuoteLines(prev => [...prev, data as QuoteLine]);
      return data as QuoteLine;
    } catch (error) {
      console.error('Error adding quote line:', error);
      throw error;
    }
  };

  const updateQuoteLine = async (id: string, updates: Partial<QuoteLine>) => {
    try {
      const { data, error } = await supabase
        .from('quote_lines')
        .update(updates)
        .eq('id', id)
        .select()
        .single();

      if (error) {
        console.error('Error updating quote line:', error);
        toast({
          title: "Error",
          description: "Failed to update quote line",
          variant: "destructive"
        });
        return;
      }

      setQuoteLines(prev => prev.map(line => 
        line.id === id ? { ...line, ...data as QuoteLine } : line
      ));
      return data as QuoteLine;
    } catch (error) {
      console.error('Error updating quote line:', error);
      throw error;
    }
  };

  const deleteQuoteLine = async (id: string) => {
    try {
      const { error } = await supabase
        .from('quote_lines')
        .delete()
        .eq('id', id);

      if (error) {
        console.error('Error deleting quote line:', error);
        toast({
          title: "Error",
          description: "Failed to delete quote line",
          variant: "destructive"
        });
        return;
      }

      setQuoteLines(prev => prev.filter(line => line.id !== id));
    } catch (error) {
      console.error('Error deleting quote line:', error);
      throw error;
    }
  };

  useEffect(() => {
    fetchQuoteLines();
  }, [quoteId]);

  return { quoteLines, loading, addQuoteLine, updateQuoteLine, deleteQuoteLine, refetch: fetchQuoteLines };
}

export function useProjects() {
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  const fetchProjects = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('projects')
        .select(`
          *,
          customer:customers(*)
        `)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching projects:', error);
        toast({
          title: "Error",
          description: "Failed to fetch projects",
          variant: "destructive"
        });
        return;
      }

      setProjects((data || []) as Project[]);
    } catch (error) {
      console.error('Error fetching projects:', error);
      toast({
        title: "Error",
        description: "Failed to fetch projects",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const addProject = async (project: Omit<Project, 'id' | 'created_at' | 'updated_at' | 'created_by'>) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        toast({
          title: "Authentication Error",
          description: "Please log in to add projects",
          variant: "destructive"
        });
        return;
      }

      const { data, error } = await supabase
        .from('projects')
        .insert([{ ...project, created_by: user.id }])
        .select(`
          *,
          customer:customers(*)
        `)
        .single();

      if (error) {
        console.error('Error adding project:', error);
        toast({
          title: "Error",
          description: "Failed to add project",
          variant: "destructive"
        });
        return;
      }

      setProjects(prev => [data as Project, ...prev]);
      toast({
        title: "Success",
        description: "Project added successfully"
      });
      return data as Project;
    } catch (error) {
      console.error('Error adding project:', error);
      toast({
        title: "Error",
        description: "Failed to add project",
        variant: "destructive"
      });
      throw error;
    }
  };

  const updateProject = async (id: string, updates: Partial<Project>) => {
    try {
      const { data, error } = await supabase
        .from('projects')
        .update(updates)
        .eq('id', id)
        .select(`
          *,
          customer:customers(*)
        `)
        .single();

      if (error) {
        console.error('Error updating project:', error);
        toast({
          title: "Error",
          description: "Failed to update project",
          variant: "destructive"
        });
        return;
      }

      setProjects(prev => prev.map(project => 
        project.id === id ? { ...project, ...data as Project } : project
      ));
      toast({
        title: "Success",
        description: "Project updated successfully"
      });
      return data as Project;
    } catch (error) {
      console.error('Error updating project:', error);
      toast({
        title: "Error",
        description: "Failed to update project",
        variant: "destructive"
      });
      throw error;
    }
  };

  useEffect(() => {
    fetchProjects();
  }, []);

  return { projects, loading, addProject, updateProject, refetch: fetchProjects };
}

export function useTasks(projectId?: string) {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const fetchTasks = async () => {
    if (!projectId) {
      setTasks([]);
      return;
    }

    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('tasks')
        .select(`
          *,
          projects (
            project_name,
            customer_id,
            customers (
              company_name
            )
          )
        `)
        .eq('project_id', projectId)
        .order('position', { ascending: true });

      if (error) {
        console.error('Error fetching tasks:', error);
        toast({
          title: "Error",
          description: "Failed to fetch tasks",
          variant: "destructive"
        });
        return;
      }

      setTasks((data || []) as Task[]);
    } catch (error) {
      console.error('Error fetching tasks:', error);
    } finally {
      setLoading(false);
    }
  };

  const addTask = async (task: Omit<Task, 'id' | 'created_at' | 'updated_at'>) => {
    try {
      const { data, error } = await supabase
        .from('tasks')
        .insert([task])
        .select()
        .single();

      if (error) {
        console.error('Error adding task:', error);
        toast({
          title: "Error",
          description: "Failed to add task",
          variant: "destructive"
        });
        return;
      }

      setTasks(prev => [...prev, data as Task]);
      toast({
        title: "Success",
        description: "Task added successfully"
      });
      return data as Task;
    } catch (error) {
      console.error('Error adding task:', error);
      throw error;
    }
  };

  const updateTask = async (id: string, updates: Partial<Task>) => {
    try {
      const { data, error } = await supabase
        .from('tasks')
        .update(updates)
        .eq('id', id)
        .select()
        .single();

      if (error) {
        console.error('Error updating task:', error);
        toast({
          title: "Error",
          description: "Failed to update task",
          variant: "destructive"
        });
        return;
      }

      setTasks(prev => prev.map(task => 
        task.id === id ? { ...task, ...data as Task } : task
      ));
      return data as Task;
    } catch (error) {
      console.error('Error updating task:', error);
      throw error;
    }
  };

  const deleteTask = async (id: string) => {
    try {
      const { error } = await supabase
        .from('tasks')
        .delete()
        .eq('id', id);

      if (error) {
        console.error('Error deleting task:', error);
        toast({
          title: "Error",
          description: "Failed to delete task",
          variant: "destructive"
        });
        return;
      }

      setTasks(prev => prev.filter(task => task.id !== id));
      toast({
        title: "Success",
        description: "Task deleted successfully"
      });
    } catch (error) {
      console.error('Error deleting task:', error);
      throw error;
    }
  };

  const reorderTasks = async (reorderedTasks: Task[]) => {
    try {
      // Update positions in bulk
      const updates = reorderedTasks.map((task, index) => ({
        id: task.id,
        position: index,
      }));

      for (const update of updates) {
        await supabase
          .from('tasks')
          .update({ position: update.position })
          .eq('id', update.id);
      }

      setTasks(reorderedTasks);
    } catch (error) {
      console.error('Error reordering tasks:', error);
      toast({
        title: "Error",
        description: "Failed to reorder tasks",
        variant: "destructive"
      });
    }
  };

  useEffect(() => {
    fetchTasks();
  }, [projectId]);

  return { 
    tasks, 
    loading, 
    addTask, 
    updateTask, 
    deleteTask, 
    reorderTasks, 
    refetch: fetchTasks 
  };
}

// Hook for fetching all tasks across all projects
export function useAllTasks() {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const fetchAllTasks = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('tasks')
        .select(`
          *,
          projects (
            project_name,
            customer_id,
            customers (
              company_name
            )
          )
        `)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching all tasks:', error);
        toast({
          title: "Error",
          description: "Failed to fetch tasks",
          variant: "destructive"
        });
        return;
      }

      setTasks((data || []) as Task[]);
    } catch (error) {
      console.error('Error fetching all tasks:', error);
    } finally {
      setLoading(false);
    }
  };

  const addTask = async (task: Omit<Task, 'id' | 'created_at' | 'updated_at'>) => {
    try {
      const { data, error } = await supabase
        .from('tasks')
        .insert([task])
        .select(`
          *,
          projects (
            project_name,
            customer_id,
            customers (
              company_name
            )
          )
        `)
        .single();

      if (error) {
        console.error('Error adding task:', error);
        toast({
          title: "Error",
          description: "Failed to add task",
          variant: "destructive"
        });
        return;
      }

      setTasks(prev => [data as Task, ...prev]);
      toast({
        title: "Success",
        description: "Task added successfully"
      });
      return data as Task;
    } catch (error) {
      console.error('Error adding task:', error);
      throw error;
    }
  };

  const updateTask = async (id: string, updates: Partial<Task>) => {
    try {
      const { data, error } = await supabase
        .from('tasks')
        .update(updates)
        .eq('id', id)
        .select(`
          *,
          projects (
            project_name,
            customer_id,
            customers (
              company_name
            )
          )
        `)
        .single();

      if (error) {
        console.error('Error updating task:', error);
        toast({
          title: "Error",
          description: "Failed to update task",
          variant: "destructive"
        });
        return;
      }

      setTasks(prev => prev.map(task => 
        task.id === id ? { ...task, ...data as Task } : task
      ));
      return data as Task;
    } catch (error) {
      console.error('Error updating task:', error);
      throw error;
    }
  };

  const deleteTask = async (id: string) => {
    try {
      const { error } = await supabase
        .from('tasks')
        .delete()
        .eq('id', id);

      if (error) {
        console.error('Error deleting task:', error);
        toast({
          title: "Error",
          description: "Failed to delete task",
          variant: "destructive"
        });
        return;
      }

      setTasks(prev => prev.filter(task => task.id !== id));
      toast({
        title: "Success",
        description: "Task deleted successfully"
      });
    } catch (error) {
      console.error('Error deleting task:', error);
      throw error;
    }
  };

  const reorderTasks = async (reorderedTasks: Task[]) => {
    try {
      // Update positions in bulk
      const updates = reorderedTasks.map((task, index) => ({
        id: task.id,
        position: index,
      }));

      for (const update of updates) {
        await supabase
          .from('tasks')
          .update({ position: update.position })
          .eq('id', update.id);
      }

      setTasks(prev => prev.map(task => {
        const updated = reorderedTasks.find(rt => rt.id === task.id);
        return updated ? updated : task;
      }));
    } catch (error) {
      console.error('Error reordering tasks:', error);
      toast({
        title: "Error",
        description: "Failed to reorder tasks",
        variant: "destructive"
      });
    }
  };

  useEffect(() => {
    fetchAllTasks();
  }, []);

  return { 
    tasks, 
    loading, 
    addTask, 
    updateTask, 
    deleteTask, 
    reorderTasks, 
    refetch: fetchAllTasks 
  };
}

// Profile hooks
export function useProfile() {
  const [profile, setProfile] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchProfile = useCallback(async () => {
    try {
      setLoading(true);
      const { data: { session } } = await supabase.auth.getSession();
      
      if (!session?.user) {
        setProfile(null);
        return;
      }

      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('user_id', session.user.id)
        .single();

      if (error && error.code !== 'PGRST116') {
        throw error;
      }

      setProfile(data);
    } catch (err) {
      console.error('Error fetching profile:', err);
      setError(err instanceof Error ? err.message : 'Failed to fetch profile');
    } finally {
      setLoading(false);
    }
  }, []);

  const updateProfile = useCallback(async (profileData: any) => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      
      if (!session?.user) {
        throw new Error('No authenticated user');
      }

      const { data, error } = await supabase
        .from('profiles')
        .update(profileData)
        .eq('user_id', session.user.id)
        .select()
        .single();

      if (error) throw error;

      setProfile(data);
      return data;
    } catch (err) {
      console.error('Error updating profile:', err);
      setError(err instanceof Error ? err.message : 'Failed to update profile');
      throw err;
    }
  }, []);

  useEffect(() => {
    fetchProfile();
  }, [fetchProfile]);

  return {
    profile,
    updateProfile,
    loading,
    error,
    refetch: fetchProfile,
  };
}