import { useState } from "react";
import { useAuth } from "@/components/AuthProvider";
import { useTeam } from "@/hooks/useTeam";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface OnboardingData {
  firstName: string;
  lastName: string;
  teamName: string;
  inviteEmails: string[];
}

export function useOnboarding() {
  const [currentStep, setCurrentStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [onboardingData, setOnboardingData] = useState<OnboardingData>({
    firstName: "",
    lastName: "",
    teamName: "",
    inviteEmails: [],
  });

  const { user } = useAuth();
  const { createTeam, inviteUser } = useTeam();

  const updateOnboardingData = (data: Partial<OnboardingData>) => {
    setOnboardingData(prev => ({ ...prev, ...data }));
  };

  const nextStep = () => {
    setCurrentStep(prev => prev + 1);
  };

  const prevStep = () => {
    setCurrentStep(prev => prev - 1);
  };

  const completeOnboarding = async () => {
    if (!user) return;

    setLoading(true);
    try {
      console.log("Starting onboarding completion for user:", user.id);
      console.log("Onboarding data:", onboardingData);

      // Check if profile already exists
      const { data: existingProfile, error: fetchError } = await supabase
        .from("profiles")
        .select("user_id, onboarding_completed")
        .eq("user_id", user.id)
        .maybeSingle();

      console.log("Existing profile:", existingProfile);
      if (fetchError) {
        console.error("Error fetching existing profile:", fetchError);
      }

      // Update or insert user profile with name
      const profileData = {
        user_id: user.id,
        first_name: onboardingData.firstName,
        last_name: onboardingData.lastName,
        onboarding_completed: true,
      };

      console.log("Upserting profile data:", profileData);

      const { error: profileError } = await supabase
        .from("profiles")
        .upsert(profileData, {
          onConflict: 'user_id'
        });

      if (profileError) {
        console.error("Profile upsert error:", profileError);
        throw profileError;
      }

      console.log("Profile upserted successfully");

      // Create team
      console.log("Creating team:", onboardingData.teamName);
      const newTeam = await createTeam(onboardingData.teamName);
      console.log("Team created:", newTeam);

      // Send invitations if any emails were provided
      if (onboardingData.inviteEmails.length > 0 && newTeam) {
        console.log("Sending invitations to:", onboardingData.inviteEmails);
        for (const email of onboardingData.inviteEmails) {
          if (email.trim()) {
            try {
              await inviteUser(email.trim(), 'member');
            } catch (inviteError) {
              console.error("Error inviting user:", inviteError);
              // Don't fail the entire onboarding for invite errors
            }
          }
        }
      }

      toast.success("Welcome to Trinevo! Your account is ready.");
      console.log("Onboarding completed successfully");
      return true;
    } catch (error) {
      console.error("Error completing onboarding:", error);
      toast.error("Failed to complete onboarding. Please try again.");
      return false;
    } finally {
      setLoading(false);
    }
  };

  return {
    currentStep,
    onboardingData,
    loading,
    updateOnboardingData,
    nextStep,
    prevStep,
    completeOnboarding,
  };
}