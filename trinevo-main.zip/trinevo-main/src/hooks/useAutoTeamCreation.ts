import { useEffect } from "react";
import { useAuth } from "@/components/AuthProvider";
import { useTeam } from "@/hooks/useTeam";
import { supabase } from "@/integrations/supabase/client";

export function useAutoTeamCreation() {
  const { user } = useAuth();
  const { team, loading, createTeam } = useTeam();

  useEffect(() => {
    const checkAndCreateTeam = async () => {
      // Only try to create team if user is logged in, not loading, and no team exists
      if (!user || loading || team) return;

      // Skip auto team creation if user hasn't completed onboarding
      // (onboarding process will handle team creation)
      const { data: profile } = await supabase.from("profiles")
        .select("onboarding_completed")
        .eq("user_id", user.id)
        .single();
      
      if (!profile?.onboarding_completed) return;

      try {
        const firstName = user.user_metadata?.first_name || 
                         user.email?.split('@')[0] || 
                         'User';
        const teamName = `${firstName}'s Team`;
        
        await createTeam(teamName);
      } catch (error) {
        console.error('Failed to auto-create team:', error);
      }
    };

    // Wait a bit for the team hook to finish loading
    const timer = setTimeout(checkAndCreateTeam, 1000);
    
    return () => clearTimeout(timer);
  }, [user, team, loading, createTeam]);
}