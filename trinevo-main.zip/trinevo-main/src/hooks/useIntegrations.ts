import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

export function useIntegrations() {
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const connectStripe = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase.functions.invoke('connect-stripe', {
        body: { action: 'connect' }
      });

      if (error) throw error;

      toast({
        title: "Success",
        description: "Stripe connected successfully"
      });

      return data;
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to connect Stripe",
        variant: "destructive"
      });
      throw error;
    } finally {
      setLoading(false);
    }
  };

  const disconnectStripe = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase.functions.invoke('connect-stripe', {
        body: { action: 'disconnect' }
      });

      if (error) throw error;

      toast({
        title: "Success",
        description: "Stripe disconnected successfully"
      });

      return data;
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to disconnect Stripe",
        variant: "destructive"
      });
      throw error;
    } finally {
      setLoading(false);
    }
  };

  const createPaymentLink = async (params: {
    invoice_id: string;
    amount: number;
    currency?: string;
    customer_email?: string;
    customer_name?: string;
    description?: string;
  }) => {
    try {
      setLoading(true);
      const { data, error } = await supabase.functions.invoke('create-payment-link', {
        body: params
      });

      if (error) throw error;

      return data;
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to create payment link",
        variant: "destructive"
      });
      throw error;
    } finally {
      setLoading(false);
    }
  };

  const sendInvoiceEmail = async (params: {
    invoice_id: string;
    customer_email: string;
    customer_name?: string;
    subject?: string;
    message?: string;
    payment_link_url?: string;
    invoice_number?: string;
    total_amount?: number;
    currency?: string;
  }) => {
    try {
      setLoading(true);
      const { data, error } = await supabase.functions.invoke('send-invoice-email', {
        body: params
      });

      if (error) throw error;

      toast({
        title: "Success",
        description: "Invoice email sent successfully"
      });

      return data;
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to send invoice email",
        variant: "destructive"
      });
      throw error;
    } finally {
      setLoading(false);
    }
  };

  const sendQuoteEmail = async (params: {
    quote_id: string;
    customer_email: string;
    customer_name?: string;
    subject?: string;
    message?: string;
    quote_number?: string;
    total_amount?: number;
    currency?: string;
  }) => {
    try {
      setLoading(true);
      const { data, error } = await supabase.functions.invoke('send-quote-email', {
        body: params
      });

      if (error) throw error;

      toast({
        title: "Success",
        description: "Quote email sent successfully"
      });

      return data;
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to send quote email",
        variant: "destructive"
      });
      throw error;
    } finally {
      setLoading(false);
    }
  };

  return {
    loading,
    connectStripe,
    disconnectStripe,
    createPaymentLink,
    sendInvoiceEmail,
    sendQuoteEmail
  };
}