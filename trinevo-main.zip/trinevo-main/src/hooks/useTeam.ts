import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/components/AuthProvider";

export interface Team {
  id: string;
  name: string;
  logo?: string;
  created_at: string;
  updated_at: string;
}

export interface TeamMember {
  id: string;
  team_id: string;
  user_id: string;
  role: string;
  joined_at: string;
  profiles?: {
    first_name?: string;
    last_name?: string;
    avatar_url?: string;
  };
}

export interface Invite {
  id: string;
  email: string;
  team_id: string;
  invited_by: string;
  token: string;
  role: string;
  used: boolean;
  expires_at: string;
  created_at: string;
}

export function useTeam() {
  const { user } = useAuth();
  const [team, setTeam] = useState<Team | null>(null);
  const [teamMembers, setTeamMembers] = useState<TeamMember[]>([]);
  const [invites, setInvites] = useState<Invite[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchTeam = async () => {
    if (!user) return;
    
    try {
      setLoading(true);
      
      // Get user's team
      const { data: memberData } = await supabase
        .from('team_members')
        .select(`
          team_id,
          teams (
            id,
            name,
            logo,
            created_at,
            updated_at
          )
        `)
        .eq('user_id', user.id)
        .single();

      if (memberData?.teams) {
        setTeam(memberData.teams as Team);
        
        // Fetch team members with their profiles
        const { data: members } = await supabase
          .from('team_members')
          .select(`
            id,
            team_id,
            user_id,
            role,
            joined_at
          `)
          .eq('team_id', memberData.teams.id);

        // Fetch profiles for team members
        if (members && members.length > 0) {
          const userIds = members.map(m => m.user_id);
          const { data: profiles } = await supabase
            .from('profiles')
            .select('user_id, first_name, last_name, avatar_url')
            .in('user_id', userIds);

          const membersWithProfiles = members.map(member => ({
            ...member,
            profiles: profiles?.find(p => p.user_id === member.user_id)
          }));

          setTeamMembers(membersWithProfiles);
        } else {
          setTeamMembers([]);
        }

        // Fetch pending invites
        const { data: inviteData } = await supabase
          .from('invites')
          .select('*')
          .eq('team_id', memberData.teams.id)
          .eq('used', false);

        setInvites(inviteData || []);
      }
    } catch (error) {
      console.error('Error fetching team:', error);
    } finally {
      setLoading(false);
    }
  };

  const updateTeam = async (updates: Partial<Team>) => {
    if (!team) {
      // Create a new team if none exists
      return await createTeam(updates.name || 'My Team');
    }

    try {
      const { data, error } = await supabase
        .from('teams')
        .update(updates)
        .eq('id', team.id)
        .select()
        .single();

      if (error) throw error;
      
      setTeam(data);
      return data;
    } catch (error) {
      console.error('Error updating team:', error);
      throw error;
    }
  };

  const createTeam = async (name: string) => {
    if (!user) return null;

    try {
      // Create team
      const { data: teamData, error: teamError } = await supabase
        .from('teams')
        .insert({ name })
        .select()
        .single();

      if (teamError) throw teamError;

      // Add user as owner
      const { error: memberError } = await supabase
        .from('team_members')
        .insert({
          team_id: teamData.id,
          user_id: user.id,
          role: 'owner',
          invited_by: user.id
        });

      if (memberError) throw memberError;

      // Update user's profile with team_id
      const { error: profileError } = await supabase
        .from('profiles')
        .update({ team_id: teamData.id })
        .eq('user_id', user.id);

      if (profileError) throw profileError;

      setTeam(teamData);
      return teamData;
    } catch (error) {
      console.error('Error creating team:', error);
      throw error;
    }
  };

  const inviteUser = async (email: string, role: string = 'member') => {
    if (!team || !user) return null;

    try {
      const token = crypto.randomUUID();
      const expiresAt = new Date();
      expiresAt.setDate(expiresAt.getDate() + 7); // 7 days expiry

      const { data, error } = await supabase
        .from('invites')
        .insert({
          email,
          team_id: team.id,
          invited_by: user.id,
          token,
          role,
          expires_at: expiresAt.toISOString()
        })
        .select()
        .single();

      if (error) throw error;

      // Send invitation email using Supabase Auth
      const inviteLink = `${window.location.origin}/join/${data.token}`;
      
      const { error: emailError } = await supabase.auth.admin.inviteUserByEmail(email, {
        redirectTo: inviteLink,
        data: {
          team_id: team.id,
          team_name: team.name,
          invited_by_name: user.user_metadata?.first_name || user.email,
          role: role
        }
      });

      if (emailError) {
        console.error('Email sending failed:', emailError);
        // Don't throw error for email failure, invitation record is created
      }

      setInvites(prev => [...prev, data]);
      return data;
    } catch (error) {
      console.error('Error inviting user:', error);
      throw error;
    }
  };

  const uploadTeamLogo = async (file: File) => {
    if (!team) return null;

    try {
      const fileExt = file.name.split('.').pop();
      const fileName = `${team.id}/logo.${fileExt}`;

      const { error: uploadError } = await supabase.storage
        .from('team-logos')
        .upload(fileName, file, { upsert: true });

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from('team-logos')
        .getPublicUrl(fileName);

      // Update team with new logo URL
      const updatedTeam = await updateTeam({ logo: publicUrl });
      return updatedTeam;
    } catch (error) {
      console.error('Error uploading team logo:', error);
      throw error;
    }
  };

  useEffect(() => {
    fetchTeam();
  }, [user]);

  return {
    team,
    teamMembers,
    invites,
    loading,
    fetchTeam,
    updateTeam,
    createTeam,
    inviteUser,
    uploadTeamLogo
  };
}